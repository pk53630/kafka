#!/usr/bin/python3
import csv

with open("/home/odmbatch/odm/Scripts/9-17-19_fluid_shots.csv", 'rb') as my_file:
    reader = csv.reader(my_file, delimiter=',')
    my_list = list(reader.decode("utf-8", errors="ignore"))
    print(my_list)
