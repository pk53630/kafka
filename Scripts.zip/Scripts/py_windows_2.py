#!/usr/bin/python3
import csv
import sys
import os
import cx_Oracle
import datetime


query=""" SELECT distinct Division_ID FROM ODM_INFO.ODM_COMPLETION WHERE PRIMO_PRPRTY ="""
connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)




lst=[]

with open('/home/odmbatch/odm/Scripts/9-17-19_fluid_shots.csv', 'rb') as f:
    for row in f:
        a=row.decode("utf-8",errors="ignore").split(',')
        lst.append(a)


print(lst[0][347])
#print(lst[10]+"--"+lst[1]+"--")

#cursor.executemany("""
#insert into iprod_dba.ECHOMETER_FLUID_SURVEY_test (DIVISION_ID,WELL_ID,DATE_VALUE,FLUID_LEVEL_SURVEY_DATE,COMMENT_TXT)
#        values (:10, :319,:1,:1,:347)""", lst)


#for result in cursor:
        #    print (result[0])
	
cursor.close()
connection.close()
