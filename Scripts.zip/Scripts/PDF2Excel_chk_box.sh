#!/usr/bin/sh

#filename=$1
#fileout=$2
#filename_p="/home/odmbatch/odm/Scripts/""$filename"
#output_filename="/home/odmbatch/odm/Scripts/""$fileout"


filename_p="/home/odmbatch/odm/Scripts/30015451150000_6_wf.txt"
output_filename="/home/odmbatch/odm/Scripts/30015451150000_6_wf.csv"

type_of_well=`grep -n "Well Name and No" $filename_p|cut -d ":" -f1`
value_well=`expr $type_of_well + 4`
v_value_well=`echo "$value_well""p"`
type_well_value=`sed -n $v_value_well $filename_p|awk '{$1=$1;print}'|cut -d '"' -f4`
z1=`echo "$type_well_value"| tr "0" "\n"|awk '{$1=$1;print}'|grep -v "^<U+25A1>"`
z2=`expr index "$z1" '<U+25A1>'`
z3=`expr $z2 - 2`
o_type_well_value=`echo "${z1:0:$z3}"`
type_well_nm=`grep -n "Type of Well" $filename_p| cut -d ":" -f2|cut -d '"' -f4`
type_of_well_nm=`grep -n "Type of Well" $filename_p| cut -d ":" -f2|cut -d '"' -f4|head -c 50|awk '{$1=$1;print}'`
well_num_nm=`grep -n "Type of Well" $filename_p| cut -d ":" -f2|cut -d '"' -f4|tail -c 50|awk '{$1=$1;print}'`

v_well_no=`expr $type_of_well + 2`
v_value_well_no=`echo "$v_well_no""p"`
type_well_value=`sed -n $v_value_well_no $filename_p|awk '{$1=$1;print}'|cut -d '"' -f4`


name_of_oper=`grep -n "Name of Operator" $filename_p|cut -d ":" -f1`
value_name=`expr $name_of_oper + 2`
v_value_name=`echo "$value_name""p"`
operator_nm=`grep -n "Name of Operator" $filename_p|cut -d "." -f2|head -c 20|awk '{$1=$1;print}'`
API_well_nm=`grep -n "Name of Operator" $filename_p|cut -d "." -f3|awk '{$1=$1;print}'`
operator_nm_val_1=`grep -n "Name of Operator" $filename_p|cut -d "." -f2|tail -c 100|awk '{$1=$1;print}'`
operator_nm_val_2=`sed -n $v_value_name $filename_p|cut -d '"' -f4|head -c 120|awk '{$1=$1;print}'`
API_well_val=`sed -n $v_value_name $filename_p|tail -c 60|awk '{$1=$1;print}'`


addr_oper=`grep -n "Address" $filename_p|cut -d ":" -f1`
value_addr=`expr $addr_oper + 2`
v_value_addr=`echo "$value_addr""p"`
addr_operator=`grep -n "Address" $filename_p|cut -d '"' -f4|head -c 130|awk '{$1=$1;print}'`
pool_nm=`grep -n "Address" $filename_p|cut -d '"' -f4|tail -c 50|awk '{$1=$1;print}'`
addr_operator_val=`sed -n $v_value_addr $filename_p|cut -d '"' -f4|head -c 130|awk '{$1=$1;print}'`
pool_num_val=`sed -n $v_value_addr $filename_p|cut -d '"' -f4|tail -c 60|awk '{$1=$1;print}'`

well_loc=`grep -n "Location of Well" $filename_p|cut -d ":" -f1`
country_nm=`grep -n "Location of Well" $filename_p|cut -d '"' -f4|tail -c 70|tr -s "," " "|awk '{$1=$1;print}'`
location_nm=`grep -n "Location of Well" $filename_p|cut -d '"' -f4|head -c 28|awk '{$1=$1;print}'`
value_country_nm=`expr $well_loc + 2`
v_country_nm=`echo $value_country_nm"p"`
country_value=`sed -n $v_country_nm $filename_p|tail -c 70|awk '{$1=$1;print}'`
loc_nm_val_1=`sed -n $v_country_nm $filename_p|cut -d '"' -f4|head -c 100|awk '{$1=$1;print}'`
value_loc_nm=`expr $well_loc + 4`
v_loc_nm=`echo "$value_loc_nm""p"`
loc_nm_val_2=`sed -n $v_loc_nm $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'`


lease_sl_no=`grep -n "Lease Serial No" $filename_p|cut -d ":" -f1`
value_lease=`expr $lease_sl_no + 2`
v_value_lease=`echo "$value_lease""p"`
lease_sl_nm=`grep -n "Lease Serial No" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'`
lease_sl_val=`sed -n $v_value_lease $filename_p|cut -d '"' -f4|tail -c 40 |awk '{$1=$1;print}'`


ind_alloc_no=`grep -n "If Indian, Allottee or Tribe Name" $filename_p|cut -d ":" -f1`
value_ind_alloc=`expr $ind_alloc_no + 2`
v_ind_alloc=`echo "$value_ind_alloc""p"`
ind_alloc_nm=`grep -n "If Indian, Allottee or Tribe Name" $filename_p|cut -d '"' -f4|tail -c 50|tr -s "," " "|awk '{$1=$1;print}'`
ind_alloc_val=`sed -n $v_ind_alloc $filename_p|cut -d '"' -f4|cut -d "." -f3|awk '{$1=$1;print}'`

unit_no=`grep -n "If Unit or CA/Agreement, Name and/or No" $filename_p|cut -d ":" -f1`
value_unit=`expr $unit_no + 2`
v_unit=`echo "$value_unit""p"`
unit_nm=`grep -n "If Unit or CA/Agreement, Name and/or No" $filename_p|cut -d '"' -f4|tail -c 50|tr -s "," " "|awk '{$1=$1;print}'`
unit_val=`sed -n $v_unit $filename_p|cut -d '"' -f4|tail -c 50|awk '{$1=$1;print}'`

chk_boc_no=`grep -n "CHECK THE APPROPRIATE BOX(ES) TO INDICATE NATURE OF NOTICE, REPORT, OR OTHER DATA" $filename_p|cut -d ":" -f1`
chk_nm=`grep -n "CHECK THE APPROPRIATE BOX(ES) TO INDICATE NATURE OF NOTICE, REPORT, OR OTHER DATA" $filename_p|cut -d '"' -f4|tr -s "," " "|awk '{$1=$1;print}'`
x="(TYPE OF SUBMISSION / TYPE OF ACTION)"
chk_ful_nm=`echo "$chk_nm""$x"`
grep "Notice of Intent" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}' > /home/odmbatch/odm/Scripts/tmp_type_submission.txt
grep "Subsequent Report" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_submission.txt
grep "Final Abandonment Notice" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_submission.txt
z1=`cat /home/odmbatch/odm/Scripts/tmp_type_submission.txt|grep -v "^<U+25A1>"|head -c 20|awk '{$1=$1;print}'`
chk_box_val_1=`echo ${z1:1}`

grep "Acidize" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}' > /home/odmbatch/odm/Scripts/tmp_type_action.txt
grep "Alter Casing" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
grep "Casing Repair" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'|tail -c 77 >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
grep "Change Plans" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'|tail -c 77 >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
grep "Convert to Injection" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_action.txt

cat /home/odmbatch/odm/Scripts/tmp_type_action.txt|tr "<U+25A1>" "\n"|tr -s "\n"|grep "0" > /home/odmbatch/odm/Scripts/tmp_type.txt
dtfile="/home/odmbatch/odm/Scripts/tmp_type.txt"
dtfileoutput="/home/odmbatch/odm/Scripts/tmp_type_out.txt"
echo > $dtfileoutput
while read line
do
  #echo "$line"
  ty=`expr index "$line" '0'`
  k=`echo "${line:$ty}"|awk '{$1=$1;print}'`
  #echo ${#k}
  echo "${line:$ty}" >> /home/odmbatch/odm/Scripts/tmp_type_out.txt
  if [[ "$k" == 'Other' ]]
  then
   #echo "asasasas"
   sed -n '56p' $filename_p|tr -d [0-9]|tr '"' ' '|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_out.txt
  fi
done <$dtfile

chk_box_val_2=`cat $dtfileoutput|tr "\n" ","|awk '{$1=$1;print}'|sed 's/,//1'|sed 's/ Other,/ Other-/'|sed 's/.$//'`
#echo $wsx

desc_no=`grep -n "Describe Proposed or Completed Operation" $filename_p|cut -d ":" -f1`
last_no=`grep -n "I hereby certify that the foregoing is true and correct" $filename_p|cut -d ":" -f1`
value_desc_low=`expr $desc_no + 12`
value_desc_high=`expr $last_no - 2`
v_desc=`echo "$value_desc_low"",""$value_desc_high""p"`
desc_nm=`grep -n "Describe Proposed or Completed Operation" $filename_p|cut -d '"' -f4|cut -d ":" -f1|awk '{$1=$1;print}'`
desc_val=`sed -n $v_desc $filename_p|cut -c 7-250|tr -s "\n" ", "|awk '{$1=$1;print}'|sed 's/.$//'`




echo "$type_of_well_nm""|""$o_type_well_value"   ## 1.
echo "2. ""$operator_nm""|""$operator_nm_val_1 $operator_nm_val_2"  ## 2.
echo "3. ""$addr_operator""|""$addr_operator_val"  ## 3.
echo "$location_nm""|""$loc_nm_val_1 $loc_nm_val_2"  ## 4.
echo "$lease_sl_nm""|""$lease_sl_val"         ## 5.
echo "$ind_alloc_nm""|""$ind_alloc_val"       ## 6.
echo "$unit_nm""|""$unit_val"                 ## 7.
echo "$well_num_nm""|""$type_well_value"      ## 8.
echo "9. ""$API_well_nm""|""$API_well_val"    ## 9.
echo "$pool_nm""|""$pool_num_val"             ## 10.
echo "$country_nm""|""$country_value"         ## 11.
echo "$chk_ful_nm""|(""$chk_box_val_1""/"$chk_box_val_2")"    ## 12.
echo "$desc_nm""|""$desc_val"                 ## 13.


echo "$type_of_well_nm"",""$o_type_well_value"   > $output_filename
echo "2. ""$operator_nm"",""$operator_nm_val_1 $operator_nm_val_2"  >> $output_filename
echo "3. ""$addr_operator"",""$addr_operator_val" >> $output_filename  
echo "$location_nm"",""$loc_nm_val_1 $loc_nm_val_2" >> $output_filename  
echo "$lease_sl_nm"",""$lease_sl_val" >> $output_filename         
echo "$ind_alloc_nm"",""$ind_alloc_val" >> $output_filename       
echo "$unit_nm"",""$unit_val" >> $output_filename                 
echo "$well_num_nm"",""$type_well_value" >> $output_filename      
echo "9. ""$API_well_nm"",""$API_well_val" >> $output_filename    
echo "$pool_nm"",""$pool_num_val" >> $output_filename             
echo "$country_nm"",""$country_value" >> $output_filename         
echo "$chk_ful_nm"",(""$chk_box_val_1""/"$chk_box_val_2")" >> $output_filename   
echo "$desc_nm"",""$desc_val" >> $output_filename


