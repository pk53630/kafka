#!/usr/local/bin/python3

import sys
import configparser
import os, time, smtplib, socket, datetime
from email.mime.text import MIMEText
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import pandas as pd
import numpy as np
import json
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
from datetime import datetime, timedelta
import cx_Oracle
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re
import email.utils
import email
from email.mime.multipart import MIMEMultipart

dt=arrow.now().format('YYYYMMDD')
filename="""/home/odmbatch/odm/logs/DAILY_DATA_COUNT_CHECKS_"""+dt+""".log"""

my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    #print("file is not present")
    Path(filename).touch()

log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("##################################### DAILY DATA COUNT CHECKS STARTED ##########################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")



try:
            pd.options.display.max_colwidth = 1000

            esconfigfilename = '/home/odmbatch/odm/Scripts/ece_es_credentials.ini'
            config = configparser.ConfigParser()
            config.read(esconfigfilename)

            es_search_conf = config['FIELDOPSESSTAGE']
            print(es_search_conf)
            host_name = es_search_conf['HostName']
            print(host_name)
            time_out = int( es_search_conf['Timeout'])
            print(time_out)
            user = es_search_conf['User']
            print(user)
            password = es_search_conf['Password']
            print(password)
            certs =  es_search_conf['VerifyCerts']
            print(certs)
            header = es_search_conf['Header']
            print(header)
            h = { "Content-type":"application/json" }

            configfilename = '/home/odmbatch/ifacility/es_ifacility_value_list.ini'
            print(configfilename)

            es_index_list = [configfilename]
            resultlist =[]


            subject = 'Facility Value List ES Process'

            for configfilename in es_index_list:
                try:
                    config = configparser.ConfigParser()
                    config.read(configfilename)

                    #ES email
                    es_email_conf = config['EMAIL']
                    sender = es_email_conf['EmailFrom']
                    recipients = es_email_conf['EmailTo']

                    #ES Index Settings to set shards and replicas
                    index_settings = {}
                    index_settings['settings'] = {}

                    for key, val in config.items('ESINDEXBODY'):
                                index_settings['settings'][key] = val
                    #print(index_settings)


                    #ES index details
                    es_index_conf = config['ESINDEXDETAILS']
                    alias_name = es_index_conf['AliasName']
                    #index_name = datetime.datetime.now().strftime('{0}_%H_%M_%d_%m_%Y'.format(alias_name))
                    index_name='ifacility_asset_changes'
                    print(index_name)
                    type_name = es_index_conf['TypeName']
                    ignore =  int(es_index_conf['Ignore'])
                    nested_index = es_index_conf['NestedIndex']
                    index_id = es_index_conf['IndexFieldId']
                    bulk_push_size = int(es_index_conf['BulkPushSize'])
                    refresh_interval = es_index_conf['RefreshInterval']
                    field_mappings = es_index_conf['IndexFieldMappings']
                    field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
                    field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))

                    #print(field_mappings_dict)

                    #ES mapping
                    es_mapping_conf = config['ELASTICTEMPLATE']
                    mapping_file = es_mapping_conf['MappingFile']
                    with open('{0}'.format(mapping_file), 'r') as mappingFile:
                            mappings = mappingFile.read()
		   

                    dtd=arrow.now().format('YYYY-MM-DD') 
                    dts=arrow.now().format('hh:m:ss')
                    curr_dts=dtd+"T"+dts+"-00:00"
                    print(curr_dts)
                    					
                    d=datetime.strftime(datetime.now() - timedelta(1), '%Y-%m-%d')
                    dY=(d+"T00:00:00-00:00")
                    print(dY)

                    es = Elasticsearch(
                        hosts = host_name,#esdatanodes
                        timeout = time_out, # increase timeout from default 10s to 120s
                        http_auth=(user,password),
                        verify_certs=certs,
                        headers = h
                              )
                    print(es)

                    if es.indices.exists(index_name):
                        print('Index eixsts')
                        try:
                            #res = es.search(index="ifacility_asset_changes", body={"query": {"range" : {"object.updateTs" : {"gte": dY}}}})
                            res = es.search(index="ifacility_asset_changes", body={
                                                         "_source": [
                                                         "object.updateTs",
                                                         "assetId",
                                                         "object.barcode",
                                                         "object.propertyId"
                                                                    ],
                                                             "size": 10000,
                                                             "query": {
                                                             "bool": {
                                                             "must": [
                                                                     {
                                                                     "range": {
                                                                     "object.updateTs": {
                                                                     "gte": dY,
                                                                     "lte": curr_dts
                                                                                        }
                                                                                }
                                                                      },
                                                                     {
                                                             "exists": {
                                                             "field": "object.propertyId"
                                                                        }
                                                                     }
                                                                         ]
                                                                         }
                                                                           },
                                                             "sort" : [
                                                                 {"object.updateTs" : {"order" : "desc"}}
                                                                       ]
                                                             })
                            #res
                            #print(res)
                            x="%d" % res['hits']['total']
                            print(x)
                            #print("%d documents found" % res['hits']['total'])
                            #for doc in res['hits']['hits']:
                            #    print("%s) %s" % (doc['_id'], doc['_source']['updateTs']))

                            with open("/home/odmbatch/odm/Scripts/ifile.txt", "w") as f: 
                                f.write(str(res))
                        except Exception as e:
                            print(e)

                except Exception as e:
                    print(e)

						
except Exception as e:
    print(e)						

v_Asset_counts="""select count(*) as v_Asset_counts from( select a.*,pa.property_id,pa.update_ts 
from im_dba.im_asset a, im_dba.im_property_asset pa where a.asset_id=pa.asset_id and (pa.update_ts >sysdate-1 or a.update_ts>sysdate-1))"""

v_ifacilities="""SELECT COUNT (*) as v_ifacilities FROM ifac_dba.ifac_schematic WHERE update_ts > SYSDATE - 1"""

v_iTrack="""SELECT COUNT (*) as v_iTrack FROM im_dba.ea_assoc WHERE update_ts > SYSDATE - 1"""

v_assoc_cnt="""
select count(*) as v_assoc_cnt from (
select (connection_guid), itrack_assoc_id, start_date, CASE WHEN end_date = to_date('12/31/3999','MM/DD/YYYY') THEN NULL ELSE end_date END end_date,'iFac'
from ifac_dba.ifac_schematic where schematic_layer = 'SE' and update_ts>'15-JUN-2019'
minus
select (assoc_guid), assoc_id, start_dt, end_dt ,'iFac' from im_dba.ea_assoc  where update_ts>'15-JUN-2019'
union
select assoc_guid, assoc_id, start_dt, end_dt ,'iTrack' from im_dba.ea_assoc  where update_ts>'15-JUN-2019'
Minus
select connection_guid, itrack_assoc_id, start_date, CASE WHEN end_date = to_date('12/31/3999','MM/DD/YYYY') THEN NULL ELSE end_date END end_date,'iTrack'
from ifac_dba.ifac_schematic where schematic_layer = 'SE' and update_ts>'15-JUN-2019')"""

v_asset_cnt = """select count(*) as v_asset_cnt from (
SELECT 
 distinct      p.asset_id,
       p.op_status_cd,
       k.property_name     current_property_name
  FROM im_dba.im_property_asset          p,
       ke_dba.ke_property                k,
       ke_dba.ke_property                kh,
       im_dba.im_property_asset_history  h
 WHERE     p.asset_id = h.asset_id
       AND p.property_id = k.property_id
       AND h.property_id = kh.property_id
       AND p.asset_id IN (SELECT asset_id
                            FROM im_dba.im_property_asset_history
                           WHERE update_ts > '15-JUN-2019'))"""

v_Attr_Values_cnt = """select count(*) as v_Attribute_Values_cnt from (                           
Select k.property_name,k.property_id,v.asset_id,v.attribute_id,a.attribute_name,v.value_list_entry_id,e.short_text_value,v.update_ts from im_dba.im_asset_attribute_value v,im_dba.im_attribute a,im_dba.im_value_list L ,im_dba.im_value_list_entry e,im_dba.im_asset ma,
im_property_asset pa,ke_dba.ke_property k
where v.attribute_id=a.attribute_id and v.value_list_entry_id=e.value_list_entry_id and e.value_list_id=l.value_list_id and v.ASSET_ID = ma.ASSET_ID and v.ASSET_ID = pa.ASSET_ID and pa.PROPERTY_ID = k.PROPERTY_ID
and v.update_ts>sysdate-1 order by v.update_ts desc)"""						   
						   
v_facility_cnt = """
select case when stg1.v_facility_cnt1=stg2.v_facility_cnt1 then 0 else stg1.v_facility_cnt1 end as v_facility_cnt from 
(select count(*) as v_facility_cnt1 from IM_DBA.IM_SITE  where update_ts>sysdate-1) stg1,
(SELECT count(*) as v_facility_cnt1 FROM fdm_dba.fdm_facility where itrack_site_id in (select site_id from IM_DBA.IM_SITE  where update_ts>sysdate-1)) stg2
"""

v_site_well_cnt = """select count(*) as v_site_well_cnt from (
Select  s.site_name,k.property_name ,k.property_id,k.division_id 
from  im_dba.im_site s,im_site_property p,ke_dba.ke_property k 
where s.site_id=p.site_id and p.property_id=k.property_id and k.primo_property_type='WELL' and p.update_ts>'15-JUN-2019')"""

v_site_facility_cnt = """select count(*) as v_site_facility_cnt from (
select  f.facility_name,w.well_name,w.primo_id,w.division_id,w.well_id 
from fdm_dba.fdm_facility f, fdm_dba.fdm_fac_well_xref x,odm_info.odm_well w 
where f.facility_id=x.facility_id and x.well_id=w.well_id  
and x.update_ts>'15-JUN-2019' and x.facility_context='REGULATORY')"""

v_site_unit_cnt = """select count(*) as v_site_unit_cnt from (
Select  s.site_name,k.property_name ,k.property_id,k.division_id 
from  im_dba.im_site s,im_site_property p,ke_dba.ke_property k 
where s.site_id=p.site_id and p.property_id=k.property_id and k.primo_property_type='OIL '||chr(38)||' GAS FACILITY' 
and p.update_ts>'15-JUN-2019')"""


v_facility_unit_cnt = """select count(*) as v_facility_unit_cnt from (
select  f.facility_name,uf.unit_facility_name,uf.primo_id,uf.division_id 
from fdm_dba.fdm_facility f, fdm_dba.fdm_UNIt_fac_xref x,fdm_dba.fdm_unit_facility uf 
where f.facility_id=x.facility_id and x.unit_facility_id=uf.unit_facility_id  
and x.update_ts>'15-JUN-2019' and x.facility_context='REGULATORY')"""


connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
#connection = cx_Oracle.connect('odm_dba/R1dba_101@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)

cursor.execute(v_Asset_counts)
result1 = cursor.fetchall()
print (result1[0][0])
logger.info("Asset Count Query - "+v_Asset_counts+" :")
logger.info("Asset Count Query Result - "+str(result1[0][0]))
logger.info("                                                                                                                ")


cursor.execute(v_ifacilities)
result2 = cursor.fetchall()
print (result2[0][0])
logger.info("ifacilities Query - "+v_ifacilities+" :")
logger.info("ifacilities Query Result - "+str(result2[0][0]))
logger.info("                                                                                                                ")


cursor.execute(v_iTrack)
result3 = cursor.fetchall()
print (result3[0][0])
logger.info("iTrack Query - "+v_iTrack+" :")
logger.info("iTrack Query Result - "+str(result3[0][0]))
logger.info("                                                                                                                ")

cursor.execute(v_assoc_cnt)
result4 = cursor.fetchall()
print (result4[0][0])
logger.info("Assco Query - "+v_assoc_cnt+" :")
logger.info("Assco Query Result - "+str(result4[0][0]))
logger.info("                                                                                                                ")


cursor.execute(v_asset_cnt)
result5 = cursor.fetchall()
print (result5[0][0])
logger.info("Asset Query - "+v_asset_cnt+" :")
logger.info("Asset Query Result - "+str(result5[0][0]))
logger.info("                                                                                                                ")


cursor.execute(v_Attr_Values_cnt)
result6 = cursor.fetchall()
print (result6[0][0])
logger.info("Attribute Value Query - "+v_Attr_Values_cnt+" :")
logger.info("Attribute Value Query Result - "+str(result6[0][0]))
logger.info("                                                                                                                ")


cursor.execute(v_facility_cnt)
result7 = cursor.fetchall()
print (result7[0][0])
logger.info("iFacility Query - "+v_facility_cnt+" :")
logger.info("iFacility Query Result - "+str(result7[0][0]))
logger.info("                                                                                                                ")


cursor.execute(v_site_well_cnt)
result8 = cursor.fetchall()
print (result8[0][0])
logger.info("Site Well Query - "+v_site_well_cnt+" :")
logger.info("Site Well Query Result - "+str(result8[0][0]))
logger.info("                                                                                                                ")


cursor.execute(v_site_facility_cnt)
result9 = cursor.fetchall()
print (result9[0][0])
logger.info("Site Facility Query - "+v_site_facility_cnt+" :")
logger.info("Site Facility Query Result - "+str(result9[0][0]))
logger.info("                                                                                                                ")


cursor.execute(v_site_unit_cnt)
result10 = cursor.fetchall()
print (result10[0][0])
logger.info("Site Unit Query - "+v_site_unit_cnt+" :")
logger.info("Site Unit Query Result - "+str(result10[0][0]))
logger.info("                                                                                                                ")


cursor.execute(v_facility_unit_cnt)
result11 = cursor.fetchall()
print (result11[0][0])
logger.info("Facility Unit Query - "+v_facility_unit_cnt+" :")
logger.info("Facility Unit Query Result - "+str(result11[0][0]))
logger.info("                                                                                                                ")


cursor.close()
connection.close()

logger.info("                                                                                                                ")
logger.info("                                                                                                                ")
logger.info("##################################### Oracle Connection is Closed ##############################################")
logger.info("                                                                                                                ")

me = "Praveen_Kshirsagaray@eogresources.com"
you = "Praveen_Kshirsagaray@eogresources.com,Haritha_Atluri@eogresources.com,Radhika_Tati@eogresources.com"

# Create message
msg = MIMEMultipart('alternative')
msg['Subject'] = """Daily Data Counts Check as on """+dt
msg['From'] = me
msg['To'] = you

# Create the body


text = """Hi Team, 
"""+"""\n"""+"""
This is Daily Data Counts Check report :"""+"""\n"""+"""
 
Ifac Schematic Count - """+str(result1[0][0])+"""
Ea Assoc Count       - """+str(result1[0][0])+"""
Assest Count         - """+str(result2[0][0])+"""\n"""+"""

Regards,
ODM support team,"""

html = """\
<html>
  <head></head>
  <body>
    <p>Hi Team,<br>
       <br>
       This is Daily Data Counts Check report :<br>
           <br>
           Asset counts : <br>
           IM Asset and IM Property Asset Count - """+str(result1[0][0])+"""<br>
           <br>
           Elastic Search ifacility_asset_changes Count - """+str(x)+"""<br>
           <br>
           Association counts : <br>
           ifacilities Count - """+str(result2[0][0])+"""<br>
           iTrack Count - """+str(result3[0][0])+"""<br>
           Assco Count - """+str(result4[0][0])+"""<br>
           <br>
           Currect property name of the asset  due to transfer/RFME :<br>
           Asset Count - """+str(result5[0][0])+"""<br>
           <br>
           Attribute Values Count - """+str(result6[0][0])+"""<br>
           <br>
           SITE - FACILITY discrepancy :<br>
           Site Facility Count - """+str(result7[0][0])+"""<br>
           <br>
           Site - Property :<br>
           Site well Count - """+str(result8[0][0])+"""<br>
           Facility Well Count - """+str(result9[0][0])+"""<br>
           <br>
           Site - Unit facility :<br>
           Site Unit Count - """+str(result10[0][0])+"""<br>
           Facility Unit Count - """+str(result11[0][0])+"""<br>
	   <br>
           <br>
	   Regards,<br>
	   ODM Support team,<br>
    </p>
  </body>
</html>
"""







# Record the MIME types of both parts - text/plain and text/html.
part1 = MIMEText(text, 'plain')
part2 = MIMEText(html, 'html')

# the HTML message, is best and preferred.
msg.attach(part1)
msg.attach(part2)

s = smtplib.SMTP('smtp.eogresources.com')
s.sendmail(me, you, msg.as_string())
s.quit()

logger.info("##################################### Email is trigerd to desination ###########################################")
logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("##################################### DAILY DATA COUNT CHECKS COMPLETED ########################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")
logger.info("                                                                                                                ")

