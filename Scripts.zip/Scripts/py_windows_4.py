#!/usr/bin/python3

import csv
import sys
import os
import cx_Oracle
import datetime



connection = cx_Oracle.connect('iprod_dba/Test_123@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)

data = [
    [60, "Parent 60",1231],
    [70, "Parent 70",2131],
    [80, "Parent 80",2131],
    [90, "Parent 90",1231],
    [100, "Parent 100",123]
]
 
cursor.executemany("""
        insert into iprod_dba.test_orcl (id, name)
        values (:1, :2)""", data)


cursor.execute("""commit""")


cursor.close()
connection.close()

