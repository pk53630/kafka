#!/usr/bin/python3

import re
from collections import Counter


lst=[]
with open('/home/odmbatch/odm/Scripts/assesment_1.csv', "r") as file:
    for k,line in enumerate(file):
        #print(k)
        #dic="a_"+str(k)+"={}"
        #print(dic)
        line = line.rstrip("\n")
        line_s=line.split(',')
        print(line)
        #print(line_s)
        for j in range(0,len(line_s)-1):
            ptrn=line_s[j]+','+line_s[j+1]
            lst.append(ptrn)


#print(lst)
a = dict(Counter(lst))
print(a)
