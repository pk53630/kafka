#!/bin/sh

YR=$1
DIV=$2
TYPE=$3

#echo $YR
#echo $DIV
#echo $TYPE

sqlplus -s fdm_dba/Test_123@r1date.eogresources.com <<EOF
set feedback off trimspool on 
set lines 5000;
set pages 5000;
spool /home/odmbatch/odm/Scripts/sqlite_memsql_prod_tgt_data_$1_$2.csv;


set serveroutput on;
execute LOAD_IN_OUT_YEAR_PKG.IN_OUT_YEAR($1,'$2','$3');
--select sysdate from dual;
spool off;
exit;
EOF


sh /home/odmbatch/odm/Scripts/sqlite_memsql_prod_tgt_data_$1_$2.sh

while [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
   sleep 10
   exit 0
done


