#!/usr/bin/sh

filename=$1
fileout=$2
filename_p="/home/odmbatch/odm/Scripts/""$filename"
output_filename="/home/odmbatch/odm/Scripts/""$fileout"

type_of_well=`grep -n "Type of Well" $filename_p|cut -d ":" -f1`
#echo $type_of_well
value_well=`expr $type_of_well + 2`
v_key_well=`echo $type_of_well"p"`
v_value_well=`echo "$value_well""p"`
type_well=`sed -n $v_key_well $filename_p|awk '{$1=$1;print}'|cut -d ":" -f1`
well_number=`sed -n $v_key_well $filename_p|awk '{$1=$1;print}'|cut -d ":" -f2|awk '{$1=$1;print}'`
type_well_value=`sed -n $v_value_well $filename_p|awk '{$1=$1;print}'|cut -d " " -f1`
well_number_value=`sed -n $v_value_well $filename_p|awk '{$1=$1;print}'|cut -d " " -f2`


name_of_oper=`grep -n "Name of Operator" $filename_p|cut -d ":" -f1`
value_name=`expr $name_of_oper + 2`
v_value_name=`echo "$value_name""p"`
nm_operator=`grep -n "Name of Operator" $filename_p|cut -d ":" -f2|awk '{$1=$1;print}'|cut -d "." -f2|awk '{$1=$1;print}'|sed 's/.$//'`
ogrid_num=`grep -n "Name of Operator" $filename_p|cut -d ":" -f2|awk '{$1=$1;print}'|cut -d "." -f3|awk '{$1=$1;print}'`
nm_operator_val=`sed -n $v_value_name $filename_p|head -c 70|awk '{$1=$1;print}'`
ogrid_num_val=`sed -n $v_value_name $filename_p|tail -c 50|awk '{$1=$1;print}'`


addr_oper=`grep -n "Address of Operator" $filename_p|cut -d ":" -f1`
value_addr=`expr $addr_oper + 2`
v_value_addr=`echo "$value_addr""p"`
addr_operator=`grep -n "Address of Operator" $filename_p|cut -d ":" -f2|awk '{$1=$1;print}'|cut -d "." -f2|awk '{$1=$1;print}'|sed 's/.$//'|sed 's/.$//'`
pool_nm=`grep -n "Address of Operator" $filename_p|cut -d ":" -f2|awk '{$1=$1;print}'|cut -d "." -f3|awk '{$1=$1;print}'`
addr_operator_val=`sed -n $v_value_addr $filename_p|head -c 70|awk '{$1=$1;print}'`
pool_num_val=`sed -n $v_value_addr $filename_p|tail -c 1|awk '{$1=$1;print}'`

well_loc_nm=`grep -n "Well Location" $filename_p|cut -d ":" -f2`
well_loc=`grep -n "Well Location" $filename_p|cut -d ":" -f1`
value_well_low=`expr $well_loc + 2`
value_well_high=`expr $well_loc + 4`
v_value_well=`echo "$value_well_low"",""$value_well_high""p"`
well_loc_val=`sed -n $v_value_well $filename_p`


indicate=`grep -in "Indicate Type of Lease" $filename_p|cut -d ":" -f2|awk '{$1=$1;print}'`
indicate_num=`grep -in "Indicate Type of Lease" $filename_p|cut -d ":" -f1`
indicate_n=`expr $indicate_num + 6`
v_indicate_num=`echo "$indicate_n""p"`
indicate_value=`sed -n $v_indicate_num $filename_p|tail -c 10|awk '{$1=$1;print}'`

state_oil_gas=`grep -in "State Oil & Gas Lease No" $filename_p|cut -d ":" -f2|awk '{$1=$1;print}'`
state_oil_gas_num=`grep -in "State Oil & Gas Lease No" $filename_p|cut -d ":" -f1`
state_oil_gas_n=`expr $state_oil_gas_num + 6`
v_state_oil_gas_name=`echo "$state_oil_gas_n""p"`
state_oil_gas_value=`sed -n $v_state_oil_gas_name $filename_p|tail -c 1|awk '{$1=$1;print}'`


unit_nm=`grep -in "Lease Name or Unit Agreement Name" $filename_p|cut -d ":" -f2|awk '{$1=$1;print}'`
unit_nm_num=`grep -in "Lease Name or Unit Agreement Name" $filename_p|cut -d ":" -f1`
unit_nm_n=`expr $unit_nm_num + 2`
v_unit_nm=`echo "$unit_nm_n""p"`
unit_nm_value=`sed -n $v_unit_nm $filename_p|tail -c 50|awk '{$1=$1;print}'`

elevation_nm=`grep -in "Elevation (Show whether DR, KB, BT, GR, etc.)" $filename_p|cut -d ":" -f2|awk '{$1=$1;print}'`
elevation=`grep -in "Elevation (Show whether DR, KB, BT, GR, etc.)" $filename_p|cut -d ":" -f1`
elevation_loc=`expr $elevation + 2`
v_elevation_loc=`echo "$elevation_loc""p"`
elevation_val=`sed -n $v_elevation_loc $filename_p|awk '{$1=$1;print}'`

chk_box=`grep -in "Check Appropriate Box to Indicate Nature of Notice, Report or Other Data" $filename_p|cut -d ":" -f2|awk '{$1=$1;print}'`
chk_box_num=`grep -in "Check Appropriate Box to Indicate Nature of Notice, Report or Other Data" $filename_p|cut -d ":" -f1`
chk_box_low=`expr $chk_box_num + 2`
chk_box_high=`expr $chk_box_num + 10`
v_chk_box=`echo "$chk_box_low"","$chk_box_high"p"`
chk_box_val=`sed -n $v_chk_box $filename_p`

desc_operation=`grep -in "Describe proposed or completed operations" $filename_p|cut -d ":" -f2`
desc_operation_num=`grep -in "Describe proposed or completed operations" $filename_p|cut -d ":" -f1`
value_desc_low=`expr $desc_operation_num + 3`
value_desc_high=`expr $desc_operation_num + 22`
v_value_desc=`echo "$value_desc_low"","$value_desc_high"p"`
desc_oper_val=`sed -n $v_value_desc $filename_p`


echo "$type_well""|""$type_well_value" > $output_filename ## 1.
echo "2. ""$nm_operator""|""$nm_operator_val" >> $output_filename ## 2.
echo "3. ""$addr_operator""|""$addr_operator_val" >> $output_filename ## 3.
echo "$well_loc_nm""|""$well_loc_val" >> $output_filename ## 4.
echo "$indicate""|""$indicate_value" >> $output_filename ## 5.
echo "$state_oil_gas""|""$state_oil_gas_value" >> $output_filename ## 6.
echo "$unit_nm""|""$unit_nm_value" >> $output_filename  ## 7.
echo "$well_number""|""$well_number_value" >> $output_filename ## 8.
echo "9. ""$ogrid_num""|""$ogrid_num_val" >> $output_filename  ## 9.
echo "10. ""$pool_nm""|""$pool_num_val" >> $output_filename  ## 10.
echo "$elevation_nm""|""$elevation_val" >> $output_filename  ## 11.
echo "$chk_box""|""$chk_box_val" >> $output_filename  ## 12.
echo "$desc_operation""|""$desc_oper_val" >> $output_filename  ## 13.






