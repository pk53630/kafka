#!/usr/bin/python3
import sys
import os
import cx_Oracle
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re

query=""" 
SELECT --p.property_id,
distinct      p.asset_id,
       p.op_status_cd,
       k.property_name     current_property_name,
       case when v.update_ts between sysdate-1 and sysdate then v.date_value else NULL end as date_value,
                   case when v.update_ts between sysdate-1 and sysdate then v.number_value else NULL end as number_value,
                   case when v.update_ts between sysdate-1 and sysdate then v.value_list_entry_id else NULL end as value_list_entry_id
     --  kh.property_name,
      -- h.*
  FROM im_dba.im_property_asset          p,
       ke_dba.ke_property                k,
       ke_dba.ke_property                kh,
       im_dba.im_property_asset_history  h,
       im_dba.im_asset_attribute_value v
WHERE     p.asset_id = h.asset_id
       AND p.property_id = k.property_id
       AND h.property_id = kh.property_id
       AND p.asset_id = v.asset_id(+)
       and trunc(h.update_ts) > '15-JUN-2019'
"""

connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(query)

data_list=[]
column_names =[]

	
for row in cursor.fetchall():
    data_list.append(list(row))


cursor.close()
connection.close()


for i in range(0,len(data_list)):
    x=data_list[i][0]
    y=data_list[i][2]
    print(str(x) + " -- " + y)


