#!/usr/bin/python3
import re

#file = open('/home/odmbatch/odm/Scripts/assesment.csv', 'r')
#b=file.read()

#print (b)

dic_pa={}
file = open('/home/odmbatch/odm/Scripts/assesment_1.csv', 'r')
#b=file.read()
a=file.readline().split(',')
ptrn=a[0]+','+a[1]

print(ptrn)


pattern = re.compile(ptrn)

for i, line in enumerate(open('/home/odmbatch/odm/Scripts/assesment_1.csv')):
    for match in re.finditer(pattern, line):
        #print ('Found on line %s: %s' % (i+1, match.group()))
        mt_key=match.group()
        mt_val=i+1


#print(mt_key)
#print(mt_val)
dic_pa[mt_key]=mt_val
print(dic_pa)
#file.close
