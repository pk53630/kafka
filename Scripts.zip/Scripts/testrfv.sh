#!/usr/bin/sh

filename=$1
fileout=$2
filename_p="/home/odmbatch/odm/Scripts/""$filename"
output_filename="/home/odmbatch/odm/Scripts/""$fileout"



type_of_well=`grep -n "Well Name and No" $filename_p|cut -d ":" -f1`

type_of_well_nm='Type of Well'
well_nm='Well Name and No.'

value_well=`expr $type_of_well + 2`
v_value_well=`echo "$value_well""p"`



type_well_value=`sed -n $v_value_well $filename_p|cut -d '"' -f4|head -c 70|awk '{$1=$1;print}'`
#echo "$type_well_value"

if [ "$type_well_value" == "" ]
then
 value_well=`expr $type_of_well + 4`
 v_value_well=`echo "$value_well""p"`
 type_well_value=`sed -n $v_value_well $filename_p|cut -d '"' -f4|head -c 70|awk '{$1=$1;print}'`
 #echo "$type_well_value"

 y=`echo "$type_well_value"|tr -s "<U+25A1>" "-"`
 #echo $y

 oil_idx=`expr index "$y" 'i'`
 gas_idx=`expr index "$y" 'a'`
 other_idx=`expr index "$y" 't'`

 oil_idx_mark=`expr $oil_idx - 3`
 gas_idx_mark=`expr $gas_idx - 3`
 other_idx_mark=`expr $other_idx - 3`

 oil_marked=`echo $y|head -c $oil_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 gas_marked=`echo $y|head -c $gas_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 other_marked=`echo $y|head -c $other_idx_mark|tail -c 1|awk '{$1=$1;print}'`

 if [ $oil_marked != '-' ]
 then
  type_well_val=`echo ${y:$oil_idx_mark:9}`
 fi

 if [ $gas_marked != '-' ]
 then
  type_well_val=`echo ${y:$gas_idx_mark:9}`
 fi

 if [ $other_marked != '-' ]
 then
  type_well_val=`echo ${y:$other_idx_mark:9}`
 fi

else

 y=`echo "$type_well_value"|tr -s "<U+25A1>" "-"`
 #echo $y

 oil_idx=`expr index "$y" 'i'`
 gas_idx=`expr index "$y" 'a'`
 other_idx=`expr index "$y" 't'`

 oil_idx_mark=`expr $oil_idx - 3`
 gas_idx_mark=`expr $gas_idx - 3`
 other_idx_mark=`expr $other_idx - 3`
 
 oil_marked=`echo $y|head -c $oil_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 echo $oil_marked
 gas_marked=`echo $y|head -c $gas_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 echo $gas_marked
 other_marked=`echo $y|head -c $other_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 echo $other_marked
 
 if [ $oil_marked != '-' ]
 then
  type_well_val=`echo ${y:$oil_idx_mark:9}`
 elif [ $gas_marked != '-' ]
 then
  type_well_val=`echo ${y:$gas_idx_mark:9}`
 elif [ $other_marked != '-' ]
 then
  type_well_val=`echo ${y:$other_idx_mark:9}`
 #else
 # type_well_val=""
 fi

fi
out_type_well_val=`echo "$type_well_val"`
echo $out_type_well_val

