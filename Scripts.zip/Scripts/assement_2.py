#!/usr/bin/python3
import re
from collections import Counter

d={}

myfile="/home/odmbatch/odm/Scripts/assesment_1.csv"
with open('/home/odmbatch/odm/Scripts/assesment_1.csv', "r") as file:
    for k,line in enumerate(file):
        #print(k)
        #dic="a_"+str(k)+"={}"
        #print(dic)
        line = line.rstrip("\n")
        line_s=line.split(',')
        print(line)
        #print(line_s)
        for j in range(0,len(line_s)-1):
            ptrn=line_s[j]+','+line_s[j+1]
            #print(ptrn)
            pattern = re.compile(ptrn)
            #print(pattern)
            with open(myfile) as f:
                contents = f.read()
                count = contents.count("a,b")
                #with open('/home/odmbatch/odm/Scripts/assesment_1.csv', 'r') as f:
                #for line in f.readlines():
                #    words = ptrn
                #    print(words)
                #    for word in line:
                #        count=1
                #        if word == ptrn:
                #            count += 1

            print(count) 
            #for i, line in enumerate(open('/home/odmbatch/odm/Scripts/assesment_1.csv')):
            #    for match in re.finditer(pattern, line):
            #        mt_key=match.group()
                     
                    #print(mt_key)
		
            #d[mt_key]=mt_val
            #print(d)
        #print(d)



#dic_pa[mt_key]=mt_val
#print(dic_pa)
