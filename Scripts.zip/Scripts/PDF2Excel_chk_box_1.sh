#!/usr/bin/sh

filename=$1
fileout=$2
filename_p="/home/odmbatch/odm/Scripts/""$filename"
output_filename="/home/odmbatch/odm/Scripts/""$fileout"


#filename_p="/home/odmbatch/odm/Scripts/30015451150000_6_wf.txt"
#filename_p="/home/odmbatch/odm/Scripts/30015451150000_8_wf.txt"
#output_filename="/home/odmbatch/odm/Scripts/30015451150000_8_wf.csv"

type_of_well=`grep -n "Well Name and No" $filename_p|cut -d ":" -f1`

type_of_well_nm='Type of Well'
#type_of_well_nm=`grep -n "Well Name and No" $filename_p|cut -d ":" -f2|cut -d '"' -f4|head -c 50|awk '{$1=$1;print}'`
#echo $type_of_well_nm


well_nm='Well Name and No.'
#well_nm=`grep -n "Well Name and No" $filename_p|cut -d ":" -f2|cut -d '"' -f4|tail -c 50|awk '{$1=$1;print}'`
#echo $well_nm

value_well=`expr $type_of_well + 2`
v_value_well=`echo "$value_well""p"`

v_out_well_nm=`sed -n $v_value_well $filename_p|cut -d '"' -f4|tail -c 6|awk '{$1=$1; print}'`

if [ "$v_out_well_nm" == "Other" ]
then
 value_well_1=`expr $type_of_well + 4`
 v_value_well_1=`echo "$value_well_1""p"`
 well_value=`sed -n $v_value_well_1 $filename_p|cut -d '"' -f4|tail -c 70|awk '{$1=$1;print}'`
 out_well_nm="$well_value"
else
 well_value=`sed -n $v_value_well $filename_p|cut -d '"' -f4|tail -c 70|awk '{$1=$1;print}'`
 out_well_nm=`echo $well_value`
fi




type_well_value=`sed -n $v_value_well $filename_p|cut -d '"' -f4|head -c 70|awk '{$1=$1;print}'`
#echo "$type_well_value"

if [ "$type_well_value" == "" ]
then
 value_well=`expr $type_of_well + 4`
 v_value_well=`echo "$value_well""p"`
 type_well_value=`sed -n $v_value_well $filename_p|cut -d '"' -f4|head -c 70|awk '{$1=$1;print}'`
 #echo "$type_well_value"

 y=`echo "$type_well_value"|tr -s "<U+25A1>" "-"`
 #echo $y

 oil_idx=`expr index "$y" 'i'`
 gas_idx=`expr index "$y" 'a'`
 other_idx=`expr index "$y" 't'`

 oil_idx_mark=`expr $oil_idx - 3`
 gas_idx_mark=`expr $gas_idx - 3`
 other_idx_mark=`expr $other_idx - 3`

 oil_marked=`echo $y|head -c $oil_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 gas_marked=`echo $y|head -c $gas_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 other_marked=`echo $y|head -c $other_idx_mark|tail -c 1|awk '{$1=$1;print}'`

 if [ $oil_marked != '-' ]
 then
  type_well_val=`echo ${y:$oil_idx_mark:9}`
 elif [ $gas_marked != '-' ]
 then
  type_well_val=`echo ${y:$gas_idx_mark:9}`
 elif [ $other_marked != '-' ]
 then
  type_well_val=`echo ${y:$other_idx_mark:9}`
 fi

else

 y=`echo "$type_well_value"|tr -s "<U+25A1>" "-"`
 #echo $y

 oil_idx=`expr index "$y" 'i'`
 gas_idx=`expr index "$y" 'a'`
 other_idx=`expr index "$y" 't'`

 oil_idx_mark=`expr $oil_idx - 3`
 gas_idx_mark=`expr $gas_idx - 3`
 other_idx_mark=`expr $other_idx - 3`
 
 oil_marked=`echo $y|head -c $oil_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 gas_marked=`echo $y|head -c $gas_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 other_marked=`echo $y|head -c $other_idx_mark|tail -c 1|awk '{$1=$1;print}'`
 
 if [ $oil_marked != '-' ]
 then
  type_well_val=`echo ${y:$oil_idx_mark:9}`
 elif [ $gas_marked != '-' ]
 then
  type_well_val=`echo ${y:$gas_idx_mark:9}`
 elif [ $other_marked != '-' ]
 then
  type_well_val=`echo ${y:$other_idx_mark:9}`
 fi

fi
out_type_well_val=`echo "$type_well_val"`

chk_boc_no=`grep -n "CHECK THE APPROPRIATE BOX(ES) TO INDICATE NATURE OF NOTICE, REPORT, OR OTHER DATA" $filename_p|cut -d ":" -f1`
#chk_nm=`grep -n "CHECK THE APPROPRIATE BOX(ES) TO INDICATE NATURE OF NOTICE, REPORT, OR OTHER DATA" $filename_p|cut -d '"' -f4|tr -s "," " "|awk '{$1=$1;print}'`
#x="(TYPE OF SUBMISSION / TYPE OF ACTION)"
#chk_ful_nm=`echo "$chk_nm""$x"`
#chk_box_nm=`echo $chk_ful_nm`
chk_box_nm='CHECK THE APPROPRIATE BOX(ES) TO INDICATE NATURE OF NOTICE REPORT OR OTHER DATA(TYPE OF SUBMISSION / TYPE OF ACTION)'

grep "Notice of Intent" $filename_p|cut -d '"' -f4|head -c 50|awk '{$1=$1;print}' > /home/odmbatch/odm/Scripts/tmp_type_submission.txt
grep "Subsequent Report" $filename_p|cut -d '"' -f4|head -c 50|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_submission.txt
grep "Final Abandonment Notice" $filename_p|cut -d '"' -f4|head -c 50|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_submission.txt
z1=`cat /home/odmbatch/odm/Scripts/tmp_type_submission.txt|grep -v "^<U+25A1>"|head -c 20|awk '{$1=$1;print}'`
#echo $z1
chk_box_val_1=`echo ${z1:1}`
chk_box_nm_1=`echo $chk_box_val_1`

v_grep_Acidize='Acidize'
v_grep_Alter_Casing='Alter Casing'
v_grep_Casing_Repair='Casing Repair'
v_grep_Change_Plans='Change Plans'
v_grep_Convert_Injection='Convert to Injection'

v_Acidize_str=`grep "Acidize" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'`
v_grep_Acidize_idx=`awk -v a="$v_Acidize_str" -v b="$v_grep_Acidize" 'BEGIN{print index(a,b)}'`
v_grep_Acidize_1=`expr $v_grep_Acidize_idx - 10`
echo ${v_Acidize_str:v_grep_Acidize_1} > /home/odmbatch/odm/Scripts/tmp_type_action.txt

v_Alter_Casing_str=`grep "Alter Casing" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'`
v_grep_Alter_Casing_idx=`awk -v a="$v_Alter_Casing_str" -v b="$v_grep_Alter_Casing" 'BEGIN{print index(a,b)}'`
v_grep_Alter_Casing_1=`expr $v_grep_Alter_Casing_idx - 10`
echo ${v_Alter_Casing_str:v_grep_Alter_Casing_1} >> /home/odmbatch/odm/Scripts/tmp_type_action.txt

v_Casing_Repair_str=`grep "Casing Repair" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'`
v_grep_Casing_Repair_idx=`awk -v a="$v_Casing_Repair_str" -v b="$v_grep_Casing_Repair" 'BEGIN{print index(a,b)}'`
v_grep_Casing_Repair_1=`expr $v_grep_Casing_Repair_idx - 10`
echo ${v_Casing_Repair_str:v_grep_Casing_Repair_1} >> /home/odmbatch/odm/Scripts/tmp_type_action.txt

v_Change_Plans_str=`grep "Change Plans" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'`
v_grep_Change_Plans_idx=`awk -v a="$v_Change_Plans_str" -v b="$v_grep_Change_Plans" 'BEGIN{print index(a,b)}'`
v_grep_Change_Plans_1=`expr $v_grep_Change_Plans_idx - 10`
echo ${v_Change_Plans_str:v_grep_Change_Plans_1} >> /home/odmbatch/odm/Scripts/tmp_type_action.txt

v_Convert_Injection_str=`grep "Convert to Injection" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'`
v_grep_Convert_Injection_idx=`awk -v a="$v_Convert_Injection_str" -v b="$v_grep_Convert_Injection" 'BEGIN{print index(a,b)}'`
v_grep_Convert_Injection_1=`expr $v_grep_Convert_Injection_idx - 10`
echo ${v_Convert_Injection_str:v_grep_Convert_Injection_1} >> /home/odmbatch/odm/Scripts/tmp_type_action.txt



#grep "Acidize" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}' > /home/odmbatch/odm/Scripts/tmp_type_action.txt
#grep "Alter Casing" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
#grep "Casing Repair" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'|tail -c 77 >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
#grep "Change Plans" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'|tail -c 77 >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
#grep "Convert to Injection" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_action.txt


mark_idx=`cat /home/odmbatch/odm/Scripts/tmp_type_action.txt|sed 's/<U+25A1>/-/g'`
#echo $mark_idx

v_Acidize='Acidize'
v_Acidize_idx=`awk -v a="$mark_idx" -v b="$v_Acidize" 'BEGIN{print index(a,b)}'`
#echo $v_Acidize_idx
v_Acidize_idx_mrk=`expr $v_Acidize_idx - 2`
v_Acidize_mrk=`echo $mark_idx|head -c $v_Acidize_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Acidize_mrk
#echo ${mark_idx:2:8}


v_Deepen='Deepen'
v_Deepen_idx=`awk -v a="$mark_idx" -v b="$v_Deepen" 'BEGIN{print index(a,b)}'`
#echo $v_Deepen_idx
v_Deepen_idx_mrk=`expr $v_Deepen_idx - 2`
v_Deepen_mrk=`echo $mark_idx|head -c $v_Deepen_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Deepen_mrk
#echo ${mark_idx:12:7}

v_Production='Production'
v_Production_idx=`awk -v a="$mark_idx" -v b="$v_Production" 'BEGIN{print index(a,b)}'`
#echo $v_Production_idx
v_Production_idx_mrk=`expr $v_Production_idx - 2`
v_Production_mrk=`echo $mark_idx|head -c $v_Production_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Production_mrk
#echo ${mark_idx:21:26}

v_water_Shut_off='Water Shut-Off'
v_water_Shut_off_idx=`awk -v a="$mark_idx" -v b="$v_water_Shut_off" 'BEGIN{print index(a,b)}'`
#echo $v_water_Shut_off_idx
v_water_Shut_off_idx_mrk=`expr $v_water_Shut_off_idx - 2`
v_water_Shut_off_mrk=`echo $mark_idx|head -c $v_water_Shut_off_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_water_Shut_off_mrk
#echo ${mark_idx:49:15}

v_Alter_Casing='Alter Casing'
v_Alter_Casing_idx=`awk -v a="$mark_idx" -v b="$v_Alter_Casing" 'BEGIN{print index(a,b)}'`
#echo $v_Alter_Casing_idx
v_Alter_Casing_idx_mrk=`expr $v_Alter_Casing_idx - 2`
v_Alter_Casing_mrk=`echo $mark_idx|head -c $v_Alter_Casing_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Alter_Casing_mrk

v_Hydraulic_Fracturing='Hydraulic Fracturing'
v_Hydraulic_Fracturing_idx=`awk -v a="$mark_idx" -v b="$v_Hydraulic_Fracturing" 'BEGIN{print index(a,b)}'`
#echo $v_Hydraulic_Fracturing_idx
v_Hydraulic_Fracturing_idx_mrk=`expr $v_Hydraulic_Fracturing_idx - 2`
v_Hydraulic_Fracturing_mrk=`echo $mark_idx|head -c $v_Hydraulic_Fracturing_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Hydraulic_Fracturing_mrk


v_Reclamation='Reclamation'
v_Reclamation_idx=`awk -v a="$mark_idx" -v b="$v_Reclamation" 'BEGIN{print index(a,b)}'`
#echo $v_Reclamation_idx
v_Reclamation_idx_mrk=`expr $v_Reclamation_idx - 2`
v_Reclamation_mrk=`echo $mark_idx|head -c $v_Reclamation_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Reclamation_mrk


v_Well_Integrity='Well Integrity'
v_Well_Integrity_idx=`awk -v a="$mark_idx" -v b="$v_Well_Integrity" 'BEGIN{print index(a,b)}'`
#echo $v_Well_Integrity_idx
v_Well_Integrity_idx_mrk=`expr $v_Well_Integrity_idx - 2`
v_Well_Integrity_mrk=`echo $mark_idx|head -c $v_Well_Integrity_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Well_Integrity_mrk


v_Casing_Repair='Casing Repair'
v_Casing_Repair_idx=`awk -v a="$mark_idx" -v b="$v_Casing_Repair" 'BEGIN{print index(a,b)}'`
#echo $v_Casing_Repair_idx
v_Casing_Repair_idx_mrk=`expr $v_Casing_Repair_idx - 2`
v_Casing_Repair_mrk=`echo $mark_idx|head -c $v_Casing_Repair_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Casing_Repair_mrk


v_New_Construction='New Construction'
v_New_Construction_idx=`awk -v a="$mark_idx" -v b="$v_New_Construction" 'BEGIN{print index(a,b)}'`
#echo $v_New_Construction_idx
v_New_Construction_idx_mrk=`expr $v_New_Construction_idx - 2`
v_New_Construction_mrk=`echo $mark_idx|head -c $v_New_Construction_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_New_Construction_mrk


v_Recomplete='Recomplete'
v_Recomplete_idx=`awk -v a="$mark_idx" -v b="$v_Recomplete" 'BEGIN{print index(a,b)}'`
#echo $v_Recomplete_idx
v_Recomplete_idx_mrk=`expr $v_Recomplete_idx - 2`
v_Recomplete_mrk=`echo $mark_idx|head -c $v_Recomplete_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Recomplete_mrk


v_Other='Other'
v_Other_idx=`awk -v a="$mark_idx" -v b="$v_Other" 'BEGIN{print index(a,b)}'`
#echo $v_Other_idx
v_Other_idx_mrk=`expr $v_Other_idx - 2`
v_Other_mrk=`echo $mark_idx|head -c $v_Other_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Other_mrk


v_Change_Plans='Change Plans'
v_Change_Plans_idx=`awk -v a="$mark_idx" -v b="$v_Change_Plans" 'BEGIN{print index(a,b)}'`
#echo $v_Change_Plans_idx
v_Change_Plans_idx_mrk=`expr $v_Change_Plans_idx - 2`
v_Change_Plans_mrk=`echo $mark_idx|head -c $v_Change_Plans_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Change_Plans_mrk


v_Plug_Abandon='Plug and Abandon'
v_Plug_Abandon_idx=`awk -v a="$mark_idx" -v b="$v_Plug_Abandon" 'BEGIN{print index(a,b)}'`
#echo $v_Plug_Abandon_idx
v_Plug_Abandon_idx_mrk=`expr $v_Plug_Abandon_idx - 2`
v_Plug_Abandon_mrk=`echo $mark_idx|head -c $v_Plug_Abandon_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Plug_Abandon_mrk


v_Temporarily_Abandon='Temporarily Abandon'
v_Temporarily_Abandon_idx=`awk -v a="$mark_idx" -v b="$v_Temporarily_Abandon" 'BEGIN{print index(a,b)}'`
#echo $v_Temporarily_Abandon_idx


if [ $v_Temporarily_Abandon_idx == 0 ]
then
v_grep_Temp_Abandon='Temporarily Abandon'
v_Temp_Abandon_str=`grep "Temporarily Abandon" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'`
v_grep_Temp_Abandon_idx=`awk -v a="$v_Temp_Abandon_str" -v b="$v_grep_Temp_Abandon" 'BEGIN{print index(a,b)}'`
v_grep_Temp_Abandon_1=`expr $v_grep_Temp_Abandon_idx - 10`
echo ${v_Temp_Abandon_str:v_grep_Temp_Abandon_1} >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
mark_idx=`cat /home/odmbatch/odm/Scripts/tmp_type_action.txt|sed 's/<U+25A1>/-/g'`
fi
v_Temporarily_Abandon_idx2=`awk -v a="$mark_idx" -v b="$v_Temporarily_Abandon" 'BEGIN{print index(a,b)}'`
v_Temporarily_Abandon_idx_mrk=`expr $v_Temporarily_Abandon_idx2 - 2`

v_Temporarily_Abandon_mrk=`echo $mark_idx|head -c $v_Temporarily_Abandon_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Temporarily_Abandon_mrk


v_Convert_Injection='Convert to Injection'
v_Convert_Injection_idx=`awk -v a="$mark_idx" -v b="$v_Convert_Injection" 'BEGIN{print index(a,b)}'`
#echo $v_Convert_Injection_idx
v_Convert_Injection_idx_mrk=`expr $v_Convert_Injection_idx - 2`
v_Convert_Injection_mrk=`echo $mark_idx|head -c $v_Convert_Injection_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Convert_Injection_mrk


v_Plug_Back='Plug Back'
v_Plug_Back_idx=`awk -v a="$mark_idx" -v b="$v_Plug_Back" 'BEGIN{print index(a,b)}'`
#echo $v_Plug_Back_idx
v_Plug_Back_idx_mrk=`expr $v_Plug_Back_idx - 2`
v_Plug_Back_mrk=`echo $mark_idx|head -c $v_Plug_Back_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Plug_Back_mrk


v_Water_Disposal='Water Disposal'
v_Water_Disposal_idx=`awk -v a="$mark_idx" -v b="$v_Water_Disposal" 'BEGIN{print index(a,b)}'`
#echo $v_Water_Disposal_idx
v_Water_Disposal_idx_mrk=`expr $v_Water_Disposal_idx - 2`
v_Water_Disposal_mrk=`echo $mark_idx|head -c $v_Water_Disposal_idx_mrk|tail -c 1|awk '{$1=$1;print}'`
#echo $v_Water_Disposal_mrk

if [ $v_Acidize_mrk != '-' ]
then
v_Acidize_st=`expr $v_Acidize_idx - 1`
v_Acidize_len=`expr $v_Deepen_idx - $v_Acidize_idx - 2`
out_Acidize_1=`echo ${mark_idx:$v_Acidize_st:$v_Acidize_len}`
out_Acidize=`echo "$out_Acidize_1"","`
fi

if [ $v_Deepen_mrk != '-' ]
then
v_Deepen_st=`expr $v_Deepen_idx - 1`
v_Deepen_len=`expr $v_Production_idx - $v_Deepen_idx - 2`
out_Deepen_1=`echo ${mark_idx:$v_Deepen_st:$v_Deepen_len}`
out_Deepen=`echo "$out_Deepen_1"","`
fi

if [ $v_Production_mrk != '-' ]
then
v_Production_st=`expr $v_Production_idx - 1`
v_Production_len=`expr $v_water_Shut_off_idx - $v_Production_idx - 2`
out_Production_1=`echo ${mark_idx:$v_Production_st:$v_Production_len}`
out_Production=`echo "$out_Production_1"","`
fi

if [ $v_water_Shut_off_mrk != '-' ]
then
v_water_Shut_off_st=`expr $v_water_Shut_off_idx - 1`
v_water_Shut_off_len=`expr $v_Alter_Casing_idx - $v_water_Shut_off_idx - 2`
out_water_Shut_off_1=`echo ${mark_idx:$v_water_Shut_off_st:$v_water_Shut_off_len}`
out_water_Shut_off=`echo "$out_water_Shut_off_1"","`
fi

if [ $v_Alter_Casing_mrk != '-' ]
then
v_Alter_Casing_st=`expr $v_Alter_Casing_idx - 1`
v_Alter_Casing_len=`expr $v_Hydraulic_Fracturing_idx - $v_Alter_Casing_idx - 2`
out_Alter_Casing_1=`echo ${mark_idx:$v_Alter_Casing_st:$v_Alter_Casing_len}`
out_Alter_Casing=`echo "$out_Alter_Casing_1"","`
fi

if [ $v_Hydraulic_Fracturing_mrk != '-' ]
then
v_Hydraulic_Fracturing_st=`expr $v_Hydraulic_Fracturing_idx - 1`
v_Hydraulic_Fracturing_len=`expr $v_Reclamation_idx - $v_Hydraulic_Fracturing_idx - 2`
out_Hydraulic_Fracturing_1=`echo ${mark_idx:$v_Hydraulic_Fracturing_st:$v_Hydraulic_Fracturing_len}`
out_Hydraulic_Fracturing=`echo "$out_Hydraulic_Fracturing"","`
fi

if [ $v_Reclamation_mrk != '-' ]
then
v_Reclamation_st=`expr $v_Reclamation_idx - 1`
v_Reclamation_len=`expr $v_Well_Integrity_idx - $v_Reclamation_idx - 2`
out_Reclamation_1=`echo ${mark_idx:$v_Reclamation_st:$v_Reclamation_len}`
out_Reclamation=`echo "$out_Reclamation_1"","`
fi

if [ $v_Well_Integrity_mrk != '-' ]
then
v_Well_Integrity_st=`expr $v_Well_Integrity_idx - 1`
v_Well_Integrity_len=`expr $v_Casing_Repair_idx - $v_Well_Integrity_idx - 2`
out_Well_Integrity_1=`echo ${mark_idx:$v_Well_Integrity_st:$v_Well_Integrity_len}`
out_Well_Integrity=`echo "$out_Well_Integrity_1"","`
fi

if [ $v_Casing_Repair_mrk != '-' ]
then
v_Casing_Repair_st=`expr $v_Casing_Repair_idx - 1`
v_Casing_Repair_len=`expr $v_New_Construction_idx - $v_Casing_Repair_idx - 2`
out_Casing_Repair_1=`echo ${mark_idx:$v_Casing_Repair_st:$v_Casing_Repair_len}`
out_Casing_Repair=`echo "$out_Casing_Repair_1"","`
fi

if [ $v_New_Construction_mrk != '-' ]
then
v_New_Construction_st=`expr $v_New_Construction_idx - 1`
v_New_Construction_len=`expr $v_Recomplete_idx - $v_New_Construction_idx - 2`
out_New_Construction_1=`echo ${mark_idx:$v_New_Construction_st:$v_New_Construction_len}`
out_New_Construction=`echo "$out_New_Construction_1"","`
fi

if [ $v_Recomplete_mrk != '-' ]
then
v_Recomplete_st=`expr $v_Recomplete_idx - 1`
v_Recomplete_len=`expr $v_Other_idx - $v_Recomplete_idx - 2`
out_Recomplete_1=`echo ${mark_idx:$v_Recomplete_st:$v_Recomplete_len}`
out_Recomplete=`echo "$out_Recomplete_1"","`
fi

if [ $v_Other_mrk != '-' ]
then
v_Other_st=`expr $v_Other_idx - 1`
v_Other_len=`expr $v_Change_Plans_idx - $v_Other_idx - 2`
out_Other_1=`echo ${mark_idx:$v_Other_st:$v_Other_len}`

other_line_no=`grep -n "Casing Repair" $filename_p|cut -d ":" -f1`
other_desc_no=`expr "$other_line_no" + 2`
other_desc_nop=`echo "$other_desc_no""p"`
other_notes=`sed -n $other_desc_nop $filename_p|cut -d '"' -f4|tail -c 50|awk '{$1=$1;print}'`
#echo $other_notes
out_Other=`echo "$out_Other_1"" - ""$other_notes"","`

fi

if [ $v_Change_Plans_mrk != '-' ]
then
v_Change_Plans_st=`expr $v_Change_Plans_idx - 1`
v_Change_Plans_len=`expr $v_Plug_Abandon_idx - $v_Change_Plans_idx - 2`
out_Change_Plans_1=`echo ${mark_idx:$v_Change_Plans_st:$v_Change_Plans_len}`
out_Change_Plans=`echo "$out_Change_Plans_1"","`
fi

if [ $v_Plug_Abandon_mrk != '-' ]
then
v_Plug_Abandon_st=`expr $v_Plug_Abandon_idx - 1`
v_Plug_Abandon_len=`expr $v_Temporarily_Abandon_idx - $v_Plug_Abandon_idx - 2`
out_Plug_Abandon_1=`echo ${mark_idx:$v_Plug_Abandon_st:$v_Plug_Abandon_len}`
out_Plug_Abandon=`echo "$out_Plug_Abandon_1"","`
fi

if [ $v_Temporarily_Abandon_mrk != '-' ]
then
v_Temporarily_Abandon_st=`expr $v_Temporarily_Abandon_idx - 1`
v_Temporarily_Abandon_len=`expr $v_Convert_Injection_idx - $v_Temporarily_Abandon_idx - 2`
out_Temporarily_Abandon_1=`echo ${mark_idx:$v_Temporarily_Abandon_st:$v_Temporarily_Abandon_len}`
out_Temporarily_Abandon=`echo "$out_Temporarily_Abandon_1"","`
fi

if [ $v_Convert_Injection_mrk != '-' ]
then
v_Convert_Injection_st=`expr $v_Convert_Injection_idx - 1`
v_Convert_Injection_len=`expr $v_Plug_Back_idx - $v_Convert_Injection_idx - 2`
out_Convert_Injection_1=`echo ${mark_idx:$v_Convert_Injection_st:$v_Convert_Injection_len}`
out_Convert_Injection=`echo "$out_Convert_Injection_1"","`
fi

if [ $v_Plug_Back_mrk != '-' ]
then
v_Plug_Back_st=`expr $v_Plug_Back_idx - 1`
v_Plug_Back_len=`expr $v_Water_Disposal_idx - $v_Plug_Back_idx - 2`
out_Plug_Back_1=`echo ${mark_idx:$v_Plug_Back_st:$v_Plug_Back_len}`
out_Plug_Back=`echo "$out_Plug_Back_1"","`
fi

if [ $v_Water_Disposal_mrk != '-' ]
then
v_Water_Disposal_st=`expr $v_Water_Disposal_idx - 1`
v_Water_Disposal_len='15'
out_Water_Disposal_1=`echo ${mark_idx:$v_Water_Disposal_st:$v_Water_Disposal_len}`
out_Water_Disposal=`echo "$out_Water_Disposal_1"","`
fi

out_final=`echo "$out_Acidize""$out_Deepen""$out_Production""$out_water_Shut_off""$out_Alter_Casing""$out_Hydraulic_Fracturing""$out_Reclamation""$out_Well_Integrity""$out_Casing_Repair""$out_New_Construction""$out_Recomplete""$out_Other""$out_Change_Plans""$out_Plug_Abandon""$out_Temporarily_Abandon""$out_Convert_Injection""$out_Plug_Back""$out_Water_Disposal"`
chk_box_nm_2=`echo $out_final|sed 's/.$//'`


name_of_oper=`grep -n "Name of Operator" $filename_p|cut -d ':' -f1`
value_name=`expr $name_of_oper + 2`
v_value_name=`echo "$value_name""p"`
operator_nm='Name of Operator'
#operator_nm=`grep -n "Name of Operator" $filename_p|cut -d '"' -f4|head -c 30|awk '{$1=$1;print}'`
API_well_nm='API Well No.'
#API_well_nm=`grep -n "Name of Operator" $filename_p|cut -d '"' -f4|tail -c 30|awk '{$1=$1;print}'`
operator_nm_val_1=`grep -n "Name of Operator" $filename_p|cut -d '"' -f4|head -c 95|tail -c 30|tr -s "," "-"|awk '{$1=$1;print}'`
operator_nm_val_2=`sed -n $v_value_name $filename_p|cut -d '"' -f4|head -c 120|tr -s "," "-"|awk '{$1=$1;print}'`
out_operator_nm=`echo "$operator_nm_val_1"" ""$operator_nm_val_2"`
out_API_well_nm=`sed -n $v_value_name $filename_p|tail -c 60|tr -s "," "-"|awk '{$1=$1;print}'`


addr_oper=`grep -n "Field and Pool or Exploratory" $filename_p|cut -d ":" -f1`
value_addr_low=`expr $addr_oper + 2`
value_addr_high=`expr $addr_oper + 4`
v_value_pool=`echo "$value_addr_low""p"`
v_value_addr=`echo "$value_addr_low"",""$value_addr_high""p"`
addr_operator='Address / Phone No. (include area code)'
#addr_operator=`grep -n "Field and Pool or Exploratory" $filename_p|cut -d '"' -f4|head -c 130|awk '{$1=$1;print}'`
pool_nm='Field and Pool or Exploratory Area'
#pool_nm=`grep -n "Field and Pool or Exploratory" $filename_p|cut -d '"' -f4|tail -c 50|awk '{$1=$1;print}'`
out_pool_nm=`sed -n $v_value_pool $filename_p|cut -d '"' -f4|tail -c 60|tr -s "," "-"|awk '{$1=$1;print}'`
v_addr_operator_1=`sed -n $v_value_addr $filename_p|cut -d '"' -f4|head -1|head -c 60|tr -s "," "-"|awk '{$1=$1;print}'`
v_addr_operator_2=`sed -n $v_value_addr $filename_p|cut -d '"' -f4|tail -1|tail -c 50|tr -s "," "-"|awk '{$1=$1;print}'`
v_addr_operator_3=`sed -n $v_value_addr $filename_p|cut -d '"' -f4|head -1|head -c 100|tail -c 20|tr -s "," "-"|awk '{$1=$1;print}'`
out_addr_operator=`echo "$v_addr_operator_1"" ""$v_addr_operator_2"" / ""$v_addr_operator_3"`



well_loc=`grep -n "Location of Well" $filename_p|cut -d ":" -f1`
country_nm='County or Parish- State'
#country_nm=`grep -n "Location of Well" $filename_p|cut -d '"' -f4|tail -c 70|tr -s "," " "|awk '{$1=$1;print}'`
location_nm='Location of Well (Footage / Sec. / T. / R. / M. / or Survey Description)'
#location_nm=`grep -n "Location of Well" $filename_p|cut -d '"' -f4|head -c 28|awk '{$1=$1;print}'`
value_country_nm=`expr $well_loc + 2`
v_country_nm=`echo $value_country_nm"p"`
out_country_nm=`sed -n $v_country_nm $filename_p|tail -c 70|tr -s "," "-"|awk '{$1=$1;print}'`
loc_nm_val_1=`sed -n $v_country_nm $filename_p|cut -d '"' -f4|head -c 100|tr -s "," "-"|awk '{$1=$1;print}'`
value_loc_nm=`expr $well_loc + 4`
v_loc_nm=`echo "$value_loc_nm""p"`
loc_nm_val_2=`sed -n $v_loc_nm $filename_p|cut -d '"' -f4|tr -s "," "-"|awk '{$1=$1;print}'`
out_location_nm=`echo "$loc_nm_val_1"" ""$loc_nm_val_2"`


lease_sl_no=`grep -n "Lease Serial No" $filename_p|cut -d ":" -f1`
value_lease=`expr $lease_sl_no + 2`
v_value_lease=`echo "$value_lease""p"`
v_lease_sl_nm=`grep -n "Lease Serial No" $filename_p|cut -d '"' -f4|awk '{$1=$1;print}'`
if [ "$v_lease_sl_nm" != "" ]
then
 lease_sl_nm='Lease Serial No.'
 #lease_sl_nm=`echo "$v_lease_sl_nm"`
 out_lease_sl_nm=`sed -n $v_value_lease $filename_p|cut -d '"' -f4|tail -c 40 |tr -s "," "-"|awk '{$1=$1;print}'`
else
 lease_sl_nm="Lease Serial No."
 out_lease_sl_nm=""
fi


ind_alloc_no=`grep -n "If Indian, Allottee or Tribe Name" $filename_p|cut -d ":" -f1`
value_ind_alloc=`expr $ind_alloc_no + 2`
v_ind_alloc=`echo "$value_ind_alloc""p"`
v_ind_alloc_nm=`grep -n "If Indian, Allottee or Tribe Name" $filename_p|cut -d '"' -f4|tail -c 37|awk '{$1=$1;print}'`
if [ "$v_ind_alloc_nm" != "" ]
then
 ind_alloc_nm='If Indian- Allottee or Tribe Name'
 #ind_alloc_nm=`echo "$v_ind_alloc_nm"`
 out_ind_alloc_nm=`sed -n $v_ind_alloc $filename_p|cut -d '"' -f4|cut -d "." -f3|tr -s "," "-"|awk '{$1=$1;print}'`
else
 ind_alloc_nm="If Indian- Allottee or Tribe Name"
 out_ind_alloc_nm=""
fi

unit_no=`grep -n "If Unit or CA/Agreement, Name and/or No" $filename_p|cut -d ":" -f1`
value_unit=`expr $unit_no + 2`
v_unit=`echo "$value_unit""p"`
unit_nm='If Unit or CA/Agreement- Name and/or No.'
#unit_nm=`grep -n "If Unit or CA/Agreement, Name and/or No" $filename_p|cut -d '"' -f4|tail -c 50|tr -s "," " "|awk '{$1=$1;print}'`
v_out_unit_nm=`sed -n $v_unit $filename_p|cut -d '"' -f4|egrep "page 2$|Well Name and No.$"|awk '{$1=$1;print}'`
if [ "$v_out_unit_nm" != "" ]
then
out_unit_nm=""
else
out_unit_nm=`sed -n $v_unit $filename_p|cut -d '"' -f4|tail -c 50|tr -s "," "-"|awk '{$1=$1;print}'`
fi


desc_no_st=`grep -n "determined that the site is ready for final inspection" $filename_p|cut -d ":" -f1`
desc_no_end=`grep -n "hereby certify that the foregoing" $filename_p|cut -d ":" -f1`
value_desc_low=`expr $desc_no_st + 2`
value_desc_high=`expr $desc_no_end - 2`
v_desc=`echo "$value_desc_low"",""$value_desc_high""p"`
desc_nm="Describe Proposed or Completed Operation"
out_desc_nm=`sed -n $v_desc $filename_p|cut -d '"' -f4|tr -s "\n" ", "|tr -s "," "-"|awk '{$1=$1;print}'`


#echo "$type_of_well_nm"",""$out_type_well_val" > $output_filename               ## 1. 
#echo "$operator_nm"",""$out_operator_nm" >> $output_filename               ## 2.
#echo "$addr_operator"",""$out_addr_operator" >> $output_filename           ## 3.
#echo "$location_nm"",""$out_location_nm" >> $output_filename                    ## 4.
#echo "$lease_sl_nm"",""$out_lease_sl_nm" >> $output_filename                    ## 5.
#echo "$ind_alloc_nm"",""$out_ind_alloc_nm" >> $output_filename                  ## 6.
#echo "$unit_nm"",""$out_unit_nm" >> $output_filename                            ## 7. 
#echo "$well_nm"",""$out_well_nm" >> $output_filename                            ## 8.
#echo "$API_well_nm"",""$out_API_well_nm" >> $output_filename                ## 9.
#echo "$pool_nm"",""$out_pool_nm" >> $output_filename                            ## 10.
#echo "$country_nm"",""$out_country_nm" >> $output_filename                      ## 11. 
#echo "$chk_box_nm"",(""$chk_box_nm_1""/""$chk_box_nm_2"")" >> $output_filename  ## 12.
#echo "$desc_nm"",""$out_desc_nm" >> $output_filename                            ## 13.


echo "$type_of_well_nm"",""$operator_nm"",""$addr_operator"",""$location_nm"",""$lease_sl_nm"",""$ind_alloc_nm"",""$unit_nm"",""$well_nm"",""$API_well_nm"",""$pool_nm"",""$country_nm"",""$chk_box_nm","$desc_nm" > $output_filename
echo "$out_type_well_val"",""$out_operator_nm"",""$out_addr_operator"",""$out_location_nm"",""$out_lease_sl_nm"",""$out_ind_alloc_nm"",""$out_unit_nm"",""$out_well_nm"",""$out_API_well_nm"",""$out_pool_nm"",""$out_country_nm"",""$chk_box_nm_1""/""$chk_box_nm_2"",""$out_desc_nm" >> $output_filename




















