#!/usr/bin/python3

import re, collections

myfile="/home/odmbatch/odm/Scripts/assesment_1.csv"
with open(myfile) as f:
    contents = f.read()
    count = contents.count("1,2")

print(count)
