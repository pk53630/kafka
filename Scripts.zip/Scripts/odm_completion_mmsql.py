#!/usr/local/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re

div_id = sys.argv[1]
dt = arrow.now().format('YYYY-MM-DD')
filename = """/home/odmbatch/odm/logs/ODM_COMPLETION_DELTA_"""+dt+""".log"""

my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    Path(filename).touch()

log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("##################################### ODM COMPLETION DELTA EXTACTION STARTED ###################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")

query="""select 
COMPLETION_ID, WELL_ID, DIVISION_ID,PRIMO_PRPRTY,PRIMO_PRPSUB,PRIMO_APICOD,TOW_SCHEMA,TOW_COMP_SK,PROCOUNT_SCHEMA,PROCOUNT_MERRICKID,ARIES_SCHEMA,ARIES_DBSKEY,ARIES_PROPNUM,to_char(PRIMO_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as PRIMO_UPDATE_TS,to_char(TOW_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as TOW_UPDATE_TS,to_char(PROCOUNT_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as PROCOUNT_UPDATE_TS,to_char(ARIES_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as ARIES_UPDATE_TS,to_char(CREATE_TS,'YYYY-MM-DD HH24:MI:SS') as CREATE_TS,CREATE_USER_ID,to_char(UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as UPDATE_TS,UPDATE_USER_ID,COMPLETION_NAME,COMP_PURP,COMP_STAT,COMP_TYPE,COMP_METH,PROD_DESK_NAME,DRILL_TEAM_NAME,ENGR_NAME,FIELD_NAME,FOREMAN_NAME,FORM_NAME,PLATFORM_NAME,PRDN_TEAM_NAME,PRDN_AREA_NAME,PUMPER_NAME,RSVR_NAME,SUPERVISOR_NAME,to_char(QBYTE_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as QBYTE_UPDATE_TS,QBYTE_CC_NUM,FV_SITE_ID,PROCESS_HISTORY_ID,LATERAL_LENGTH,CLEANOUT_TCP_START_DATE_ID,CLEANOUT_TCP_END_DATE_ID,TCP_DATE_ID,DRILLOUT_PLUG_START_DATE_ID,DRILLOUT_PLUG_END_DATE_ID,
to_char(PERC_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as PERC_UPDATE_TS,FIRST_PROD_DT_ID,GROSS_EUR_MMCFE,GAS_EUR_MMCF,GROSS_EUR_MBOE,OIL_EUR_MBBL,WTR_EUR_MBBL,GOR,WGR,GROSS_EUR_MMCFE_PER_FT,OIL_EUR_PER_LB_SAND,OIL_EUR_PER_FT,WTR_EUR_PER_FT,CO2_EXIST,BARNETT_THICKNESS,TOTAL_POROSITY,OIL_SATURATION,BULK_VOLUME_OIL,HYDROCARBON_PORE_VOLUME,TL_HYDROCARBON_PORE_VOLUME,NMR_LARGE_PORE,BULK_VOLUME_OIL_LRG_PORE,TL_HC_PORE_VOL_LRG_PORE,SAND_TYPE,BYPASS_LENGTH,STIM_ROCK_VOLUME,FIRST_OIL_DAYS,OMIT_STG,FLOWBACK_FIRST_OIL_PCT,FIRST_OIL_DEPTH,FIRST_OIL_CSG,QTR_YEAR,DRILLOUT_YEAR,QC_TECH,QC_ENGINEER,PERF_CONF,WELL_SPACE_EAST,WELL_SPACE_WEST,COMP_ENGR_NAME,ARIES_RESERVE_KEY,FIELD_ID,COUNTY_CD_ID,RSVR_ID,FORM_ID,PLATFORM_ID,COMP_TYPE_ID,COMP_PURP_ID,FOREMAN_ID,STATE_PROV_CD_ID,WELL_COMP_STATUS_ID,PROD_METHOD_ID,ROUTE_ID,DIVISION_REF_ID,ACCOUNTING_TEAM_ID,PRDN_AREA_ID,DDA_FIELD_ID,DRILL_TEAM_ID,FIELD_GROUP_ID,GATHERING_SYS_ID,LEASE_ID,PROD_ACCOUNTANT_ID,PRDN_TEAM_ID,ENGR_NAME_ID,TREND_REF_ID,SUBTREND_REF_ID,PLAY_REF_ID,to_char(PA_DATE,'YYYY-MM-DD HH24:MI:SS') as PA_DATE,
to_char(SOLD_DATE,'YYYY-MM-DD HH24:MI:SS') as SOLD_DATE,PROSPECT_ID,TEAM_REF_ID,to_char(FP_DATE,'YYYY-MM-DD HH24:MI:SS') as FP_DATE,PRJ_YEAR,ARIES_CATEGORY,PLAN_MD_DPTH,SHRINK_PLANT,YIELD_PLANT,SUBTREND2_REF_ID,COMP_ENGR_ID,COMP_METH_ID,PROD_DESK_ID,PROD_SUPT_ID,ARIES_CATEGORY_ID,DRILL_YEAR_ID,RIG_CO_ID,PROJ_YEAR_ID,PUMPER_ID,UWI,BH_LOCATION_ELEMENT_1,BH_LOCATION_ELEMENT_2,BH_LOCATION_ELEMENT_3,BH_LOCATION_ELEMENT_4,BH_LOCATION_ELEMENT_5,BH_LOCATION_ELEMENT_6,BH_LOCATION_ELEMENT_7,BH_LOCATION_ELEMENT_8,LOCATION_ELEMENT_1,LOCATION_ELEMENT_2,LOCATION_ELEMENT_3,LOCATION_ELEMENT_4,LOCATION_ELEMENT_5,LOCATION_ELEMENT_6,LOCATION_ELEMENT_7,LOCATION_ELEMENT_8,GATHERING_SYSTEM_STATUS,PROD_ANALYST_NAME,PLANT_ID,PRISM_UWI,PRISM_CC_NUM,TOTAL_CAPITAL_GROSS,AFIT_DIRECT_TOTAL_CAPITAL,AFIT_DIRECT_ROR,AFIT_DIRECT_PVI,AFIT_DIRECT_NPV10,GAS_EUR_NET,NGL_EUR_NET,OIL_EUR_NET,NGL_EUR_GROSS,CEMENTED_FL,EXTERNAL_PACKERS_FL,WELLS_PER_PAD,IC_COMPLETION_ID,COMMENTS,PLUG_BACK_TOTAL_DEPTH_FT,COMP_RIG_RELEASE_DT_ID,to_char(CDC_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as CDC_UPDATE_TS,
COMPLETION_SOURCE,COMPLETION_METHOD_ID,COMPLETION_METHOD,CSE_FILE_NBR,to_char(CSE_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as CSE_UPDATE_TS,WLV_IDWELL,to_char(WLV_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as WLV_UPDATE_TS,to_char(NAV1_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as NAV1_UPDATE_TS,to_char(ECO_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as ECO_UPDATE_TS,OIL_GATHERING_SYS_ID,PUMP_DEPTH,TOW_GATH_AGRMNT_ID,GATH_AGRMNT_ID_1,GATH_AGRMNT_ID_2,GATH_AGRMNT_ID_3,SUB_DIVISION_ID,DO_RIG_ID,XSPOC_DATASET,XSPOC_WELL_KEY,CYGNET_DATASET,CYGNET_WELL_KEY,BLUE_COMPLETION_FL,GROSS_OIL_PREFRAC_HIT_EUR,OPS_DIV_ID,EC_ENTITY_ID,EC_ENTITY_COLOR,BLUE_WELL_FL,RT_FRACPACK_NAME,PRODUCTION_ID,XSPOC_NODE_ID,PRIOR_YR_CAT_ID,TOW_PCT_EXISTS_FL,LATERAL_MILEAGE,PREMIUM_WELL_FL,ITYPE_CURVE_FL,LOE_AREA_ID,YPC_EOG_FL,ENERTIA_KEY,ENERTIA_COMP_HID,ENERTIA_COMP_CODE,AW_ROR,IP_FLOW_UP
from odm_dba.odm_completion_delta where division_id="""+div_id+""" and delta_ts >= (select nvl((select end_ts from (select end_ts, rank() over (order by end_ts desc) rn from odm_dba.utl_process_history where process_id=(select process_id from odm_dba.utl_process where process_name = 'LOAD_ODM_COMPLETION_DELTA') and division_id ="""+div_id+""") where rn = 2),(select max(start_ts) from odm_dba.utl_process_history where process_id=(select process_id from odm_dba.utl_process where process_name = 'LOAD_ODM_COMPLETION_DELTA') and division_id = """+div_id+""")) as ts from dual) and division_id="""+div_id

logger.info("                                                                                                                ")

completion_id="""select completion_id from odm_dba.odm_completion_delta where division_id ="""+div_id+""" and delta_ts >= (select nvl((select end_ts from (select end_ts, rank() over (order by end_ts desc) rn from odm_dba.utl_process_history where process_id=(select process_id from odm_dba.utl_process where process_name = 'LOAD_ODM_COMPLETION_DELTA') and division_id ="""+div_id+""") where rn = 2),(select max(start_ts) from odm_dba.utl_process_history where process_id=(select process_id from odm_dba.utl_process where process_name = 'LOAD_ODM_COMPLETION_DELTA') and division_id = """+div_id+""")) as ts from dual) and division_id="""+div_id
logger.info("                                                                                                                ")

connection = cx_Oracle.connect('odm_dba/R1dba_101@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(query)

data_list = []
column_names = []

for i in cursor.description:
    column_names.append(i[0])
for row in cursor.fetchall():
    data_list.append(list(row))

logger.debug("The List of Delete and Insert records are %s :",data_list)
cursor.execute(completion_id)

comp_id_list = []
comp_id_col_nm = []

for j in cursor.description:
    comp_id_col_nm.append(j[0])
for row_comp_id in cursor.fetchall():
    comp_id_list.append(list(row_comp_id))


cnx = mysql.connector.connect(user='ODM_DBA', password='Test_123', host='OPSMSQLDEV01')
cur = cnx.cursor()

logger.info("###################################### Delete Statement STARTED Execution ######################################")
stmt = "DELETE FROM ODM_DBA.odm_completion_delta WHERE completion_id = (%s) and division_id = "+div_id
cur.executemany(stmt,comp_id_list)

logger.info("###################################### Delete Statement COMPLETED Execution ####################################")
logger.info("                                                                                                                ")
logger.info("                                                                                                                ")
logger.info("###################################### Insert Statement STARTED Execution ######################################")

stmt1 = """INSERT INTO ODM_DBA.odm_completion_delta
(completion_id, well_id, division_id, primo_prprty, primo_prpsub, primo_apicod, tow_schema, tow_comp_sk, procount_schema, procount_merrickid, aries_schema, aries_dbskey, aries_propnum, primo_update_ts, tow_update_ts, procount_update_ts, aries_update_ts, create_ts, create_user_id, update_ts, update_user_id, completion_name, comp_purp, comp_stat, comp_type, comp_meth, prod_desk_name, drill_team_name, engr_name, field_name, foreman_name, form_name, platform_name, prdn_team_name, prdn_area_name, pumper_name, rsvr_name, supervisor_name, qbyte_update_ts, qbyte_cc_num, fv_site_id, process_history_id, lateral_length, cleanout_tcp_start_date_id, cleanout_tcp_end_date_id, tcp_date_id, drillout_plug_start_date_id, drillout_plug_end_date_id, perc_update_ts, first_prod_dt_id, gross_eur_mmcfe, gas_eur_mmcf, gross_eur_mboe, oil_eur_mbbl, wtr_eur_mbbl, gor, wgr, gross_eur_mmcfe_per_ft, oil_eur_per_lb_sand, oil_eur_per_ft, wtr_eur_per_ft, co2_exist, barnett_thickness, total_porosity, oil_saturation, bulk_volume_oil, hydrocarbon_pore_volume, tl_hydrocarbon_pore_volume, 
 nmr_large_pore, bulk_volume_oil_lrg_pore, tl_hc_pore_vol_lrg_pore, sand_type, bypass_length, stim_rock_volume, first_oil_days, omit_stg, flowback_first_oil_pct, first_oil_depth, first_oil_csg, qtr_year, drillout_year, qc_tech, qc_engineer, perf_conf, well_space_east, well_space_west, comp_engr_name, aries_reserve_key, field_id, county_cd_id, rsvr_id, form_id, platform_id, comp_type_id, comp_purp_id, foreman_id, state_prov_cd_id, well_comp_status_id, prod_method_id, route_id, division_ref_id, accounting_team_id, prdn_area_id, dda_field_id, drill_team_id, field_group_id, gathering_sys_id, lease_id, prod_accountant_id, prdn_team_id, engr_name_id, trend_ref_id, subtrend_ref_id, play_ref_id, pa_date, sold_date, prospect_id, team_ref_id, fp_date, prj_year, aries_category, plan_md_dpth, shrink_plant, yield_plant, subtrend2_ref_id, comp_engr_id, comp_meth_id, prod_desk_id, prod_supt_id, aries_category_id, drill_year_id, rig_co_id, proj_year_id, pumper_id, uwi, bh_location_element_1, bh_location_element_2, bh_location_element_3, bh_location_element_4, bh_location_element_5, 
 bh_location_element_6, bh_location_element_7, bh_location_element_8, location_element_1, location_element_2, location_element_3, location_element_4, location_element_5, location_element_6, location_element_7, location_element_8, gathering_system_status, prod_analyst_name, plant_id, prism_uwi, prism_cc_num, total_capital_gross, afit_direct_total_capital, afit_direct_ror, afit_direct_pvi, afit_direct_npv10, gas_eur_net, ngl_eur_net, oil_eur_net, ngl_eur_gross, cemented_fl, external_packers_fl, wells_per_pad, ic_completion_id, comments, plug_back_total_depth_ft, comp_rig_release_dt_id, cdc_update_ts, completion_source, completion_method_id, completion_method, cse_file_nbr, cse_update_ts, wlv_idwell, wlv_update_ts, nav1_update_ts, eco_update_ts, oil_gathering_sys_id, pump_depth, tow_gath_agrmnt_id, gath_agrmnt_id_1, gath_agrmnt_id_2, gath_agrmnt_id_3, sub_division_id, do_rig_id, xspoc_dataset, xspoc_well_key, cygnet_dataset, cygnet_well_key, blue_completion_fl, gross_oil_prefrac_hit_eur, ops_div_id, ec_entity_id, ec_entity_color, blue_well_fl, rt_fracpack_name, production_id, 
 xspoc_node_id, prior_yr_cat_id, tow_pct_exists_fl, lateral_mileage, premium_well_fl, itype_curve_fl, loe_area_id, ypc_eog_fl, enertia_key, enertia_comp_hid, enertia_comp_code, aw_ror, ip_flow_up)
 VALUES
(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""

for k in range(0,len(data_list)):
    cur.execute(stmt1,data_list[k])

cnx.commit()

logger.info("###################################### Insert Statement COMPLETED Execution ####################################")
logger.info("                                                                                                                ")

cur.close()
cnx.close()

cursor.close()
connection.close()

logger.info("################################################################################################################")
logger.info("############################### ODM COMPLETION DELTA EXTACTION COMPLETED #######################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")
logger.info("                                                                                                                ")
