#!/usr/local/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re

div_id = sys.argv[1]

dt=arrow.now().format('YYYY-MM-DD')
filename="""/home/odmbatch/odm/logs/ODM_COMP_PRODUCTION_DELTA_"""+dt+""".log"""

my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    #print("file is not present")
    Path(filename).touch()


log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("############################## ODM COMP PRODUCTION DELTA EXTACTION STARTED #####################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")
logger.info("                                                                                                                ")
logger.info("                                                                                                                ")

comp_id="""select 
DIVISION_ID,COMPLETION_ID,DATE_ID,to_char(DATE_VALUE,'YYYY-MM-DD HH24:MI:SS') as DATE_VALUE,GROSS_GAS_PROD,GROSS_OIL_PROD,WATER_PROD,GROSS_GAS_SALES,GROSS_OIL_SALES,POTENTIAL_GAS_PROD,POTENTIAL_OIL_PROD,POTENTIAL_WATER_PROD,FORECAST_GAS_PROD,FORECAST_OIL_PROD,FORECAST_WATER_PROD,FORECAST_NGL_PROD,FORECAST_COND_PROD,FORECAST_GAS_SALES,FORECAST_OIL_SALES,FORECAST_WATER_SALES,FORECAST_NGL_SALES,FORECAST_COND_SALES,FORECAST_NET_GAS_SALES,FORECAST_NET_OIL_SALES,FORECAST_NET_WATER_SALES,FORECAST_NET_NGL_SALES,FORECAST_NET_COND_SALES,GAS_INJ,OIL_INJ,WATER_INJ,CHOKE,CASING_PRESSURE1,CASING_PRESSURE2,TUBING_PRESSURE,TEMPERATURE,DOWNTIME_HRS,DOWNTIME_REASON_REF_ID,COMMENTS,POTENTIAL_UPDATE_FL,POTENTIAL_PROCESS_ID,FORECAST_PROCESS_ID,UPDATE_PROCESS_ID,NRI_OIL,NRI_GAS,NRI_NGL,CUM_GAS_PROD,CUM_OIL_PROD,CUM_WATER_PROD,CUM_POTENTIAL_GAS_PROD,CUM_POTENTIAL_OIL_PROD,CUM_POTENTIAL_WATER_PROD,CUM_FORECAST_GAS_PROD,CUM_FORECAST_OIL_PROD,CUM_FORECAST_WATER_PROD,LINE_PRESSURE,QBYTE_CC_NUM,to_char(QBYTE_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as QBYTE_UPDATE_TS,
to_char(TOW_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as TOW_UPDATE_TS,to_char(PROCOUNT_UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as PROCOUNT_UPDATE_TS,CREATE_USER_ID,to_char(CREATE_TS,'YYYY-MM-DD HH24:MI:SS') as CREATE_TS,UPDATE_USER_ID,to_char(UPDATE_TS,'YYYY-MM-DD HH24:MI:SS') as UPDATE_TS,SRC_SYS_CD,WATER_SALES,GROSS_OIL_BEG_INV,GROSS_OIL_END_INV,SURF_CASING_PRESS,CHLORIDES,GOR_PROD,WGR_PROD,VENT_VOL,OIL_DENSITY,WATER_DENSITY,WOR_PROD,WLR_PROD,OIL_CUT_PCT,MEASURED_FLUID_LEVEL,MEASURED_BHP,GAS_LIFT_VOL,H2S,STROKES,LOAD_WATER_REM,GAS_FLARE,WATER_HAULED,WATER_TRANSFER,OIL_GRAVITY,C5,GROSS_FCST_OIL_PROD,GROSS_FCST_GAS_PROD,GROSS_FCST_WATER_PROD,FULL_CHOKE_SIZE,WATER_TRNSFR_VOL,FC_H2S,PRED_FCST_OIL_PROD,PRED_FCST_GAS_PROD,PRED_FCST_WATER_PROD,GROSS_NGL_SALES,NET_NGL_SALES,GROSS_DRY_GAS_PROD,NET_DRY_GAS_PROD,NET_OIL_PROD,NET_GAS_PROD,NET_OIL_SALES,NET_GAS_SALES,GROSS_DRY_GAS_SALES,NET_DRY_GAS_SALES,INTERMEDIATE_CASING,CO2,EOR_GAS_TOTAL_RETURN,UNDERPERFORM_REASON_REF_ID,ALERT_POTN_OIL_PROD,ALERT_GROSS_OIL_PROD,ALERT_POTN_GAS_PROD,ALERT_GROSS_GAS_PROD,AIR_INJECTION,FRESH_WATER_INJ,SALT_WATER_INJ
from odm_dba.odm_comp_production partition (comp_prod_DIV10)
where trunc(date_value) = (select trunc(end_ts)-3 from odm_dba.utl_process_last_run where process_id=2187 and division_id ="""+div_id+""")""" 
"""and update_ts  >= (select end_ts-3 from odm_dba.utl_process_last_run where process_id=2187 and division_id ="""+div_id+""")"""


connection = cx_Oracle.connect('odm_dba/R1dba_101@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)

cursor.execute(comp_id)

well_id_list=[]
well_id_col_nm =[]

for j in cursor.description:
    well_id_col_nm.append(j[0])


for row_well_id in cursor.fetchall():
    #print(tuple(row_well_id))
    well_id_list.append(list(row_well_id))


a=[]
for i in range(0,len(well_id_list)):
    a.append(well_id_list[i][1])


b=[]
for j in range(0,len(well_id_list)):
    b.append(well_id_list[j][2])


comp_id=list(a)
date_id=list(b)
#print(date_id)



cnx = mysql.connector.connect(user='ODM_DBA', password='Test_123', host='OPSMSQLDEV01')
cur = cnx.cursor()

stmt = """DELETE FROM ODM_DBA.odm_comp_production_delta WHERE completion_id = %s"""

for k in range(0,len(comp_id)):
    cur.execute(stmt,(comp_id[k]),(date_id[k]))



stmt1 = """INSERT INTO ODM_DBA.odm_comp_production_delta
(division_id,completion_id,date_id,date_value,gross_gas_prod,gross_oil_prod,water_prod,gross_gas_sales,gross_oil_sales,potential_gas_prod,potential_oil_prod,potential_water_prod,forecast_gas_prod,forecast_oil_prod,forecast_water_prod,forecast_ngl_prod,forecast_cond_prod,forecast_gas_sales,forecast_oil_sales,forecast_water_sales,forecast_ngl_sales,forecast_cond_sales,forecast_net_gas_sales,forecast_net_oil_sales,forecast_net_water_sales,forecast_net_ngl_sales,forecast_net_cond_sales,gas_inj,oil_inj,water_inj,choke,casing_pressure1,casing_pressure2,tubing_pressure,temperature,downtime_hrs,downtime_reason_ref_id,comments,potential_update_fl,potential_process_id,forecast_process_id,update_process_id,nri_oil,nri_gas,nri_ngl,cum_gas_prod,cum_oil_prod,cum_water_prod,cum_potential_gas_prod,cum_potential_oil_prod,cum_potential_water_prod,cum_forecast_gas_prod,cum_forecast_oil_prod,cum_forecast_water_prod,line_pressure,qbyte_cc_num,qbyte_update_ts,tow_update_ts,procount_update_ts,create_user_id,create_ts,update_user_id,update_ts,src_sys_cd,water_sales,gross_oil_beg_inv,gross_oil_end_inv,surf_casing_press,chlorides,gor_prod,wgr_prod,vent_vol,oil_density,water_density,wor_prod,wlr_prod,oil_cut_pct,measured_fluid_level,measured_bhp,gas_lift_vol,h2s,strokes,load_water_rem,gas_flare,water_hauled,water_transfer,oil_gravity,c5,gross_fcst_oil_prod,gross_fcst_gas_prod,gross_fcst_water_prod,full_choke_size,water_trnsfr_vol,fc_h2s,pred_fcst_oil_prod,pred_fcst_gas_prod,pred_fcst_water_prod,gross_ngl_sales,net_ngl_sales,gross_dry_gas_prod,net_dry_gas_prod,net_oil_prod,net_gas_prod,net_oil_sales,net_gas_sales,gross_dry_gas_sales,net_dry_gas_sales,intermediate_casing,co2,eor_gas_total_return,underperform_reason_ref_id,alert_potn_oil_prod,alert_gross_oil_prod,alert_potn_gas_prod,alert_gross_gas_prod,air_injection,fresh_water_inj,salt_water_inj)
 VALUES
(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""

for m in range(0,len(well_id_list)):
    #print(len(well_id_list))
    cur.execute(stmt1,well_id_list[m])


cnx.commit()

cur.close()
cnx.close()



cursor.close()
connection.close()

