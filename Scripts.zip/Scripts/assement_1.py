#!/usr/bin/python3
import re

filename="/home/odmbatch/odm/Scripts/assesment_1.csv"
with open('/home/odmbatch/odm/Scripts/assesment_1.csv', "r") as file:
    for j,line in enumerate(file):
        #j={}
        print(j)
        dic="a_"+str(j)+"={}"
        print(dic)
        line = line.rstrip("\n").split(',')
        #print(line)
        for i in range(0,len(line)-1):
            ptrn = line[i]+','+line[i+1]
            pattern=line[i]+','+line[i+1]
            #print(ptrn)
            #match = re.search(pattern,line)
            #if match:
            #    print(match.group())




