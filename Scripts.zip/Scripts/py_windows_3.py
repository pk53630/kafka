#!/usr/bin/python3

import csv
import sys
import os
import cx_Oracle
import datetime

lst=[]
f_lst=[]
with open('/home/odmbatch/odm/Scripts/9-17-19_fluid_shots.csv', "r") as file:
    for k,line in enumerate(file):
        line = line.rstrip("\n")
        line_s=line.split(',')
        lst.append(line_s)


print(lst[0][1])
print(lst[1][1])




for i in range(0,len(lst)):
    f_lst.append(lst[i][1])
    f_lst.append(lst[i][347])



#print(f_lst)
query=""" SELECT distinct Division_ID FROM ODM_INFO.ODM_COMPLETION WHERE PRIMO_PRPRTY ="""
#connection = cx_Oracle.connect('iprod_dba/Test_123@r1date.eogresources.com')
#cursor = cx_Oracle.Cursor(connection)

#cursor.executemany("""
#insert into iprod_dba.ECHOMETER_FLUID_SURVEY_test (DIVISION_ID,WELL_ID,DATE_VALUE,FLUID_LEVEL_SURVEY_DATE,COMMENT_TXT)
#        values (:1, :2,:3,:4,:5)""", lst)

#cursor.close()
#connection.close()


