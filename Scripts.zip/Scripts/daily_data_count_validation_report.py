#!/usr/local/bin/python3
import sys
import configparser
import cx_Oracle
import os, time, smtplib, socket
from email.mime.text import MIMEText
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from datetime import datetime, timedelta
import arrow
from pathlib import Path
import re
import zipfile
import email.utils
import email
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from os.path import basename
import email.mime.application
import pandas as pd


src_table_nm = sys.argv[1]
dt=arrow.now().format('YYYYMMDD')
dtMS=arrow.now().format('HHMS')
dty=arrow.now().format('YYYY-MM-DD')


archive_file= """/home/odmbatch/odm/archive/"""+dtMS+"""_ES_VALIDATION_"""+src_table_nm+"""_"""+dt+""".csv"""

validation_file="""/home/odmbatch/odm/data/"""+dtMS+"""_ES_VALIDATION_"""+src_table_nm+"""_"""+dt+""".csv"""
Path(validation_file).touch()

if src_table_nm == "site_well":
    with open(validation_file, "w") as f:
        f.write("SITE_NAME,PROPERTY_NAME,PROPERTY_ID,DIVISION_ID,Value_Exists_In_Index"+ "\n")
elif src_table_nm == "facility_well":
    with open(validation_file, "w") as f:
        f.write("FACILITY_NAME,WELL_NAME,PRIMO_ID,DIVISION_ID,WELL_ID,Value_Exists_In_Index"+ "\n")
elif src_table_nm == "site_unit":
    with open(validation_file, "w") as f:
        f.write("SITE_NAME,PROPERTY_NAME,PROPERTY_ID,DIVISION_ID,Value_Exists_In_Index"+ "\n")
elif src_table_nm == "facility_unit":
    with open(validation_file, "w") as f:
        f.write("FACILITY_NAME,UNIT_FACILITY_NAME,PROPERTY_ID,DIVISION_ID,Value_Exists_In_Index"+ "\n")
elif src_table_nm == "attribute_values":
    with open(validation_file, "w") as f:
        f.write("PROPERTY_NAME,PROPERTY_ID,ASSET_ID,ATTRIBUTE_ID,ATTRIBUTE_NAME,VALUE_LIST_ENTRY_ID,SHORT_TEXT_VALUE,Value_Exists_In_Index"+ "\n")
elif src_table_nm == "property_asset_name":
    with open(validation_file, "w") as f:
        f.write("ASSET_ID,CURRENT_PROPERTY_NAME,Value_Exists_In_Index"+ "\n")
else:
    print("None")		
		
		
		
site_well_query=""" 
SELECT
    s.site_name,
    k.property_name,
    k.property_id,
    k.division_id
FROM
    im_dba.im_site s,
    im_site_property p,
    ke_dba.ke_property k
WHERE
    s.site_id = p.site_id
    AND p.property_id = k.property_id
    AND k.primo_property_type = 'WELL'
    AND p.update_ts > '15-JUN-2019'
"""

facility_well_query=""" 
SELECT
    f.facility_name,
    w.well_name,
    w.primo_id,
    w.division_id,
    w.well_id
FROM
    fdm_dba.fdm_facility f,
    fdm_dba.fdm_fac_well_xref x,
    odm_info.odm_well w
WHERE
    f.facility_id = x.facility_id
    AND x.well_id = w.well_id
    AND x.update_ts > '15-JUN-2019'
    AND x.facility_context = 'REGULATORY'
"""

site_unit_query=""" 
SELECT
    s.site_name,
    k.property_name,
    k.property_id,
    k.division_id
FROM
    im_dba.im_site s,
    im_site_property p,
    ke_dba.ke_property k
WHERE
    s.site_id = p.site_id
    AND p.property_id = k.property_id
    AND k.primo_property_type = 'OIL '
                                || CHR(38)
                                || ' GAS FACILITY'
    AND p.update_ts > '15-JUN-2019' """


facility_unit_query=""" 
SELECT
    f.facility_name,
    uf.unit_facility_name,
    uf.primo_id,
    uf.division_id
FROM
    fdm_dba.fdm_facility f,
    fdm_dba.fdm_unit_fac_xref x,
    fdm_dba.fdm_unit_facility uf
WHERE
    f.facility_id = x.facility_id
    AND x.unit_facility_id = uf.unit_facility_id
    AND x.update_ts > '15-JUN-2019'
    AND x.facility_context = 'REGULATORY' """


attribute_values_query="""
SELECT
    k.property_name,
    k.property_id,
    v.asset_id,
    v.attribute_id,
    a.attribute_name,
    v.value_list_entry_id,
    e.short_text_value,
    v.update_ts
FROM
    im_dba.im_asset_attribute_value v,
    im_dba.im_attribute a,
    im_dba.im_value_list l,
    im_dba.im_value_list_entry e,
    im_dba.im_asset ma,
    im_property_asset pa,
    ke_dba.ke_property k
WHERE
    v.attribute_id = a.attribute_id
    AND v.value_list_entry_id = e.value_list_entry_id
    AND e.value_list_id = l.value_list_id
    AND v.asset_id = ma.asset_id
    AND v.asset_id = pa.asset_id
    AND pa.property_id = k.property_id
    AND v.update_ts > SYSDATE - 1
ORDER BY
    v.update_ts DESC
"""


property_asset_name_query="""
SELECT --p.property_id,
distinct      p.asset_id,
       p.op_status_cd,
       k.property_name     current_property_name,
       case when v.update_ts between sysdate-1 and sysdate then v.date_value else NULL end as date_value,
       case when v.update_ts between sysdate-1 and sysdate then v.number_value else NULL end as number_value,
       case when v.update_ts between sysdate-1 and sysdate then v.value_list_entry_id else NULL end as value_list_entry_id
     --  kh.property_name,
      -- h.*
  FROM im_dba.im_property_asset          p,
       ke_dba.ke_property                k,
       ke_dba.ke_property                kh,
       im_dba.im_property_asset_history  h,
       im_dba.im_asset_attribute_value v
WHERE     p.asset_id = h.asset_id
       AND p.property_id = k.property_id
       AND h.property_id = kh.property_id
       AND p.asset_id = v.asset_id(+)
       and trunc(h.update_ts) > '15-JUN-2019'
"""


	
connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)


cursor.execute(site_well_query)
site_well_data_list=[]
for row in cursor.fetchall():
    site_well_data_list.append(list(row))


cursor.execute(facility_well_query)
facility_well_data_list=[]
for row in cursor.fetchall():
    facility_well_data_list.append(list(row))


cursor.execute(site_unit_query)
site_unit_data_list=[]
for row in cursor.fetchall():
    site_unit_data_list.append(list(row))


cursor.execute(facility_unit_query)
facility_unit_data_list=[]	
for row in cursor.fetchall():
    facility_unit_data_list.append(list(row))


cursor.execute(attribute_values_query)
attribute_values_data_list=[]
for row in cursor.fetchall():
    attribute_values_data_list.append(list(row))


cursor.execute(property_asset_name_query)
property_asset_name_data_list=[]
for row in cursor.fetchall():
    property_asset_name_data_list.append(list(row))
	
	
cursor.close()
connection.close()

try:
            pd.options.display.max_colwidth = 1000

            esconfigfilename = '/home/odmbatch/odm/Scripts/ece_es_credentials.ini'
            config = configparser.ConfigParser()
            config.read(esconfigfilename)

            es_search_conf = config['FIELDOPSESSTAGE']
            print(es_search_conf)
            host_name = es_search_conf['HostName']
            print(host_name)
            time_out = int( es_search_conf['Timeout'])
            print(time_out)
            user = es_search_conf['User']
            print(user)
            password = es_search_conf['Password']
            print(password)
            certs =  es_search_conf['VerifyCerts']
            print(certs)
            header = es_search_conf['Header']
            print(header)
            h = { "Content-type":"application/json" }

            configfilename = '/home/odmbatch/ifacility/es_ifacility_value_list.ini'
            print(configfilename)

            es_index_list = [configfilename]
            resultlist =[]


            subject = 'Facility Value List ES Process'

            for configfilename in es_index_list:
                try:
                    config = configparser.ConfigParser()
                    config.read(configfilename)

                    #ES email
                    es_email_conf = config['EMAIL']
                    sender = es_email_conf['EmailFrom']
                    recipients = es_email_conf['EmailTo']

                    #ES Index Settings to set shards and replicas
                    index_settings = {}
                    index_settings['settings'] = {}

                    for key, val in config.items('ESINDEXBODY'):
                                index_settings['settings'][key] = val
                    #print(index_settings)


                    #ES index details
                    es_index_conf = config['ESINDEXDETAILS']
                    alias_name = es_index_conf['AliasName']
                    #index_name = datetime.datetime.now().strftime('{0}_%H_%M_%d_%m_%Y'.format(alias_name))
                    index_name='ifacility_asset_changes'
                    print(index_name)
                    type_name = es_index_conf['TypeName']
                    ignore =  int(es_index_conf['Ignore'])
                    nested_index = es_index_conf['NestedIndex']
                    index_id = es_index_conf['IndexFieldId']
                    bulk_push_size = int(es_index_conf['BulkPushSize'])
                    refresh_interval = es_index_conf['RefreshInterval']
                    field_mappings = es_index_conf['IndexFieldMappings']
                    field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
                    field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))

                    #print(field_mappings_dict)

                    #ES mapping
                    es_mapping_conf = config['ELASTICTEMPLATE']
                    mapping_file = es_mapping_conf['MappingFile']
                    with open('{0}'.format(mapping_file), 'r') as mappingFile:
                            mappings = mappingFile.read()
							
                    d=datetime.strftime(datetime.now() - timedelta(1), '%Y-%m-%d')
                    dY=(d+"T00:00:00.000-00:00")
                    print(dY)

                    es = Elasticsearch(
                        hosts = host_name,#esdatanodes
                        timeout = time_out, # increase timeout from default 10s to 120s
                        http_auth=(user,password),
                        verify_certs=certs,
                        headers = h
                              )
                    print(es)

                    if es.indices.exists(index_name):
                        print('Index exists')
                        if src_table_nm == "site_well":
                            try:
                                v_Index_name="ifacility_asset_changes"
                                for i in range(0,len(site_well_data_list)):
                                    #SITE_NAME,PROPERTY_NAME,PROPERTY_ID,DIVISION_ID
                                    v_SITE_NAME=site_well_data_list[i][0]
                                    v_PROPERTY_NAME=site_well_data_list[i][1]
                                    v_PROPERTY_ID=site_well_data_list[i][2]
                                    v_DIVISION_ID=site_well_data_list[i][3]
									
                                    res = es.search(index="ifacility_asset_changes", body={"query": {"bool": {"must": [
                                                                   {"match": {"object.propertyName": v_PROPERTY_NAME}},
                                                                   {"match": {"object.propertyId": v_PROPERTY_ID}},
                                                                   {"match": {"object.divisionId": v_DIVISION_ID}}
                                                                                ]}}
                                                                                   })
                                    #res
                                    #print(res)
                                    x="%d" % res['hits']['total']
                                    #print(x)
                                    a=lambda x: 'True' if int(x) > 0 else 'False'
                                    #print(a(x))
                                    res_f = v_SITE_NAME+","+v_PROPERTY_NAME+","+str(v_PROPERTY_ID)+","+str(v_DIVISION_ID)+","+a(x)
                                    #print("%d documents found" % res['hits']['total'])
                                    #for doc in res['hits']['hits']:
                                    #print("%s) %s" % (doc['_id'], doc['_source']['updateTs']))
									
                                    with open(validation_file, "a") as f: 
                                        f.write(str(res_f)+ "\n")
                            except Exception as e:
                                print(e)
								
                        elif src_table_nm == "facility_well":
                            try:
                                v_Index_name="ifacility_facilities"
                                for i in range(0,len(facility_well_data_list)):
                                    #FACILITY_NAME,WELL_NAME,PRIMO_ID,DIVISION_ID,WELL_ID
                                    v_FACILITY_NAME=facility_well_data_list[i][0]
                                    v_WELL_NAME=facility_well_data_list[i][1]
                                    v_PRIMO_ID=facility_well_data_list[i][2]
                                    v_DIVISION_ID=facility_well_data_list[i][3]
                                    v_WELL_ID=facility_well_data_list[i][3]
									
                                    res = es.search(index="ifacility_facilities", body={"query": {"bool": {"must": [
                                                                     {"match": {"facilityName": v_FACILITY_NAME}},
                                                                     {"match": {"primoList": v_PRIMO_ID}},
			                                             {"match": {"divisionId": v_DIVISION_ID}}
	                                                                   ]}}
                                                                            })
                                    #res
                                    #print(res)
                                    x="%d" % res['hits']['total']
                                    #print(x)
                                    a=lambda x: 'True' if int(x) > 0 else 'False'
                                    #print(a(x))
                                    res_f = v_FACILITY_NAME+","+v_WELL_NAME+","+str(v_PRIMO_ID)+","+str(v_DIVISION_ID)+","+str(v_WELL_ID)+","+a(x)
                                    #print("%d documents found" % res['hits']['total'])
                                    #for doc in res['hits']['hits']:
                                    #print("%s) %s" % (doc['_id'], doc['_source']['updateTs']))
									
                                    with open(validation_file, "a") as f: 
                                        f.write(str(res_f)+ "\n")
                            except Exception as e:
                                print(e)								

                        elif src_table_nm == "site_unit":
                            try:
                                v_Index_name="ifacility_asset_changes"
                                for i in range(0,len(site_unit_data_list)):
                                #SITE_NAME,PROPERTY_NAME,PROPERTY_ID,DIVISION_ID
                                    v_SITE_NAME=site_unit_data_list[i][0]
                                    v_PROPERTY_NAME=site_unit_data_list[i][1]
                                    v_PROPERTY_ID=site_unit_data_list[i][2]
                                    v_DIVISION_ID=site_unit_data_list[i][3]

                                    res = es.search(index="ifacility_asset_changes", body={"query": {"bool": {"must": [
                                                                          {"match": {"object.propertyName": v_PROPERTY_NAME}},
                                                                          {"match": {"object.propertyId": v_PROPERTY_ID}},
                                                                          {"match": {"object.divisionId": v_DIVISION_ID}}
                                                                                     ]}}
                                                                                })
                                    #print(res)
                                    x="%d" % res['hits']['total']
                                    #print(x)
                                    a=lambda x: 'True' if int(x) > 0 else 'False'
                                    #print(a(x))
                                    res_f = v_SITE_NAME+","+v_PROPERTY_NAME+","+str(v_PROPERTY_ID)+","+str(v_DIVISION_ID)+","+a(x)
                                    #print("%d documents found" % res['hits']['total'])
                                    #for doc in res['hits']['hits']:
                                    #print("%s) %s" % (doc['_id'], doc['_source']['updateTs']))
									
                                    with open(validation_file, "a") as f: 
                                        f.write(str(res_f)+ "\n")
                            except Exception as e:
                                print(e)								

                        elif src_table_nm == "facility_unit":
                            try:
                                v_Index_name="ifacility_facilities"
                                for i in range(0,len(facility_unit_data_list)):
                                    #FACILITY_NAME,UNIT_FACILITY_NAME,PROPERTY_ID,DIVISION_ID
                                    v_FACILITY_NAME=facility_unit_data_list[i][0]
                                    v_UNIT_FACILITY_NAME=facility_unit_data_list[i][1]
                                    v_PROPERTY_ID=facility_unit_data_list[i][2]
                                    v_DIVISION_ID=facility_unit_data_list[i][3]

                                    res = es.search(index="ifacility_facilities", body={"query": {"bool": {"must": [
                                                                                  {"match": {"facilityName": v_FACILITY_NAME}},
                                                                                  {"match": {"object.propertyId": v_PROPERTY_ID}},
                                                                                  {"match": {"object.divisionId": v_DIVISION_ID}}
                                                                                         ]}}
                                                                                   })
                                    #print(res)
                                    x="%d" % res['hits']['total']
                                    #print(x)
                                    a=lambda x: 'True' if int(x) > 0 else 'False'
                                    #print(a(x))
                                    res_f = v_FACILITY_NAME+","+v_UNIT_FACILITY_NAME+","+str(v_PROPERTY_ID)+","+str(v_DIVISION_ID)+","+a(x)
                                    #print("%d documents found" % res['hits']['total'])
                                    #for doc in res['hits']['hits']:
                                    #print("%s) %s" % (doc['_id'], doc['_source']['updateTs']))
									
                                    with open(validation_file, "a") as f: 
                                        f.write(str(res_f)+ "\n")
                            except Exception as e:
                                print(e)								

                        elif src_table_nm == "attribute_values":
                            try:
                                v_Index_name="ifacility_asset_changes"
                                for i in range(0,len(attribute_values_data_list)):
                                    #FACILITY_NAME,UNIT_FACILITY_NAME,PROPERTY_ID,DIVISION_ID
                                    v_property_name=attribute_values_data_list[i][0]
                                    v_property_id=attribute_values_data_list[i][1]
                                    v_asset_id=attribute_values_data_list[i][2]
                                    v_attribute_id=attribute_values_data_list[i][3]
                                    v_attribute_name=attribute_values_data_list[i][4]
                                    v_value_list_entry_id=attribute_values_data_list[i][5]
                                    v_short_text_value=attribute_values_data_list[i][6]

                                    res = es.search(index="ifacility_asset_changes", body={"query": {"bool": {"must": [
                                                                                  {"match": {"object.propertyName": v_property_name}},
                                                                                  {"match": {"object.propertyId": v_property_id}},
                                                                                  {"match": {"object.assetId": v_asset_id}},
                                                                                  {"match": {"object.attributeId": v_attribute_id}},
                                                                                  {"match": {"object.attributeName": v_attribute_name}},
                                                                                  {"match": {"object.assetValueListEntryId": v_value_list_entry_id}},
                                                                                  {"match": {"object.assetShortTextValue": v_short_text_value}}
                                                                                         ]}}
                                                                                   })
                                    #print(res)
                                    x="%d" % res['hits']['total']
                                    #print(x)
                                    a=lambda x: 'True' if int(x) > 0 else 'False'
                                    #print(a(x))
                                    res_f = v_property_name+","+str(v_property_id)+","+str(v_asset_id)+","+str(v_attribute_id)+","+v_attribute_name+","+str(v_value_list_entry_id)+","+v_short_text_value+","+a(x)
                                    #print("%d documents found" % res['hits']['total'])
                                    #for doc in res['hits']['hits']:
                                    #print("%s) %s" % (doc['_id'], doc['_source']['updateTs']))

                                    with open(validation_file, "a") as f:
                                        f.write(str(res_f)+ "\n")
                            except Exception as e:
                                print(e)

                        elif src_table_nm == "property_asset_name":
                            try:
                                v_Index_name="ifacility_asset_changes"
                                for i in range(0,len(property_asset_name_data_list)):
                                    #FACILITY_NAME,UNIT_FACILITY_NAME,PROPERTY_ID,DIVISION_ID
                                    v_assetId=property_asset_name_data_list[i][0]
                                    v_propertyName=property_asset_name_data_list[i][1]
                                    res = es.search(index="ifacility_asset_changes", body={"query": {"bool": {"must": [
                                                                                  {"match": {"object.assetId": v_assetId}},
                                                                                  {"match": {"object.propertyName": v_propertyName}}
                                                                                                                ]}}
                                                                                   })
 
                                    #print(res)
                                    x="%d" % res['hits']['total']
                                    #print(x)
                                    a=lambda x: 'True' if int(x) > 0 else 'False'
                                    #print(a(x))
                                    res_f=str(v_assetId) + "," + v_propertyName+","+a(x)
                                    #print("%d documents found" % res['hits']['total'])
                                    #for doc in res['hits']['hits']:
                                    #print("%s) %s" % (doc['_id'], doc['_source']['updateTs']))

                                    with open(validation_file, "a") as f:
                                        f.write(str(res_f)+ "\n")
                            except Exception as e:
                                print(e)


                except Exception as e:
                    print(e)

						
except Exception as e:
    print(e)						


f="""ES_VALIDATION_"""+src_table_nm+"""_"""+dt+""".csv"""
archive_folder="""/home/odmbatch/odm/data/"""
archive_file_zip="""ES_VALIDATION_"""+src_table_nm+"""_"""+dt+""".zip"""
archive_folder_zip="""/home/odmbatch/odm/Script/ES_VALIDATION_"""+src_table_nm+"""_"""+dt+""".zip"""
fantasy_zip = zipfile.ZipFile(archive_file_zip, 'w')

for folder, subfolders, files in os.walk(archive_folder):
    for file in files:
        if file.endswith('.csv'):
            fantasy_zip.write(os.path.join(folder, file),os.path.relpath(os.path.join(folder,file),archive_folder),compress_type = zipfile.ZIP_DEFLATED)

fantasy_zip.close()





#html to include in the body section

html = """\
<html>
  <head></head>
  <body>
    <p>Hi Team,<br>
       <br>
	   This is zipped file ES report for """+src_table_nm+""" on """+dt+""":<br>
	   <br>
	   ES Index Name : """+str(v_Index_name)+""":<br>
       <br>
	   The validation is Oracle with ES of above Index.
	   <br>
       <br>
	   Regards,<br>
	   ODM Support team,<br>
    </p>
  </body>
</html>
"""		   

 
# Creating message.
msg = MIMEMultipart('alternative')
msg['Subject'] = """ES file report """+src_table_nm+""" on """+dt
msg['From'] = "Praveen_Kshirsagaray@eogresources.com"
msg['To'] = "Praveen_Kshirsagaray@eogresources.com,Haritha_Atluri@eogresources.com"
 
# The MIME types for text/html
HTML_Contents = MIMEText(html, 'html')
 
# Adding pptx file attachment
filename=archive_file_zip
fo=open(filename,'rb')
attach = email.mime.application.MIMEApplication(fo.read(),_subtype="zip")
fo.close()
attach.add_header('Content-Disposition','attachment',filename=filename)
 
# Attachment and HTML to body message.
msg.attach(attach)
msg.attach(HTML_Contents)
 
 
# Your SMTP server information
s_information = smtplib.SMTP()

s_information.connect('smtp.eogresources.com')

s_information.sendmail(msg['From'], msg['To'], msg.as_string())
s_information.quit()


zip_file="""/home/odmbatch/odm/Scripts/ES_VALIDATION_"""+src_table_nm+"""_"""+dt+""".zip"""
zip_archive_file="""/home/odmbatch/odm/archive/ES_VALIDATION_"""+src_table_nm+"""_"""+dt+""".zip"""

os.rename(validation_file,archive_file)
os.rename(zip_file,zip_archive_file)



