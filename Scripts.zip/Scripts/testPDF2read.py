#!/usr/local/bin/python3


from PyPDF2 import PdfFileReader
def extract_pdfText(path):
   with open(path, 'rb') as f:
      pdf = PdfFileReader(f)
      # get the 50th page
      page = pdf.getPage(0)
      print(page)
      print('Page type: {}'.format(str(type(page))))
      #Extract text from the 50th page
      text = page.extractText()
      print(text)
if __name__ == '__main__':
   path = '/home/odmbatch/odm/Scripts/30015424530000_05_22_2019_02_25_11.pdf'
   extract_pdfText(path)   

