#!/usr/bin/sh

#filename=$1
#fileout=$2
#filename_p="/home/odmbatch/odm/Scripts/""$filename"
#output_filename="/home/odmbatch/odm/Scripts/""$fileout"

filename_p="/home/odmbatch/odm/Scripts/30015451150000_6_wf.txt"
output_filename="/home/odmbatch/odm/Scripts/30015451150000_6_wf.csv"

type_of_well=`grep -n "Type of Well" $filename_p|cut -d ":" -f1`
#echo $type_of_well
value_well=`expr $type_of_well + 4`
v_value_well=`echo "$value_well""p"`
type_well_value=`sed -n $v_value_well $filename_p|awk '{$1=$1;print}'|cut -d '"' -f4`

#echo "$type_well_value"

z1=`echo "$type_well_value"| tr "0" "\n"|awk '{$1=$1;print}'|grep -v "^<U+25A1>"`
#z1=`echo "$type_well_value"| tr "0" "\n"|grep -v "^<U+25A1>"`
#echo $z1
z2=`expr index "$z1" '<U+25A1>'`
#echo $z2
z3=`expr $z2 - 2`
#echo $z3
#echo "${z1:0:$z3}"



grep "Notice of Intent" 30015451150000_6_wf.txt|cut -d '"' -f4|awk '{$1=$1;print}' > /home/odmbatch/odm/Scripts/tmp_type_submission.txt
grep "Subsequent Report" 30015451150000_6_wf.txt|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_submission.txt
grep "Final Abandonment Notice" 30015451150000_6_wf.txt|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_submission.txt


zz1=`cat tmp_type_submission.txt|grep -v "^<U+25A1>"`
zz2=`expr index "$zz1" '<U+25A1>'`
zz3=`expr $zz2 - 2`
#echo ${zz1:1:$zz3}

grep "Acidize" 30015451150000_6_wf.txt|cut -d '"' -f4|awk '{$1=$1;print}' > /home/odmbatch/odm/Scripts/tmp_type_action.txt
grep "Alter Casing" 30015451150000_6_wf.txt|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
grep "Casing Repair" 30015451150000_6_wf.txt|cut -d '"' -f4|awk '{$1=$1;print}'|tail -c 77 >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
grep "Change Plans" 30015451150000_6_wf.txt|cut -d '"' -f4|awk '{$1=$1;print}'|tail -c 77 >> /home/odmbatch/odm/Scripts/tmp_type_action.txt
grep "Convert to Injection" 30015451150000_6_wf.txt|cut -d '"' -f4|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_action.txt


cat tmp_type_action.txt|tr "<U+25A1>" "\n"|tr -s "\n"|grep "0" > /home/odmbatch/odm/Scripts/tmp_type.txt
dtfile="/home/odmbatch/odm/Scripts/tmp_type.txt"
dtfileoutput="/home/odmbatch/odm/Scripts/tmp_type_out.txt"
echo > $dtfileoutput
while read line
do
  #echo "$line"
  ty=`expr index "$line" '0'`
  k=`echo "${line:$ty}"|awk '{$1=$1;print}'`
  echo ${#k}
  echo "${line:$ty}" >> /home/odmbatch/odm/Scripts/tmp_type_out.txt
  if [[ "$k" == 'Other' ]]
  then
   echo "asasasas"
   sed -n '56p' 30015451150000_6_wf.txt|tr -d [0-9]|tr '"' ' '|awk '{$1=$1;print}' >> /home/odmbatch/odm/Scripts/tmp_type_out.txt
  fi


done <$dtfile

wsx=`cat $dtfileoutput|tr "\n" ","|awk '{$1=$1;print}'|sed 's/,//1'|sed 's/ Other,/ Other-/'|sed 's/.$//'`
echo $wsx

