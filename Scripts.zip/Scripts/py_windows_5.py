#!/usr/bin/python3

import sys
import pandas as pd
import csv
import sys
import os
import cx_Oracle
import datetime


with open("/home/odmbatch/odm/Scripts/9-17-19_fluid_shots_1.csv",'r',encoding="utf8", errors='ignore') as f, open("/home/odmbatch/odm/Scripts/9-17-19_fluid_shots_upd.csv",'w') as f1:
    next(f) # skip header line
    for line in f:
        f1.write(line)


df2 = pd.read_csv('/home/odmbatch/odm/Scripts/9-17-19_fluid_shots_1.csv',sep=',',encoding="ISO-8859-1")
data = df2.dropna(subset=['Well ID'])
#print (data)

df3=data.iloc[:,[2,3]]
print(df3)


rows = [tuple(x) for x in df3.values]
print(rows)

connection = cx_Oracle.connect('iprod_dba/Test_123@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)


cursor.executemany("""
        insert into iprod_dba.test_orcl (id, name)
        values (:1, :2)""", rows)


cursor.execute("""commit""")


cursor.close()
connection.close()
