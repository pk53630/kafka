#!/usr/bin/python3
import csv
import sys
import os
import cx_Oracle
import datetime


query=""" SELECT distinct Division_ID FROM ODM_INFO.ODM_COMPLETION WHERE PRIMO_PRPRTY ="""
connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)


lst=[]

with open('/home/odmbatch/odm/Scripts/9-17-19_fluid_shots.csv', 'rb') as f:
    for row in f:
        a=row.decode("utf-8",errors="ignore").split(',')
        lst.append(a)


for i in range(0,len(lst)):
    if ((lst[i][318]) != ""):
        print(query+str(lst[i][318]))
        cursor.execute(query+str(lst[i][318]))
        row = cursor.fetchone()
        DIVISION_ID =(row[0])
        DATE_VALUE = lst[i][0]
        TIME_VALUE = lst[i][1]
        print(DIVISION_ID)
        DATE_TIME = (str(DATE_VALUE)+" "+str(TIME_VALUE))
        print(DATE_TIME)
       	ACOUSTIC_VEL_CALC_METHOD = lst[i][3]
       	ACOUSTIC_VEL = lst[i][2]
       	ANALYIS_METHOD = ""
       	ANCHOR_DEPTH = lst[i][341]
       	AVERAGE_JOINT_LENGTH = lst[i][330]
       	BALANCED_DOWNSTROKE_PEAK = lst[i][60]
       	BALANCED_UPSTROKE_PEACK = lst[i][61]
       	BOTTOMHOLE_TEMPERATURE = lst[i][298]
       	CASING_OD = lst[i][333]
       	CASING_PRESSURE = lst[i][4]
       	CASING_PRESSURE_PSI_FS = ""
       	CBE_METHOD = lst[i][220]
       	CBM_KIN_LB = ""
       	CHANGE_IN_PRESSURE = ""
       	CHANGE_IN_PRESSURE_FS = ""
       	CHANGE_IN_TIME_FS = ""
       	COMMENT_TXT = lst[i][346]
       	COUNTER_BAL_EFF_WEIGHT_LEVEL = ""
       	COUNTER_BALANCE_CHANGE = lst[i][128]
       	CRANKS = ""
       	DAMP_DOWN = ""
       	DAMP_UP = ""
       	DEPTH_MAKER = lst[i][293]
       	DEPTH_TO_DOWNHOLE_MARKER = lst[i][293]
       	DEPTH_TO_LIQ_LEVEL = lst[i][20]
       	ELEVATION = ""
       	EQUIVALENT_GAS_FREE_LIQ_HT = lst[i][25]
       	FILTER_WIDTH = ""
       	FILTER_WIDTH_2 = ""
       	FORMATION_DEPTH = lst[i][336]
       	FORMATION_DEPTH_TVD = ""
       	GAS_FLOW = ""
       	GAS_GRAVITY = lst[i][300]
       	GAS_PRODUCTION = lst[i][26]
       	GAS_PRODUCTION_POTENTIAL = ""
       	GAS_SPECIFIC_GRAVITY = ""
       	GAS_LIQ_INTERFACE_PRESSURE = lst[i][27]
       	GEARBOX_RATING = lst[i][227]
       	HERTZ = lst[i][224]
       	INDICATOR_TIME = ""
       	IPR_METHOD = lst[i][31]
       	JOINT_TO_DOWNHOLE_MARKER = ""
       	JOINTS_COUNT = lst[i][33]
       	JOINTS_PER_SECOND = lst[i][8]
       	JOINTES_TO_LIQ_LEVEL = lst[i][32]
       	KELLEY_BUSHING = lst[i][283]
       	LIQ_CORRECTION_FACTOR = ""
       	MAIN_DEPTH_TO_LIQ_LEVEL_TVD = ""
       	MAIN_DEPTH_TO_LIQ_LEVEL = ""
       	MAIN_JOINTS_TO_LIQ_LEVEL = ""
       	MAIN_TIME_TO_LIQ_LEVEL = ""
       	MANUAL_ACOUSTIC_VEL = lst[i][50]
       	MANUAL_JTS = ""
       	MANUFACTURER = ""
       	MEASURED_DOWNSTROKE_PEAK = lst[i][62]
       	MEASURED_STOKE_LENGTH = lst[i][260]
       	MEASURED_UPSTROKE_PEAK = lst[i][63]
       	METH_ACOUSTIC_VEL_GAS_GRAVITY = ""
       	METH_ACOUSTIC_VEL_PRESSURE = ""
       	METHOD_SELECTION = ""
       	MFG_COMMENTS = ""
       	MOTOR_TYPE = ""
       	OIL_API = lst[i][306]
       	OIL_PRODUCTION = lst[i][35]
       	OIL_PRODUCTION_POTENTIAL = ""
       	OVER_CHANGE_IN_TIME = ""
       	PBHP = lst[i][36]
       	PBHP_SBHP = ""
       	PHASE = ""
       	PLUNGER_DIAMETER = lst[i][338]
       	POLISHED_ROD_DIAMETER = ""
       	POWER_CONSUMPTION = lst[i][240]
       	POWER_DEMAND = lst[i][241]
       	PRODUCING_BHP_DATE = ""
       	PRODUCING_BHP_METHOD = ""
       	PRODUCING_BHP = lst[i][36]
       	PRODUCING_INTERVAL_BOTTOM = ""
       	PRODUCING_INTERVAL_TOP = ""
       	PRODUCTION_DATE = ""
       	PRODUCTION_EFFICIENCY = lst[i][41]
       	PRODUCTION_METHOD = ""
       	PUMP_INTAKE_DEPTH = lst[i][245]
       	PUMP_INTAKE_DEPTH_TVD = ""
       	PUMP_INTAKE_PRESSURE = lst[i][39]
       	RATED_FULL_LOAD_AMP = lst[i][225]
       	RATED_FULL_LOAD_RPM = lst[i][253]
       	RATED_HP = lst[i][126]
       	ROTATION = lst[i][256]
       	RUN_TIME = lst[i][257]
       	STATIC_BHP_DATE = ""
       	STATIC_BHP_METHOD = ""
       	STATIC_BHP = lst[i][44]
       	SURFACE_TEMPERATURE = lst[i][307]
       	SYNCHRONOUS_RPM = lst[i][269]
       	TAPER_2_ROD_DIAMETER = ""
       	TAPER_2_ROD_LENGTH = ""
       	TAPER_2_ROD_TYPE = ""
       	TAPER_3_ROD_DIAMETER = ""
       	TAPER_3_ROD_LENGTH = ""
       	TAPER_3_ROD_TYPE = ""
       	TAPER_4_ROD_DIAMETER = ""
       	TAPER_4_ROD_LENGTH = ""
       	TAPER_4_ROD_TYPE = ""
       	TAPER_5_ROD_DIAMETER = ""
       	TAPER_5_ROD_LENGTH = ""
       	TAPER_5_ROD_TYPE = ""
       	TAPER_6_ROD_DIAMETER = ""
       	TAPER_6_ROD_LENGTH = ""
       	TAPER_6_ROD_TYPE = ""
       	TAPER_7_ROD_DIAMETER = ""
       	TAPER_7_ROD_LENGTH = ""
       	TAPER_7_ROD_TYPE = ""
       	TAPER_8_ROD_DIAMETER = ""
       	TAPER_8_ROD_LENGTH = ""
       	TAPER_8_ROD_TYPE = ""
       	TIME_TO_FIRST_COLLAR = ""
       	TIME_TO_LAST_COLLAR = ""
       	TOP_TAPER_ROD_DIAMETER = lst[i][270]
       	TOP_TAPER_ROD_LENGTH = lst[i][271]
       	TOP_TAPER_ROD_TYPE = lst[i][272]
       	TORQUE_CALC = ""
       	TOTAL_GASEOUS_LIQ_COLUMN_HT = lst[i][24]
       	TUBING_OD = lst[i][343]
       	TUBING_PRESSURE_PSI = lst[i][166]
       	UNIT_API_NUMBER = lst[i][252]
       	UNIT_CLASS = ""
       	VOLTAGE = lst[i][278]
       	WATER_PRODUCTION = lst[i][51]
       	WATER_PRODUCTION_POTENTIAL = ""
       	WATER_SPECIFIC_GRAVITY = lst[i][310]
       	WEIGHT_OF_COUNTER_WEIGHTS = lst[i][279]
       	WELL_STATE = ""
        WELL_ID = lst[i][318]


        #in_query="""INSERT INTO iprod_dba.ECHOMETER_FLUID_SURVEY_test ('DIVISION_ID','WELL_ID','DATE_VALUE','FLUID_LEVEL_SURVEY_DATE','COMMENT_TXT') VALUES (DIVISION_ID,WELL_ID,DATE_TIME,DATE_TIME,COMMENT_TXT) """

        print(DIVISION_ID,WELL_ID,ACOUSTIC_VEL_CALC_METHOD,DATE_TIME,WEIGHT_OF_COUNTER_WEIGHTS,COMMENT_TXT) 

#for result in cursor:
        #    print (result[0])
	
cursor.close()
connection.close()
