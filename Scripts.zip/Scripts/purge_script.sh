#!/bin/sh
################################################################################
#
# Program      :  purge_script.sh
#
# Author       :  Praveen Kumar KS
#
# Created      :  23-Jan-2019
#
# Description  :  This program purge archival logs and zip files
#
################################################################################

find /home/odmbatch/odm/logs/*.log -mtime +5 | xargs rm -f
find /home/odmbatch/odm/archive/*.csv -mtime +5 | xargs rm -f
find /home/odmbatch/odm/archive/*.zip -mtime +5 | xargs rm -f
find /home/odmbatch/odm/data/*.csv -mtime +5 | xargs rm -f

