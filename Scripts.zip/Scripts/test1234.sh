#!/bin/sh

#a=`ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l`
#b=`expr $a + 1`
#echo $b

while [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
   sleep 10
   exit 0
done
