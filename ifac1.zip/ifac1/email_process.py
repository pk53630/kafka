﻿#!/usr/local/bin/python3

# create function to send email
def send_email(sender,msg,recipients,subject):
  print(sender)
  print(msg)
  print(recipients)
  recipients_list = recipients.split(";")
  print(subject)
  email_msg = msg
  email_msg['Subject'] = subject
  email_msg['From'] = sender
  email_msg['To'] = recipients
  try:
     smtpObj = smtplib.SMTP('smtp.eogresources.com')
     smtpObj.sendmail(sender, recipients.split(";"),email_msg.as_string())
     smtpObj.quit()
  except smtplib.SMTPException as exc:
     error = exc.args
     error_msg = error.message
     print(error_msg)

try:
    import os
    import socket
    import smtplib
    from email.mime.text import MIMEText
    import datetime
except exception as e:
    raise e
     
