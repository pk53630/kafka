def order(frame,var):
    varlist =[w for w in frame.columns if w not in var]
    frame = frame[var+varlist]
    return frame

def es_results(res,trace_id,index_type):
    for key,value in res.items():
        if key == 'acknowledged':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           return 'Success'
        elif key == 'error':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           print(value)
           return 'Error'
        elif key == 'status':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})


try:
    import sys
    import configparser
    import cx_Oracle as db
    import os, time, smtplib, socket, datetime
    from email.mime.text import MIMEText
    from elasticsearch import Elasticsearch
    from elasticsearch import helpers
    import pandas as pd
    import json
    from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
    sys.path.append(r"C:\Users\rtati\Documents\python_files")
    import email_process

    pd.options.display.max_colwidth = 1000

    # All Parameters--------------------------------------------------------------------------------------------------------------------
    print(sys.argv[0])
    configfilename = sys.argv[1]
    print(sys.argv[1])
    equipment_id = sys.argv[2]
    print(sys.argv[2])

    es_index_list = [configfilename]
    resultlist =[]


    sender = 'radhika_tati@eogresources.com'
    recipients = 'radhika_tati@eogresources.com'

    subject = 'Equipment ES Process'

    for configfilename in es_index_list:
        try:
            config = configparser.ConfigParser()
            config.read(configfilename)

            #ES email
            es_email_conf = config['EMAIL']
            sender = es_email_conf['EmailFrom']
            recipients = es_email_conf['EmailTo']

            #Elastic Search
            elastic_conf = config['ELASTICSEARCH']
            cluster_name = elastic_conf['ClusterName']
            time_out = int(elastic_conf['TimeOut'])
            host_list = elastic_conf['HostList']
            host_list = host_list.replace("\n", "")
            host_list = host_list.split(',')



            #ES Index Settings to set shards and replicas
            index_settings = {}
            index_settings['settings'] = {}
  
            for key, val in config.items('ESINDEXBODY'):
                        index_settings['settings'][key] = val
            print(index_settings)


            #ES index details
            es_index_conf = config['ESINDEXDETAILS']
            index_name = es_index_conf['IndexName']
            type_name = es_index_conf['TypeName']
            alias_name =  es_index_conf['AliasName']
            ignore =  int(es_index_conf['Ignore'])
            nested_index = es_index_conf['NestedIndex']
            index_id = es_index_conf['IndexFieldId']
            bulk_push_size = int(es_index_conf['BulkPushSize'])
            refresh_interval = es_index_conf['RefreshInterval']
            field_mappings = es_index_conf['IndexFieldMappings']
            field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
            field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))

            print(field_mappings_dict)

            #ES mapping
            es_mapping_conf = config['ELASTICTEMPLATE']
            mapping_file = es_mapping_conf['MappingFile']
            with open('{0}'.format(mapping_file), 'r') as mappingFile:
                    mappings = mappingFile.read()



            #Oracle settings
            db_conf = config['DATABASE']
            connection_string = db_conf['ConnectionString']
            object_name = db_conf['ObjectName']
            where_clause = db_conf['WhereClause']
            sql_path = db_conf['SqlPath']

              # End of all Parameters--------------------------------------------------------------------------------------------------------------------------------------------------------

            # Connect to Oracle 
            try:
                start_time = time.time()
                ora_con = db.Connection(connection_string)
                ora_cursor = ora_con.cursor()
                ora_cursor.arraysize = 10000
                
                with open('{0}'.format(sql_path), 'r') as sqlFile:
                      ora_sql = sqlFile.read()

                where_clause = 'and r.equipment_id = '+equipment_id
                select_query = ora_sql +' '+ where_clause

                print(select_query)

                ora_rows=[]               
                ora_cursor.execute(select_query)
                ora_rows = ora_cursor.fetchall()
                print(ora_rows)

                ora_count = ora_cursor.rowcount
                print(ora_count)

                es_field_names = [(field_mappings_dict[ora_col_name[0].lower()]) for ora_col_name in ora_cursor.description]

                ora_cursor.close()
                ora_con.close()
            except db.DatabaseError as e:
                #error = e.args
                #error_msg = error.message
                print(e)
                raise
                resultlist.append({'traceid':5,'indextype':'Oracle Database Error ','indexname':index_name,'alias_name':alias_name,'message':'Database Error','output':str(e)})

            #connect to elastic search and index setup-----------------------------------------------------------------
            es = Elasticsearch(hosts=host_list,timeout=time_out)

            ora_df = pd.DataFrame(ora_rows,columns=es_field_names)
            print(ora_df)
            ora_df['key']=ora_df['assetUuid']
            ora_df['timestamp']=ora_df['updateTs']
            hdr_list = ['divisionId','equipmentId','assetUuid','assetDesc','assetId','barcode','itemId','itemDesc','categoryId','categoryName','comments','conditionCode','rfId','propertyId','assignmentUuid','propertyNumber','propertySub','propertyName','propertyType','divisionName','serialNumber','stockNumber','startDate','endDate','trend','stateCd','stateName','countyName','fieldName','latitude','longitude','playId','playName','rigId','rigName','subDivisionId','subDivisionName','teamId','teamName','blueWellFl','ecEntityColor','formationNm','operatedFl','operatorName','originationType','phaseName','subphaseName','routeName','foremanName','updateTs','updateUserId','userName','maxApicodNbr','apicodNbr','assocWellId','assocFacilityId','assocUnitFacilityId','wellName','equipSubTypeName','productName','linkId','systemId','systemName','towEquipSk','procountMerrickid','latlong','opStatusCd']
            attr_list = ['divisionId','facilityId','equipmentId','barcode','serialNumber','assetUuid','assetDesc','categoryId','categoryName','startDate','propertyId','propertyName','assetId','itemId','attributeId','attributeName','attributeLevel','attributeGrouping','uiControlCode','sortOrder','isOverridable','valueListId','isActive','itemNumberValue','itemDateValue','itemShortTextValue','itemLongTextValue','itemValueListEntryId','itemValueListEntryDesc','assetNumberValue','assetDateValue','assetShortTextValue','assetLongTextValue','assetValueListEntryId','assetValueListEntryDesc','updateTs','updateUserId','userName']
            df1 = ora_df.groupby(['divisionId','equipmentId','assetId','assetUuid'], as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
            print(df1.head())
            df1['key']=df1['assetUuid']
            df1['assetDesc']=ora_df['assetDesc']
            df1['barcode']=ora_df['barcode']
            df1['itemId']=ora_df['itemId']
            df1['categoryId']=ora_df['categoryId']
            df1['categoryName']=ora_df['categoryName']
            df1['comments']=ora_df['comments']
            df1['conditionCode']=ora_df['conditionCode']
            df1['rfId']=ora_df['rfId']
            df1['propertyId']=ora_df['propertyId']
            df1['assignmentUuid']=ora_df['assignmentUuid']
            df1['propertyNumber']=ora_df['propertyNumber']
            df1['propertySub']=ora_df['propertySub']
            df1['propertyName']=ora_df['propertyName']
            df1['propertyType']=ora_df['propertyType']
            df1['divisionName']=ora_df['divisionName']
            df1['serialNumber']=ora_df['serialNumber']
            df1['stockNumber']=ora_df['stockNumber']
            df1['startDate']=ora_df['startDate']
            df1['endDate']=ora_df['endDate']
            df1['trend']=ora_df['trend']
            df1['stateCd']=ora_df['stateCd']
            df1['stateName']=ora_df['stateName']
            df1['fieldName']=ora_df['fieldName']
            df1['latitude']=ora_df['latitude']
            df1['longitude']=ora_df['longitude']
            df1['playId']=ora_df['playId']
            df1['playName']=ora_df['playName']
            df1['rigId']=ora_df['rigId']
            df1['rigName']=ora_df['rigName']
            df1['subDivisionId']=ora_df['subDivisionId']
            df1['subDivisionName']=ora_df['subDivisionName']
            df1['teamId']=ora_df['teamId']
            df1['teamName']=ora_df['teamName']
            df1['blueWellFl']=ora_df['blueWellFl']
            df1['ecEntityColor']=ora_df['ecEntityColor']
            df1['formationNm']=ora_df['formationNm']
            df1['operatedFl']=ora_df['operatedFl']
            df1['operatorName']=ora_df['operatorName']
            df1['originationType']=ora_df['originationType']
            df1['phaseName']=ora_df['phaseName']
            df1['routeName']=ora_df['routeName']
            df1['subphaseName']=ora_df['subphaseName']
            df1['foremanName']=ora_df['foremanName']
            df1['updateTs']=ora_df['updateTs']
            df1['userName']=ora_df['userName']
            df1['maxApicodNbr']=ora_df['maxApicodNbr']
            df1['apicodNbr']=ora_df['apicodNbr']
            df1['assocWellId']=ora_df['assocWellId']
            df1['assocFacilityId']=ora_df['assocFacilityId']
            df1['assocUnitFacilityId']=ora_df['assocUnitFacilityId']
            df1['wellName']=ora_df['wellName']
            df1['productName']=ora_df['productName']
            df1['linkId']=ora_df['linkId']
            df1['systemId']=ora_df['systemId']
            df1['systemName']=ora_df['systemName']
            df1['towEquipSk']=ora_df['towEquipSk']
            df1['procountMerrickid']=ora_df['procountMerrickid']
            df1['latlong']=ora_df['latlong']
            df1['opStatusCd']=ora_df['opStatusCd']
            df1['timestamp']=ora_df['timestamp']
            df1['itemDesc']=ora_df['itemDesc']
            df1['countyName']=ora_df['countyName']
            df1['updateUserId']=ora_df['updateUserId']
            df1['equipSubTypeName']=ora_df['equipSubTypeName']
            df2 = df1.groupby(['key','latlong','assetId','timestamp'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
            equip_json=df2.to_json(orient='records')
            json_df=json.loads(equip_json)
            json_df[0]

            if es.indices.exists(index_name):
                print('Index eixsts')
                faclist=[]
                for doc in json_df:
                    action = {"_index":index_name,"_type":type_name,"-id":doc['assetId'],"_on_type": "update", "_source": doc }
                    faclist.append(action)
                print(faclist)

                print(faclist)
                success, info = helpers.bulk(es, faclist)
                if not success:
                    print(info)
                    resultlist.append({'traceid':7,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info}) 
                    raise RuntimeError('error bulk')

        except Exception as e:
            print(e)
            resultlist.append({'traceid':4,'indextype':' ','indexname':index_name,'alias_name':alias_name,'message':'unexpected Error','output':str(e)})
            



finally:
    try:
        subject = 'Equipment ES process'
        if len(resultlist) > 0:
           message = 'Equipment ES process complete '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")
           email_process.send_email(sender,MIMEText(str(order(pd.DataFrame(resultlist),['traceid','indexname','alias_name','message','output']).to_html(classes='table',index=False,escape=False)),'html'),recipients,subject)
    except Exception as e:
        message = 'Equipment ES process complete unexpected Error '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")+str(e)
        print(e)
        email_process.send_email(sender,MIMEText(message),recipients,subject)

