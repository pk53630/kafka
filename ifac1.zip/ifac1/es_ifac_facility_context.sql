SELECT fcv.code_value_id "key", fcv.code_value "facility_context"
FROM fdm_dba.fdm_code_value fcv, fdm_dba.fdm_code_value_type fcvt
WHERE fcvt.code_value_type_id = 104
AND fcv.code_descr = 'FACILITY_CONTEXT'
AND fcvt.code_value_type_id = fcv.code_value_type_id
