#!/usr/local/bin/python3
def order(frame,var):
    varlist =[w for w in frame.columns if w not in var]
    frame = frame[var+varlist]
    return frame

def es_results(res,trace_id,index_type):
    for key,value in res.items():
        if key == 'acknowledged':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           return 'Success'
        elif key == 'error':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           #print(value)
           return 'Error'
        elif key == 'status':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})

def replace_value(row):
    new_row=[]
    for i in row:
        for key,value in i.items():
            if value ==-99999:
                i[key]=np.nan
    return row



import sys
import configparser
import cx_Oracle as db
import os, time, smtplib, socket, datetime
from email.mime.text import MIMEText
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import pandas as pd
import numpy as np
import json
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
import email_process
#import resource

#print(resource.getrlimit(resource.RLIMIT_STACK))
print(sys.getrecursionlimit())
sys.setrecursionlimit(15000)
print(sys.getrecursionlimit())

try:
    pd.options.display.max_colwidth = 1000

    # All Parameters--------------------------------------------------------------------------------------------------------------------
    # print(sys.argv[0])

    esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
    config = configparser.ConfigParser()
    config.read(esconfigfilename)

    es_search_conf = config['FIELDOPSESSTAGE']
    print(es_search_conf)
    host_name = es_search_conf['HostName']
    print(host_name)
    time_out = int( es_search_conf['Timeout'])
    print(time_out)
    user = es_search_conf['User']
    print(user)
    password = es_search_conf['Password']
    print(password)
    certs =  es_search_conf['VerifyCerts']
    print(certs)
    header = es_search_conf['Header']
    print(header)
    h = { "Content-type":"application/json" }

    configfilename = '/home/odmbatch/ifacility/es_ipipe_equipment.ini'

    # print(sys.argv[1])
    division_id = 10
    # print(sys.argv[2])
    equipment_id = 0
    facility_id = 0
    eog_user_id = 0

    es_index_list = [configfilename]
    resultlist =[]


    sender = 'radhika_tati@eogresources.com'
    recipients = 'radhika_tati@eogresources.com'

    subject = 'PDATD Pipeline Equipment ES Process'

    for configfilename in es_index_list:
        try:
            config = configparser.ConfigParser()
            config.read(configfilename)

            #ES email
            es_email_conf = config['EMAIL']
            sender = es_email_conf['EmailFrom']
            recipients = es_email_conf['EmailTo']

            #Elastic Search
            #elastic_conf = config['ELASTICSEARCH']
            #cluster_name = elastic_conf['ClusterName']
            #time_out = int(elastic_conf['TimeOut'])
            #host_list = elastic_conf['HostList']
            #host_list = host_list.replace("\n", "")
            #host_list = host_list.split(',')



            #ES Index Settings to set shards and replicas
            index_settings = {}
            index_settings['settings'] = {}

            for key, val in config.items('ESINDEXBODY'):
                        index_settings['settings'][key] = val
            #print(index_settings)


            #ES index details
            es_index_conf = config['ESINDEXDETAILS']
            index_name = es_index_conf['IndexName']
            type_name = es_index_conf['TypeName']
            alias_name =  es_index_conf['AliasName']
            ignore =  int(es_index_conf['Ignore'])
            nested_index = es_index_conf['NestedIndex']
            index_id = es_index_conf['IndexFieldId']
            bulk_push_size = int(es_index_conf['BulkPushSize'])
            refresh_interval = es_index_conf['RefreshInterval']
            field_mappings = es_index_conf['IndexFieldMappings']
            field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
            field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))

            #print(field_mappings_dict)

            #ES mapping
            es_mapping_conf = config['ELASTICTEMPLATE']
            mapping_file = es_mapping_conf['MappingFile']
            with open('{0}'.format(mapping_file), 'r') as mappingFile:
                    mappings = mappingFile.read()



            #Oracle settings
            db_conf = config['DATABASE']
            connection_string = db_conf['ConnectionString']
            sql_path = db_conf['SqlPath']
            sql_query = """WITH res
     AS (SELECT fex.division_id,
                fex.equipment_id,
                RAWTOHEX( e.equipment_guid ) asset_uuid,
                e.asset_id,
                e.item_id,
                e.tow_equip_sk,
                e.procount_merrickid,
                e.equip_status,
                e.flowcal_meter_num,
                e.scada_meter_num,
                e.condition_cd,
                e.serial_nb,
                e.barcode_id,
                e.rf_id,
                e.comments,
                e.asset_desc,
                e.asset_desc_short,
                e.equipment_guid,
                e.active_fl,
                e.product_cd,
                e.link_id,
                e.fdm_lock_fl,
                e.equip_sub_type_name,
                e.product_name,
                e.workflow_status,
                e.workflow_status_ts,
                e.sub_division_id,
                e.sub_division_name,
                e.parent_asset_id,
                fex.start_date,
                fex.end_date,
                fex.system_id,
                fex.assoc_prprty_type,
                fex.assoc_pipe_segment_id,
                fex.assignment_guid,
                fex.op_status_cd,
                fp.pipeline_id,
                fp.pipeline_name,
                fp.pipeline_descr,
                fp.pipeline_type,
                fps.pipe_segment_id,
                fps.imap_pline_id,
                fps.pipe_segment_name,
                fps.commodity_type,
                DECODE(fps.commodity_type,'NG','NATURAL GAS','PRW','PRODUCED WATER','CRD','CRUDE OIL',fps.commodity_type) commodity_type_name,
                fps.status,
                fps.quality,
                fps.length_in_ft,
                fps.pipe_comp,
                fps.gas_type,
                fps.class,
                fps.grade,
                fps.county,
                fps.diameter,
                fps.afe_number,
                fps.budget_year,
                fps.team,
                fps.closed_date,
                fps.pipe_subsystem_name,
                fps.afe_name,
                fps.last_rev,
                fps.type_id,
                fps.year_id,
                fps.version_id,
                fps.full_pl_id,
                fps.paper_book_location,
                fps.electronic_file_location,
                fps.pipe_size,
                fps.length_in_mi,
                fps.parent_segment_id,
                fps.division_name,
                fps.state,
                ci.item_name,
                ci.category_id,
                ci.stock_nb,
                a.attribute_id,
                e.update_ts,
                e.update_user_id,
                (SELECT su.first_name || ' ' || last_name
                   FROM smtp_dba.smt_user su
                  WHERE e.update_user_id = su.user_id(+))
                   user_name,
                a.attribute_name,
                ca.attribute_level,
                a.attribute_grouping,
                a.ui_control_cd ui_control_code,
                NVL (ca.sort_order, 0) sort_order,
                ca.override_fl is_overridable,
                ca.value_list_id,
                ca.active_fl is_active,
                c.category_name
           FROM ifac_dba.ifac_equipment e,
                (SELECT *
                   FROM (SELECT x.*,
                                ROW_NUMBER ()
                                OVER (
                                   PARTITION BY x.division_id, x.equipment_id
                                   ORDER BY x.system_id ASC)
                                   rnum
                           FROM fdm_dba.fdm_pipe_equip_xref x
                          WHERE     system_id IN (100, 102, 128)
                                AND end_date =
                                       TO_DATE ('12/31/3999', 'MM/DD/YYYY')
                                AND x.division_id = 10)
                  WHERE rnum = 1) fex,
                fdm_dba.fdm_pipeline fp,
                fdm_dba.fdm_pipeline_segment fps,
                ifac_dba.ifac_catalog_item ci,
                ifac_dba.ifac_category c,
                (SELECT *
                   FROM ifac_dba.ifac_category_attribute
                  WHERE active_fl = 'Y' AND attribute_level IN ('I', 'A')) ca,
                ifac_dba.ifac_attribute a
          WHERE     e.division_id = fex.division_id
                AND e.equipment_id = fex.equipment_id
                AND fex.division_id = fp.division_id
                AND fex.pipeline_id = fp.pipeline_id
                AND fex.division_id = fps.division_id
                AND fex.assoc_pipe_segment_id = fps.pipe_segment_id
                AND e.item_id = ci.item_id
                AND ci.category_id = c.category_id
                AND ca.category_id = c.category_id
                AND a.attribute_id = ca.attribute_id)
SELECT r.division_id,
       r.equipment_id,
       r.asset_uuid key,
       r.asset_id,
       lower(REGEXP_REPLACE(r.asset_uuid, '(.{8})(.{4})(.{4})(.{4})(.*)', '\1-\2-\3-\4-\5')) asset_uuid,
       r.item_id,
       r.tow_equip_sk,
       r.procount_merrickid,
       r.equip_status,
       r.flowcal_meter_num,
       r.scada_meter_num,
       r.condition_cd,
       r.serial_nb,
       r.barcode_id,
       r.rf_id,
       r.comments,
       r.asset_desc,
       r.asset_desc_short,
       lower(REGEXP_REPLACE(r.equipment_guid, '(.{8})(.{4})(.{4})(.{4})(.*)', '\1-\2-\3-\4-\5')) equipment_guid,
       r.active_fl,
       r.product_cd,
       r.link_id,
       r.fdm_lock_fl,
       r.equip_sub_type_name,
       r.product_name,
       r.workflow_status,
       r.workflow_status_ts,
       r.sub_division_id,
       r.sub_division_name,
       r.parent_asset_id,
       to_char(to_timestamp_tz(to_char(r.start_date,'YYYY-MM-DD'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM') start_date,
       to_char(to_timestamp_tz(to_char(case when r.end_date = to_date('12/31/3999','MM/DD/YYYY') then null else r.end_date end ,'YYYY-MM-DD'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM') end_date,
       r.system_id,
       r.assoc_prprty_type,
       r.assoc_pipe_segment_id,
       lower(REGEXP_REPLACE(r.assignment_guid, '(.{8})(.{4})(.{4})(.{4})(.*)', '\1-\2-\3-\4-\5'))assignment_guid,
       r.op_status_cd,
       r.pipeline_id,
       r.pipeline_name,
       r.pipeline_descr,
       r.pipeline_type,
       r.pipe_segment_id,
       r.imap_pline_id,
       r.pipe_segment_name,
       r.commodity_type,
       r.commodity_type_name,
       r.division_name,
       r.state,
       r.item_name,
       r.category_id,
       r.category_name,
       r.stock_nb,
       r.attribute_id,
       r.update_user_id,
       r.user_name,
       r.attribute_name,
       r.attribute_level,
       r.attribute_grouping,
       r.ui_control_code,
       r.sort_order,
       r.is_overridable,
       r.value_list_id,
       r.is_active,
       TO_CHAR (TO_TIMESTAMP_TZ (TO_CHAR (r.update_ts, 'YYYY-MM-DD"T"HH24:MI:SS'),'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM')update_ts,
       ciav.number_value item_number_value,
       ciav.date_value item_date_value,
       ciav.short_text_value item_short_text_value,
       ciav.long_text_value item_long_text_value,
       ciav.value_list_entry_id item_value_list_entry_id,
       civle.value_list_entry_desc item_value_list_entry_desc,
       eav.number_value asset_number_value,
       eav.date_value asset_date_value,
       eav.short_text_value asset_short_text_value,
       eav.long_text_value asset_long_text_value,
       eav.value_list_entry_id asset_value_list_entry_id,
       evle.value_list_entry_desc asset_value_list_entry_desc,
       TO_CHAR (TO_TIMESTAMP_TZ (TO_CHAR (eav.update_ts, 'YYYY-MM-DD"T"HH24:MI:SS'),'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM')attr_update_ts,
       eav.update_user_id attr_user_id,
       (SELECT su.first_name || ' ' || last_name
          FROM smtp_dba.smt_user su
         WHERE eav.update_user_id = su.user_id(+))
          attr_user_name
  FROM res r,
       ifac_dba.ifac_catalog_item_attr_val ciav,
       ifac_dba.ifac_value_list_entry civle,
       ifac_dba.ifac_equipment_attr_val eav,
       ifac_dba.ifac_value_list_entry evle
 WHERE     ciav.item_id(+) = r.item_id
       AND ciav.attribute_id(+) = r.attribute_id
       AND civle.value_list_entry_id(+) = ciav.value_list_entry_id
       AND eav.asset_id(+) = r.asset_id
       AND eav.attribute_id(+) = r.attribute_id
       AND evle.value_list_entry_id(+) = eav.value_list_entry_id
       AND r.division_id = 10"""
       # End of all Parameters--------------------------------------------------------------------------------------------------------------------------------------------------------

            # Connect to Oracle
            try:
                start_time = time.time()
                ora_con = db.Connection(connection_string)
                ora_cursor = ora_con.cursor()
                ora_cursor.arraysize = 10000
                lrc_cursor = ora_con.cursor()



                ora_rows=[]
                #ora_cursor.callproc(sql_path,[division_id,equipment_id,facility_id,eog_user_id,lrc_cursor])
                ora_cursor.execute(sql_query)
                ora_rows = ora_cursor.fetchall()
                print(ora_rows)

                ora_count = lrc_cursor.rowcount
                print(ora_count)

                es_field_names = [(field_mappings_dict[ora_col_name[0].lower()]) for ora_col_name in ora_cursor.description]
                print(es_field_names)
                #lrc_cursor.close()
                ora_cursor.close()
                ora_con.close()
            except db.DatabaseError as e:
                #error = e.args
                #error_msg = error.message
                #print(e)
                raise
                resultlist.append({'traceid':5,'indextype':'Oracle Database Error ','indexname':index_name,'alias_name':alias_name,'message':'Database Error','output':str(e)})

            #connect to elastic search and index setup-----------------------------------------------------------------
            #es = Elasticsearch(hosts=host_name,timeout=time_out)
            es = Elasticsearch(
                        hosts = host_name,#esdatanodes
                        timeout = time_out, # increase timeout from default 10s to 120s
                        http_auth=(user,password),
                        verify_certs=certs,
                        headers = h
                              )
            request_body= index_settings

            start_time=time.time()
            # Check if the index doesnot exist and create
            if not es.indices.exists(index_name):
                res = es.indices.create(index= index_name, body=request_body)
                print(res)
                output=es_results(res,1,'index create')
                if output=='Error':
                    raise
                print("Index created")
                print ("Time taken to create ES Index : %s seconds " % (time.time() - start_time))

            #res=es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=ignore)
            #print(res)
            #output=es_results(res,3,'index mapping')
            #if output=='Error':
            #   raise
            ora_df = pd.DataFrame(ora_rows,columns=es_field_names)
            #print(ora_df)
            ora_df['timestamp']=ora_df['updateTs']
            hdr_list = ['divisionId','equipmentId','key','assetId','assetUuid','itemId','towEquipSk','procountMerrickid','equipStatus','flowcalMeterNum','scadaMeterNum','conditionCd','serialNb','barcodeId','rfId','comments','assetDesc','assetDescShort','equipmentGuid','activeFl','productCd','linkId','fdmLockFl','equipSubTypeName','productName','workflowStatus','workflowStatusTs','subDivisionId','subDivisionName','parentAssetId','startDate','endDate','systemId','assocPrprtyType','assocPipeSegmentId','assignmentGuid','opStatusCd','pipelineId','pipelineName','pipelineDescr','pipelineType','pipeSegmentId','imapPlineId','pipeSegmentName','commodityType','commodityTypeName','divisionName','state','itemName','categoryId','categoryName','updateTs','updateUserId','userName']
            attr_list = ['divisionId','pipelineId','pipeSegmentId','equipmentId','barcodeId','serialNb','assetUuid','assetDesc','categoryId','categoryName','startDate','assetId','itemId','attributeId','attributeName','attributeLevel','attributeGrouping','uiControlCode','sortOrder','isOverridable','valueListId','isActive','itemNumberValue','itemDateValue','itemShortTextValue','itemLongTextValue','itemValueListEntryId','itemValueListEntryDesc','assetNumberValue','assetDateValue','assetShortTextValue','assetLongTextValue','assetValueListEntryId','assetValueListEntryDesc','updateTs','updateUserId','userName']
            for i in es_field_names:
                print(i)
                ora_df[i]=ora_df[i].replace(np.nan,-99999)
            #ora_df = ora_df.replace(np.nan,-99999)
            df1 = ora_df.groupby(hdr_list, as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
            #df1 = ora_df.groupby(['divisionId','equipmentId','assetId','assetUuid','key','groupName','groupId','groupGuid','parentObjectId','groupAssetUuid','groupType'], as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
    
                
            print(list(df1))
            #print(list(df1['attributes']))
            for i in list(df1):
                print(i)
                df1[i]=df1[i].replace(-99999,np.nan)
            df1['attributes']= df1['attributes'].apply(lambda row: replace_value(row))
            hdr_list = ['divisionId','equipmentId','key','assetId','assetUuid','itemId','towEquipSk','procountMerrickid','equipStatus','flowcalMeterNum','scadaMeterNum','conditionCd','serialNb','barcodeId','rfId','comments','assetDesc','assetDescShort','equipmentGuid','activeFl','productCd','linkId','fdmLockFl','equipSubTypeName','productName','workflowStatus','workflowStatusTs','subDivisionId','subDivisionName','parentAssetId','startDate','endDate','systemId','assocPrprtyType','assocPipeSegmentId','assignmentGuid','opStatusCd','pipelineId','pipelineName','pipelineDescr','pipelineType','pipeSegmentId','imapPlineId','pipeSegmentName','commodityType','commodityTypeName','divisionName','state','itemName','categoryId','categoryName','updateTs','updateUserId','userName','attributes']
            df2 = df1.groupby(['key','assetId'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
            equip_json=df2.to_json(orient='records')
            json_df=json.loads(equip_json)
            json_df[0]
            if es.indices.exists(index_name):
            #print('Index eixsts')
                faclist=[]
                for doc in json_df:
                    action = {"_index":index_name,"_type":type_name,"_id":doc['assetId'],"_on_type": "update", "_source": doc}
                    faclist.append(action)
                success, info = helpers.bulk(es, faclist)
                if not success:
                    #print(info)
                    resultlist.append({'traceid':7,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info})
                    raise RuntimeError('error bulk')
         
                

        except Exception as e:
            print(e)
            resultlist.append({'traceid':4,'indextype':' ','indexname':index_name,'alias_name':alias_name,'message':'unexpected Error','output':str(e)})




finally:
    try:
        subject = 'houvlxodmtest:Pipe Line Equipment ES process'
        if len(resultlist) > 0:
            message = 'R1DATD Pipe line Equipment ES process complete '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")
            #email_process.send_email(sender,MIMEText(str(order(pd.DataFrame(resultlist),['traceid','indexname','alias_name','message','output']).to_html(classes='table',index=False,escape=False)),'html'),recipients,subject)
    except Exception as e:
        message = 'PDATD Equipment ES process complete unexpected Error '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")+str(e)
        print(e)
        email_process.send_email(sender,MIMEText(message),recipients,subject)


