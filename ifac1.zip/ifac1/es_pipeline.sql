SELECT fp.division_id
        , fp.pipeline_id
        , fp.pipeline_descr
        , fp.pipeline_name
        , fp.pipeline_type
        , fps.pipe_segment_id
        , fps.imap_pline_id
        , fps.pipe_segment_name
        , fps.commodity_type
        , DECODE(fps.commodity_type,'NG','NATURAL GAS','PRW','PRODUCED WATER','CRD','CRUDE OIL',fps.commodity_type) commodity_type_name
        , fps.status
        , fps.quality
        , fps.length_in_ft
        , fps.pipe_comp
        , fps.gas_type
        , fps.class
        , fps.grade
        , fps.county
        , fps.diameter
        , fps.afe_number
        , fps.budget_year
        , fps.team
        , fps.closed_date
        , fps.pipe_subsystem_name
        , fps.afe_name
        , fps.last_rev
        , fps.type_id
        , fps.year_id
        , fps.version_id
        , fps.full_pl_id
        , fps.paper_book_location
        , fps.electronic_file_location
        , fps.pipe_size
        , fps.length_in_mi
        , fps.primo_prprty
        , fps.primo_prpsub
        , (Select distinct state_name from ke_dba.ke_state ks, ke_dba.ke_county kc where kc.state_cd = ks.state_cd and kc.county_name = fps.county and state_abbr=fps.state) state_name
        , (select division_name from fdm_dba.fdm_division where division_id = fp.division_id) division_name
        , piggable
        , cygnet_fl
        , min_latitude
        , min_longitude
        , max_latitude
        , max_longitude
        , mid_latitude
        , mid_longitude
        , CASE WHEN mid_latitude||','||mid_longitude <> ',' THEN  min_latitude||','||min_longitude END min_latlong
        , CASE WHEN max_latitude||','||max_longitude <> ',' THEN  max_latitude||','||max_longitude END max_latlong
        , CASE WHEN mid_latitude||','||mid_longitude <> ',' THEN  mid_latitude||','||mid_longitude END mid_latlong
        , leg_name
     FROM fdm_dba.fdm_pipeline fp, fdm_dba.fdm_pipeline_segment fps
    WHERE fp.division_id = fps.division_id
      AND fp.pipeline_id = fps.pipeline_id
      --AND fps.imap_pline_id <> '10-'
