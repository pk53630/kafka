SELECT division_id||'-'||team_id "key"
       , division_id
       , team_id
       , team_name
FROM ( SELECT distinct division_id
              , team_id
              , team_name
       FROM odm_info.odm_well
      )