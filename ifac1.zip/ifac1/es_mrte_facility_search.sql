SELECT MRTE_PRPRTY_ID||PRIMO_PRPRTY||PRIMO_PRPSUB "key",
    mrx.DIVISION_ID ,
    DIVISION_CODE       ,
    mfs.FACILITY_ID "ACTUAL_FACILITY_ID",
    FACILITY_NAME       ,
    PRIMO_PRPRTY        ,
    PRIMO_PRPSUB        ,
    mrx.ROUTE_ID    ,
    SC_GRS_OIL_PY       ,
    SC_GRS_GAS_PY       ,
    SC_GRS_WTR_PY       ,
    ALERT_COUNT ,
    SORT_ORDER  ,
    INBOX_COUNT ,
    TO_CHAR (CAST (mfs.update_ts AS TIMESTAMP (3)) AT TIME ZONE 'America/Chicago', 'YYYY-MM-DD"T"hh24:mi:ss') "SC_LAST_FETCH_TS",
    PROD_VOL_SOURCE     ,
    ALLOC_VOL_SOURCE    ,
    TO_CHAR (CAST (mfs.update_ts AS TIMESTAMP (3)) AT TIME ZONE 'America/Chicago', 'YYYY-MM-DD"T"hh24:mi:ss') "UPDATE_TS",
    CASE WHEN ABS(LATITUDE) <=90 THEN LATITUDE ELSE NULL END LATITUDE,
    CASE WHEN ABS(LONGITUDE)    <= 180 THEN LONGITUDE ELSE NULL END LONGITUDE,
    CASE WHEN ABS(LATITUDE) <=90 AND ABS(LONGITUDE) <= 180 THEN LATLONG ELSE NULL END LATLONG,
    mr.FOREMAN_NAME        ,
    mr.ROUTE_NAME  ,
    'FA' "PROPERTY_TYPE",
    mrx.MRTE_PRPRTY_ID "FACILITY_ID",
    mfs.facility_type_name,
    mfs.property_id,
    CASE WHEN omr.route_id IS NOT NULL THEN 'Y' ELSE 'N' END "IS_CUSTOM",
    mfs.route_stop_id,
    mfs.route_stop_name,
    mfs.assoc_completion_id,
    mfs.assoc_comp_prprty_id,
    mfs.division_name,
    mfs.area_name,
    rawtohex(ml.list_guid) list_guid
FROM mrte_dba.mrte_facility_search mfs,
     mrte_dba.mrte_fac_route_xref mrx,
     mrte_dba.mrte_route mr,
     mrte_dba.odc_mrte_route omr,
     mrte_dba.mrte_list ml
WHERE mfs.division_id = mrx.division_id
  AND mfs.facility_id = mrx.facility_id
  AND mrx.division_id = mr.division_id
  AND mrx.route_id = mr.route_id
  AND mrx.division_id = omr.division_id(+)
  AND mrx.route_id = omr.route_id(+)
  AND mrx.division_id = ml.division_id(+)
  AND mrx.route_id = ml.route_id(+)

