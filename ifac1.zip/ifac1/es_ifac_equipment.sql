WITH res
     AS (SELECT division_id
              , equipment_id
              , asset_uuid
              , asset_desc
              , asset_id
              , barcode
              , item_id
              , item_desc
              , category_id
              , category_name
              , comments
              , condition_code
              , rf_id
              , property_id
              , assignment_uuid
              , property_number
              , property_sub
              , property_name
              , property_type
              , division_name
              , serial_number
              , stock_number
              , start_date
              , end_date
              , trend
              , state_cd
              , state_name
              , county_name
              , field_name
              , latitude
              , longitude
              , play_id
              , play_name
              , rig_id
              , rig_name
              , sub_division_id
              , sub_division_name
              , team_id
              , team_name
              , blue_well_fl
              , ec_entity_color
              , formation_nm
              , operated_fl
              , operator_name
              , origination_type
              , phase_name
              , subphase_name
              , route_name
              , foreman_name
              , update_ts
              , update_user_id
              , user_name
              , max_apicod_nbr
              , apicod_nbr
              , assoc_well_id
              , assoc_facility_id
              , assoc_unit_facility_id
              , well_name
              , equip_sub_type_name
              , product_name
              , link_id
              , system_id
              , system_name
              , tow_equip_sk
              , procount_merrickid
              , CASE WHEN latlong = ',' THEN NULL ELSE latlong END latlong
              , op_status_cd
              , attribute_id
              , attribute_name
              , attribute_level
              , attribute_grouping
              , ui_control_code
              , sort_order
              , is_overridable
              , value_list_id
              , is_active
              , facility_id
           FROM ( SELECT 
                        e.division_id
                       , e.equipment_id
                       , RAWTOHEX( e.equipment_guid ) asset_uuid
                       , e.asset_desc
                       , CASE WHEN e.asset_id > 0 THEN e.asset_id ELSE NULL END asset_id
                       , e.barcode_id barcode
                       , CASE WHEN e.item_id > 0 THEN e.item_id ELSE NULL END item_id
                       , ci.item_name item_desc
                       , c.category_id
                       , UPPER( c.category_name ) category_name
                       , e.comments
                       , e.condition_cd condition_code
                       , e.rf_id
                       , ( CASE
                             WHEN fex.assoc_well_id > 0 THEN LPAD( ow.primo_prprty || ow.primo_prpsub, 9, 0 )
                             WHEN fex.assoc_unit_facility_id > 0 THEN LPAD( fu.primo_prprty || fu.primo_prpsub, 9, 0 )
                             WHEN fex.assoc_facility_id > 0 THEN LPAD( f.primo_prprty || f.primo_prpsub, 9, 0 )
                          END )
                            property_id
                       , RAWTOHEX( assignment_guid ) assignment_uuid
                       , ( CASE
                             WHEN fex.assoc_well_id > 0 THEN ow.primo_prprty
                             WHEN fex.assoc_unit_facility_id > 0 THEN fu.primo_prprty
                             WHEN fex.assoc_facility_id > 0 THEN f.primo_prprty
                          END )
                            property_number
                       , ( CASE
                             WHEN fex.assoc_well_id > 0 THEN ow.primo_prpsub
                             WHEN fex.assoc_unit_facility_id > 0 THEN fu.primo_prpsub
                             WHEN fex.assoc_facility_id > 0 THEN f.primo_prpsub
                          END )
                            property_sub
                       , ( CASE
                             WHEN fex.assoc_well_id > 0 THEN ow.well_name
                             WHEN fex.assoc_unit_facility_id > 0 THEN fu.unit_facility_name
                             WHEN fex.assoc_facility_id > 0 THEN f.facility_name
                          END )
                            property_name
                       , fex.assoc_prprty_type property_type
                       , (select d.division_name from fdm_dba.fdm_division d where e.division_id = d.division_id) division_name
                       , e.serial_nb serial_number
                       , ci.stock_nb stock_number
                       , fex.start_date
                       , fex.end_date
                       , ow.trend
                       , ow.state_cd
                       , ow.state_name
                       , ow.county_name
                       , ow.field_name
                       , ow.latitude
                       , ow.longitude
                       , ow.play_id
                       , ow.play_name
                       , ow.rig_id
                       , ow.rig_name
                       , ow.sub_division_id
                       , ow.sub_division_name
                       , ow.team_id
                       , ow.team_name
                       , ow.blue_well_fl
                       , ow.ec_entity_color
                       , ow.formation_nm
                       , ow.operated_fl
                       , oc.operator_name
                       , ow.origination_type
                       , ow.phase_name
                       , ow.subphase_name
                       , oc.route_name
                       , oc.foreman_name
                       , e.update_ts
                       , e.update_user_id
                       , (select su.first_name || ' ' || last_name from  smtp_dba.smt_user su where e.update_user_id = su.user_id(+))user_name
                       , oc.max_apicod_nbr
                       , oc.apicod_nbr
                       , CASE WHEN fex.assoc_well_id > 0 THEN fex.assoc_well_id ELSE NULL END assoc_well_id
                       , CASE WHEN fex.assoc_facility_id > 0 THEN fex.assoc_facility_id ELSE NULL END assoc_facility_id
                       , CASE WHEN fex.assoc_unit_facility_id > 0 THEN fex.assoc_unit_facility_id ELSE NULL END assoc_unit_facility_id
                       , ow.well_name
                       , e.equip_sub_type_name
                       , e.product_name
                       , e.link_id
                       , fex.system_id
                       , ( SELECT code_value
                             FROM fdm_dba.fdm_code_value
                            WHERE code_value_id = fex.system_id )
                            system_name
                       , fex.request_id
                       , fex.request_type
                       , CASE WHEN e.tow_equip_sk > 0 THEN e.tow_equip_sk ELSE NULL END tow_equip_sk
                       , CASE WHEN e.procount_merrickid > 0 THEN e.procount_merrickid ELSE NULL END procount_merrickid
                       , ( CASE
                             WHEN fex.assoc_well_id > 0 THEN ow.latitude || ',' || ow.longitude
                             WHEN fex.assoc_unit_facility_id > 0 THEN fu.latitude || ',' || fu.longitude
                             WHEN fex.assoc_facility_id > 0 THEN f.latitude || ',' || f.longitude
                          END )
                            latlong
                       , fex.op_status_cd
                       , a.attribute_id
                       , a.attribute_name
                       , ca.attribute_level
                       , a.attribute_grouping
                       , a.ui_control_cd ui_control_code
                       , NVL( ca.sort_order, 0 ) sort_order
                       , ca.override_fl is_overridable
                       , ca.value_list_id
                       , ca.active_fl is_active
                       , fex.facility_id
                    FROM ifac_dba.ifac_equipment e
                       , (SELECT *
                            FROM (SELECT x.*, ROW_NUMBER( ) OVER( PARTITION BY x.division_id, x.equipment_id ORDER BY x.system_id ASC ) rnum
                                    FROM fdm_dba.fdm_fac_equip_xref x
                                   WHERE system_id IN ( 100, 102, 128 )
                                     AND end_date = TO_DATE( '12/31/3999', 'MM/DD/YYYY' ))
                           WHERE rnum = 1) fex
                       , fdm_dba.fdm_facility f
                       , fdm_dba.fdm_facility ff
                       , fdm_dba.fdm_unit_facility fu
                       , odm_info.odm_well ow
                       , ( SELECT *
                             FROM ( SELECT division_id
                                         , well_id
                                         , foreman_name
                                         , operator_name
                                         , route_name
                                         , primo_apicod apicod_nbr
                                         , LAST_VALUE( primo_apicod ) OVER( PARTITION BY well_id,primo_prprty ORDER BY primo_apicod ASC ) max_apicod_nbr
                                      FROM odm_info.odm_completion )
                            WHERE apicod_nbr = max_apicod_nbr ) oc
                       , ifac_dba.ifac_catalog_item ci
                       , ifac_dba.ifac_category c
                       , (SELECT *
                            FROM ifac_dba.ifac_category_attribute
                           WHERE active_fl = 'Y'
                             AND attribute_level IN ( 'I', 'A' )) ca
                       , ifac_dba.ifac_attribute a
                   WHERE e.division_id = fex.division_id
                     AND e.equipment_id = fex.equipment_id
                     AND e.asset_id > 0
                     AND e.item_id = ci.item_id
                     AND ci.category_id = c.category_id
                     AND fex.division_id = ff.division_id
                     AND fex.facility_id = ff.facility_id
                     AND ff.active_flag = 'Y'
                     AND fex.division_id = f.division_id(+)
                     AND fex.assoc_facility_id = f.facility_id(+)
                     AND fex.division_id = fu.division_id(+)
                     AND fex.assoc_unit_facility_id = fu.unit_facility_id(+)
                     AND fex.division_id = ow.division_id(+)
                     AND fex.assoc_well_id = ow.well_id(+)
                     AND ow.division_id = oc.division_id(+)
                     AND ow.well_id = oc.well_id(+)
                     AND ca.category_id = c.category_id
                     AND a.attribute_id = ca.attribute_id ))
SELECT r.division_id
     , r.equipment_id
     , r.asset_uuid
     , r.asset_desc
     , r.asset_id
     , r.barcode
     , r.item_id
     , r.item_desc
     , r.category_id
     , r.category_name
     , r.comments
     , r.condition_code
     , r.rf_id
     , r.property_id
     , r.assignment_uuid
     , r.property_number
     , r.property_sub
     , r.property_name
     , r.property_type
     , r.division_name
     , r.serial_number
     , r.stock_number
     , r.start_date start_date
     , case when r.end_date = to_date('12/31/3999','MM/DD/YYYY') then null else r.end_date end  end_date
     , r.trend
     , r.state_cd
     , r.state_name
     , r.county_name
     , r.field_name
     , r.latitude
     , r.longitude
     , r.play_id
     , r.play_name
     , r.rig_id
     , r.rig_name
     , r.sub_division_id
     , r.sub_division_name
     , r.team_id
     , r.team_name
     , r.blue_well_fl
     , r.ec_entity_color
     , r.formation_nm
     , r.operated_fl
     , r.operator_name
     , r.origination_type
     , r.phase_name
     , r.subphase_name
     , r.route_name
     , r.foreman_name
     , r.update_ts
     , r.update_user_id
     , r.user_name
     , r.max_apicod_nbr
     , r.apicod_nbr
     , r.assoc_well_id
     , r.assoc_facility_id
     , r.assoc_unit_facility_id
     , r.well_name
     , r.equip_sub_type_name
     , r.product_name
     , r.link_id
     , r.system_id
     , r.system_name
     , r.tow_equip_sk
     , r.procount_merrickid
     , r.latlong
     , r.op_status_cd
     , r.attribute_id
     , r.attribute_name
     , r.attribute_level
     , r.attribute_grouping
     , r.ui_control_code
     , r.sort_order
     , r.is_overridable
     , r.value_list_id
     , r.is_active
     , r.facility_id
     , ciav.number_value item_number_value
     , ciav.date_value item_date_value
     , ciav.short_text_value item_short_text_value
     , ciav.long_text_value item_long_text_value
     , ciav.value_list_entry_id item_value_list_entry_id
     , civle.value_list_entry_desc item_value_list_entry_desc
     , eav.number_value asset_number_value
     , eav.date_value asset_date_value
     , eav.short_text_value asset_short_text_value
     , eav.long_text_value asset_long_text_value
     , eav.value_list_entry_id asset_value_list_entry_id
     , evle.value_list_entry_desc asset_value_list_entry_desc
     , eav.update_ts attr_update_ts
     , eav.update_user_id attr_user_id
     , (select su.first_name || ' ' || last_name from  smtp_dba.smt_user su where eav.update_user_id = su.user_id(+))attr_user_name
  FROM res r
     , ifac_dba.ifac_catalog_item_attr_val ciav
     , ifac_dba.ifac_value_list_entry civle
     , ifac_dba.ifac_equipment_attr_val eav
     , ifac_dba.ifac_value_list_entry evle
 WHERE ciav.item_id(+) = r.item_id
   AND ciav.attribute_id(+) = r.attribute_id
   AND civle.value_list_entry_id(+) = ciav.value_list_entry_id
   AND eav.asset_id(+) = r.asset_id
   AND eav.attribute_id(+) = r.attribute_id
   AND evle.value_list_entry_id(+) = eav.value_list_entry_id

