# -*- coding: utf-8 -*-
"""
Created on Mon Jun 10 12:11:29 2019

@author: Jterrell
"""

import configparser
import cx_Oracle
import pymssql
import sys

configfilename = '/home/odmbatch/ifacility/TankCapacity.ini'

config = configparser.ConfigParser()
config.read(configfilename)

db_conf = config['DATABASE']
connection_string = db_conf['ConnectionString']
object_name = db_conf['ObjectName']
where_clause = db_conf['WhereClause']


div_id = sys.argv[1]
SQL = ''

if (div_id == "10"):
    SQL = db_conf['SerSql_10']
    ora_SQL = db_conf['OraSql_10']
elif (div_id == "14"):
    SQL = db_conf['SerSql_14']
    ora_SQL = db_conf['OraSql_14']
elif (div_id == "30"):
    SQL = db_conf['SerSql_30']
    ora_SQL = db_conf['OraSql_30']
elif (div_id == "45"):
    SQL = db_conf['SerSql_45']
    ora_SQL = db_conf['OraSql_45']
elif (div_id == "50"):
    SQL = db_conf['SerSql_50']
    ora_SQL = db_conf['OraSql_50']
elif (div_id == "60"):
    SQL = db_conf['SerSql_60']
    ora_SQL = db_conf['OraSql_60']
elif (div_id == "63"):
    SQL = db_conf['SerSql_63']
    ora_SQL = db_conf['OraSql_63']
elif (div_id == "301"):
    SQL = db_conf['SerSql_301']
    ora_SQL = db_conf['OraSql_301']
else:
    print("The Division Id entered is not in List")


#print(SQL)
#print(ora_SQL)

if (SQL != '' and (div_id == "10" or div_id == "14" or div_id == "30" or div_id == "63" or div_id == "45")):
    #  Step 1 - Load CygNet Views
    MSconn = pymssql.connect(host = db_conf['Host'], user = db_conf['User'], password = db_conf['Password'], database = db_conf['Database'])
    MScursor = MSconn.cursor(as_dict=True)
    ##SQL = "select primoID, Templates1, SCADAID from [CygNet].[dbo].[Midland_Facilities] where Templates1 like '%Tank%' and SCADAID is not null"
    MScursor.execute(SQL)
    MidTanks = MScursor.fetchall()
    MScursor.close()
    MidTankDict = {}
    for Tank in MidTanks:
        InsertObj = {} 
        if (div_id == "14" or div_id == "45" or div_id == "63"):
            InsertObj["id"] = Tank["meternumber"]
        else:
            InsertObj["id"] = Tank["SCADAID"]
        
        InsertObj["primo"] = Tank["primoID"]
        InsertObj["cygnetDesignation"] = Tank["Templates1"]
        
        if (div_id == "14" or div_id == "45" or div_id == "63"):
            MidTankDict[Tank["meternumber"]] = InsertObj
        else:
            MidTankDict[Tank["SCADAID"]] = InsertObj


    #print (MidTankDict)
    ORAconn = cx_Oracle.connect('MRTE_ADMIN/Test_789@R1DATE.eogresources.com')
    ORAcursor = ORAconn.cursor()
    ORAUpdatecursor = ORAconn.cursor()

    # Wells
    #print(ora_SQL)
    ORAcursor.execute(ora_SQL)
    Wells = ORAcursor
    ProTanks = {}

    for record in Wells:
        try:
            #print(record)
            #print(MidTankDict[record[0]])
            if str(record[1]) == str(div_id):
                SQL_upd = "UPDATE fdm_dba.fdm_equipment SET PRIMO_prprty = " + str(MidTankDict[record[0]]["primo"]) + ", CYGNET_DESIGNATION  = '" + str(MidTankDict[record[0]]["cygnetDesignation"]) + "' WHERE SCADA_ID = '" + str(MidTankDict[record[0]]["id"]) + "' AND DIVISION_id = " + div_id
                #print (SQL_upd)
                ORAUpdatecursor.execute(SQL_upd)
                result = ORAconn.commit()
        except:
            DoNothing = 0
else:
    print("The entered division_id is not in, the list is 10,14,30,45,50,60,63,301")


