SELECT division_id "key"
     , division_id
     , division_name
     , division_code 
FROM odm_dba.odm_division
