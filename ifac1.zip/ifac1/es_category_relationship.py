#!/usr/local/bin/python3
import sys
import configparser
import logging
import cx_Oracle
import os, time, smtplib, socket, datetime
from elasticsearch import Elasticsearch
import json
import pandas as df
import cx_Oracle as db
import pandas.io.sql as psql
from elasticsearch import helpers
from email.mime.text import MIMEText

#os.environ['ORACLE_HOME'] = '/oracle/app/oracle/product/11.2.0/dbhome_1'
#os.environ['LD_LIBRARY_PATH'] = '/oracle/app/oracle/product/11.2.0/dbhome_1/lib'

hostnm=socket.gethostname()

email_from = "odm_team@eogresources.com"
email_to = "radhika_tati@eogresources.com"
email_subject = hostnm.upper() + " Category Relationship ES Index"

def send_email(email_from, email_to, email_subject, email_msg):
    email_msg = MIMEText(email_msg)
    email_msg['Subject'] = email_subject
    email_msg['From'] = email_from
    email_msg['To'] = email_to

    try:
        smtpObj = smtplib.SMTP('smtp.eogresources.com')
        smtpObj.sendmail(email_from, [email_to], email_msg.as_string())
        smtpObj.quit()
    except smtplib.SMTPException as exc:
        error, = exc.args
        error_msg = error.message
        print(error_msg)

esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
config = configparser.ConfigParser()
config.read(esconfigfilename)
es_search_conf = config['FIELDOPSESSTAGE']
print(es_search_conf)

host_name = es_search_conf['HostName']
print(host_name)
time_out = int( es_search_conf['Timeout'])
print(time_out)
user = es_search_conf['User']
print(user)
password = es_search_conf['Password']
print(password)
certs =  es_search_conf['VerifyCerts']
print(certs)
header = es_search_conf['Header']
print(header)
h = { "Content-type":"application/json" }

es = Elasticsearch(
                   hosts = host_name,
                   timeout = time_out, 
                   http_auth=(user,password),
                   verify_certs=certs,
                   headers = h
                   )        

print(es.info())

ora_con = db.connect('ifac_dba/Test_345@r1date.eogresources.com')
#ora_con = db.connect('iapps_read_only/iaRO2$13@pdatd.eogresources.com')

try:
    start_time = time.time()

#    fac_query = """SELECT parent_category_id||'-'||child_category_id "key"
#    ,  parent_category_id "parentCategoryId"
#,      parent_category_name "parentCategoryName"
#,      child_category_id "childCategoryId"
#,      child_category_name "childCategoryName"
#,      comments
#,      active_fl "activeFl"
#FROM ifac_dba.IFAC_CATEGORY_RELATIONSHIP"""
    fac_query = """SELECT parent_category_id "key"
    ,  parent_category_id "parentCategoryId"
    ,      parent_category_name "parentCategoryName"
    ,      LISTAGG( child_category_id, ',' ) WITHIN GROUP (ORDER BY child_category_id)  "childCategoryList"
     FROM ifac_dba.IFAC_CATEGORY_RELATIONSHIP
     GROUP BY parent_category_id,parent_category_name"""
    #fac_df = psql.read_sql_query(fac_query, ora_con)
    #print(fac_df)
    ora_cur = ora_con.cursor()
    ora_cur.execute(fac_query)
    ora_rows=[]
    for row in ora_cur:
        row1=[]
        for i in range(len(row)):
            print(i)
            if i==3:
                list_value = []
                list_value=row[i]
                print(list_value)
                #row1.append(row[i].read())
                row1.append(list_value.split(','))
                #row1.append(clob_value)
            else:
                row1.append(row[i])
        print(row1)
        ora_rows.append(row1)
except cx_Oracle.DatabaseError as exc:
    error, = exc.args
    error_msg = error.message
    send_email(email_from, email_to, email_subject+": FAILED", error_msg) 


try:
    fac_df = df.DataFrame.from_records(ora_rows, columns= ['key','parentCategoryId','parentCategoryName','childCategoryList'])
    fac_json = fac_df.to_json(orient = "records")

    # Load each record into json format before bulk
    json_df= json.loads(fac_json)
    json_df[0]

    if es.indices.exists('ifacility_category_rel'):
        print("ifacility_category_rel index exists")
        start_time = time.time()
        faclist = []
        for doc in json_df:
            action = { "_index": 'ifacility_category_rel', "_type": 'ifacility_category_rel',"_id":doc['key'],"_on_type": "update", "_source": doc }
            faclist.append(action)
        print(faclist)

        for success, info in helpers.parallel_bulk(es, faclist, thread_count=2, chunk_size=7000):
                end_time= time.time()
                #print(end_time)
                if not success:
                    print("response", info)
                    email_body="Error While loading metadata Index"
                    send_email(email_from, email_to, email_subject+": INFO", email_body)
                
    else:
        start_time = time.time()
        request_body = {
            "settings" : {
                "number_of_shards": 1,
                "number_of_replicas":1
            }
        }
        es.indices.create(index='ifacility_category_rel', ignore=400,body=request_body)
        mappings = {
        "dynamic_templates": [{
                "integers": {
                "match_mapping_type": "integer",
                "mapping": {
                  "type": "float"
                }
              }
            },
                              {

                "string_fields": {
                  "mapping": {
                    "index": "analyzed",
                    "omit_norms": True,
                    "type": "string",
                    "fields": {
                      "raw": {
                        "ignore_above": 256,
                        "index": "not_analyzed",
                        "type": "string"
                      }                
                    }
                  },
                  "match": "*",
                  "match_mapping_type": "string"
                }
              }]
        }
        es.indices.put_mapping(index='ifacility_category_rel', doc_type='ifacility_category_rel', body=mappings, ignore=400)
        faclist = []
        for doc in json_df:
            action = { "_index": 'ifacility_category_rel', "_type": 'ifacility_category_rel',"_id":doc['key'],"_on_type": "update", "_source": doc }
            faclist.append(action)

        for success, info in helpers.parallel_bulk(es, faclist, thread_count=2, chunk_size=7000):
                end_time = time.time()
                if not success:
                    print("response", info) 
                    email_body="Error While loading ifacility_category_rel Index"
                    send_email(email_from, email_to, email_subject+": INFO", email_body)
                #else:
                    #email_body="Facility Index Load Success"
                    #print(email_body)
                    #print("response", info)
                    #send_email(email_from, email_to, email_subject+": INFO", email_body)
finally:
    total_time = (end_time - start_time)
    email_body="ifacility_category_rel Index Load Success"+" "+"time taken"+" "+str(total_time)
    send_email(email_from, email_to, email_subject, email_body)
