select DISTINCT fp.division_id,
       fp.pipeline_id,
       fp.pipeline_name,
       fp.pipeline_descr,
       fp.primo_prprty,
       fp.primo_prpsub,
       fp.pipeline_type,
       first_value(fps.county) over (partition by fps.pipeline_id) county,
       first_value(fps.state) over (partition by fps.pipeline_id) state,
       first_value(fps.team) over (partition by fps.pipeline_id) team,
       fd.division_name,
       29814 facility_type_id,
       'PIPELINE' facility_type_name
from fdm_dba.fdm_pipeline fp, fdm_dba.fdm_pipeline_segment fps, fdm_dba.fdm_division fd
where fp.division_id = fps.division_id
and fp.pipeline_id = fps.pipeline_id
and fp.division_id = fd.division_id
