#!/usr/local/bin/python3

import sys
from elasticsearch import Elasticsearch
import cx_Oracle as db
import datetime
from fdm_log_utl import run_sql_stmt
import configparser

######################################################################################################
# Description:
# File created for to Delete  from iMaterial, iTrack and iFacility
#               which are no longer required.
#  Created on : 11-20-2018
#  Created By : Vijaya prasad
#----------------------------------------------------------------------------------------------------
#  Ver no   Modified By      Modified Date               Description
#   0.1
#
#######################################################################################################

# Arguments declaration
#user_id = sys.argv[1]

# Variables and constants delcaration section
user_id = 0
startTs = datetime.datetime.now()
startTs = str(startTs)
start_ts = (startTs)[:-7]
# Logging parameter and their sequence
# division_id, job_status_id, complete_load_fl, ora_err_code, ora_err_message,
# job_message, start_ts, end_ts, last_run_ts, record_count, create_user
# update_user, job_exception_fl, job_summary_fl, job_status

#-------------------------------------------------------
#   Logging
#-------------------------------------------------------
division_id = 0
complete_load_fl = "'Y'"
job_status_id = "'RUNNING'"
ora_err_code = 0
ora_err_message = "''"
job_message = "'Start Elastic search delete process for iTrack'"
record_count = 0
create_user = "'0'"
update_user = "'0'"
job_exception_fl = "'N'"
job_summary_fl = "'N'"
job_status = "'RUNNING'"
package_name = "'es_del_asset'"
procedure_name = "'es_del_asset.py'"
table_name = "'elastic_search'"
dml_operation_name = "'DELETE'"
job_Id = "'LOAD_ES_DEL_ASSET'"
errorFlag = 'N'
run_sql_stmt(division_id,
                job_status_id,
                complete_load_fl,
                ora_err_code,
                ora_err_message,
                job_message,
                '''to_date(' '''+start_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                "Null",
                "Null",
                package_name,
                procedure_name,
                table_name,
                dml_operation_name,
                record_count,
                create_user,
                update_user,
                job_exception_fl,
                job_summary_fl,
                job_status,
                job_Id)
try:
    esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
    config = configparser.ConfigParser()
    config.read(esconfigfilename)

    es_search_conf = config['FIELDOPSESSTAGE']
    host_name = es_search_conf['HostName']
    time_out = int( es_search_conf['Timeout'])
    user = es_search_conf['User']
    password = es_search_conf['Password']
    certs =  es_search_conf['VerifyCerts']
    header = es_search_conf['Header']
    h = { "Content-type":"application/json" }
    es = Elasticsearch(
                       hosts = host_name,
                       timeout = time_out,
                       http_auth=(user,password),
                       verify_certs=certs,
                       headers = h
                       )
    #print('Success elastic login')
    #-------------------------------------------------------
    #   Logging for Elastic search login
    #-------------------------------------------------------

    job_status_id = "'RUNNING'"
    job_message = "'Elastic search logon is success for "+host_name+"'"
    job_exception_fl = "'N'"
    job_summary_fl = "'N'"
    job_status = "'RUNNING'"
    run_sql_stmt(division_id,
                    job_status_id,
                    complete_load_fl,
                    ora_err_code,
                    ora_err_message,
                    job_message,
                    '''to_date(' '''+start_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                    "Null",
                    "Null",
                    package_name,
                    procedure_name,
                    table_name,
                    dml_operation_name,
                    record_count,
                    create_user,
                    update_user,
                    job_exception_fl,
                    job_summary_fl,
                    job_status,
                    job_Id)

    ora_con = db.connect('fdm_load/FdmLoad_201807@r1date.eogresources.com')
    cur = ora_con.cursor()

    lSqlQuery = '''
    SELECT ASSET_ID FROM aud_dba.ima_property_asset aud
     WHERE audit_dml_type = 'D' and audit_ts >= sysdate -30
       AND NOT EXISTS ( SELECT 1 FROM im_dba.im_property_asset
                        WHERE asset_id = aud.asset_id)
    '''

    cur.execute(lSqlQuery)
    data = cur.fetchall()

    if not data:
    #-------------------------------------------------------
    #   Logging
    #-------------------------------------------------------
        job_status_id = "'RUNNING'"
        job_message = "'No assets found in iTrack for Delete.'"
        job_exception_fl = "'N'"
        job_summary_fl = "'N'"
        job_status = "'RUNNING'"
        endTs = datetime.datetime.now()
        endTs = str(endTs)
        end_ts = (endTs)[:-7]
        run_sql_stmt(division_id,
                        job_status_id,
                        complete_load_fl,
                        ora_err_code,
                        ora_err_message,
                        job_message,
                        '''to_date(' '''+start_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                        '''to_date(' '''+end_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                        "Null",
                        package_name,
                        procedure_name,
                        table_name,
                        dml_operation_name,
                        record_count,
                        create_user,
                        update_user,
                        job_exception_fl,
                        job_summary_fl,
                        job_status,
                        job_Id)
    else:
        deletedCount1 = 0
        deletedCount2 = 0
        deletedAssets = ''
        alreadyDeletedAssets = ''
        for i in data:
            Asset = list(i)
            es_query = """
            {
             "size" : 9064,
             "query": { "bool": { "should": [ { "match": { "object.assetId":"""+str(Asset[0])+"""}} ] } }
            }"""
            result = es.search(index = 'ifacility_asset_changes',scroll = '2m',size = 1000,body = es_query )
            hits = result['hits']['hits']
            maxScore = result['hits']['max_score']
            total = result['hits']['total']
    #        print('maxScore :',maxScore)
    #        print('total :',total)
            if maxScore is None and total == 0:
                alreadyDeletedAssets = alreadyDeletedAssets+','+str(Asset[0])
                deletedCount1 = deletedCount1 + 1
            else:
                try:
                    assetId = result['hits']['hits'][0]['_source']['object']['assetId']
                    indexName = result['hits']['hits'][0]['_index']
                    typeName = result['hits']['hits'][0]['_type']
                    Id = result['hits']['hits'][0]['_id']
                    divisionId = result['hits']['hits'][0]['_source']['object']['divisionId']
    #                print('index :',indexName)
    #                print('type :',typeName)
    #                print('asset id :',assetId)
    #                print('id :',Id)
    #                print('Division id', divisionId)
                    res = es.delete(index=indexName, doc_type=typeName, id=Id)
    #                print('deleted..... elastic asset id', Id)
                    deletedAssets = deletedAssets+','+str(assetId)
                    deletedCount2 = deletedCount2 + 1;
                except:
                    the_type, the_value, the_traceback = sys.exc_info()
                    errMsg = str(the_type)+', '+str(the_value)
                    errMsg = errMsg.replace("'","")
                    #-------------------------------------------------------
                    #   Logging for Error occured at Asset deleted.
                    #-------------------------------------------------------
                    division_id = divisionId
                    job_status_id = "'FAILED'"
                    ora_err_message = "'Python Error for Assest Id : "+str(assetId)+"'"
                    job_message = "'Error : "+errMsg+"'"
                    job_status = "'FAILED'"
                    job_summary_fl = "'N'"
                    ora_err_code = 1
                    run_sql_stmt(division_id,
                                    job_status_id,
                                    complete_load_fl,
                                    ora_err_code,
                                    ora_err_message,
                                    job_message,
                                    '''to_date(' '''+start_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                                    "Null",
                                    "Null",
                                    package_name,
                                    procedure_name,
                                    table_name,
                                    dml_operation_name,
                                    record_count,
                                    create_user,
                                    update_user,
                                    job_exception_fl,
                                    job_summary_fl,
                                    job_status,
                                    job_Id)
    #-------------------------------------------------------
    #   Logging for already deleted assets
    #-------------------------------------------------------
        job_status_id = "'RUNNING'"
        ora_err_code = 0
        ora_err_message = "'Assets has been deleted in iTrack, iFacility and iMaterial thru ES in previous run.'"
        record_count = deletedCount1
        job_exception_fl = "'N'"
        job_summary_fl = "'N'"
        job_status = "'RUNNING'"
        assestData = [alreadyDeletedAssets[start:start+1985] for start in range(0, len(alreadyDeletedAssets), 1985)]
        i = 0
        for asset in assestData:
            i = i +1
            job_message = "'Line "+str(i)+' :'+asset+"'"
            run_sql_stmt(division_id,
                        job_status_id,
                        complete_load_fl,
                        ora_err_code,
                        ora_err_message,
                        job_message,
                        '''to_date(' '''+start_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                        "Null",
                        "Null",
                        package_name,
                        procedure_name,
                        table_name,
                        dml_operation_name,
                        record_count,
                        create_user,
                        update_user,
                        job_exception_fl,
                        job_summary_fl,
                        job_status,
                        job_Id)
    #-------------------------------------------------------
    #   Logging for currently deleted assets
    #-------------------------------------------------------
        job_status_id = "'RUNNING'"
        ora_err_message = "'Assets are deleted from iTract'"
        record_count = deletedCount2
        job_exception_fl = "'N'"
        job_summary_fl = "'N'"
        job_status = "'RUNNING'"
        assestData = [deletedAssets[start:start+1995] for start in range(0, len(deletedAssets), 1995)]
        i = 0
        for asset in assestData:
            i = i +1
            job_message = "'Line "+str(i)+':'+asset+"'"
            run_sql_stmt(division_id,
                        job_status_id,
                        complete_load_fl,
                        ora_err_code,
                        ora_err_message,
                        job_message,
                        '''to_date(' '''+start_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                        "Null",
                        "Null",
                        package_name,
                        procedure_name,
                        table_name,
                        dml_operation_name,
                        record_count,
                        create_user,
                        update_user,
                        job_exception_fl,
                        job_summary_fl,
                        job_status,
                        job_Id)
except:
    the_type, the_value, the_traceback = sys.exc_info()
    errMsg = str(the_type)+', '+str(the_value)
    errMsg = errMsg.replace("'","")
    #-------------------------------------------------------
    #   Logging for exception occured any of ES or Oracle
    #-------------------------------------------------------
    division_id = 0
    job_status_id = "'FAILED'"
    ora_err_message = "'Exception occured any of ES or Oracle'"
    job_message = "'Error : "+errMsg+"'"
    job_status = "'FAILED'"
    job_summary_fl = "'Y'"
    ora_err_code = 1
    errorFlag = 'Y'
    endTs = datetime.datetime.now()
    endTs = str(endTs)
    end_ts = (endTs)[:-7]
    run_sql_stmt(division_id,
                    job_status_id,
                    complete_load_fl,
                    ora_err_code,
                    ora_err_message,
                    job_message,
                    '''to_date(' '''+start_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                    '''to_date(' '''+end_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                    "Null",
                    package_name,
                    procedure_name,
                    table_name,
                    dml_operation_name,
                    record_count,
                    create_user,
                    update_user,
                    job_exception_fl,
                    job_summary_fl,
                    job_status,
                    job_Id)
finally:
    #-------------------------------------------------------
    #   Logging for final record
    #-------------------------------------------------------
    job_status_id = "'SUCCESS'"
    ora_err_message = "''"
    job_message = "'Assets delete process end.'"
    record_count = 0
    job_exception_fl = "'N'"
    if errorFlag == 'Y':
        job_summary_fl = "'N'"
    else:
        job_summary_fl = "'Y'"
    job_status = "'SUCCESS'"
    endTs = datetime.datetime.now()
    endTs = str(endTs)
    end_ts = (endTs)[:-7]
    run_sql_stmt(division_id,
                    job_status_id,
                    complete_load_fl,
                    ora_err_code,
                    ora_err_message,
                    job_message,
                    '''to_date(' '''+start_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                    '''to_date(' '''+end_ts+'''','RRRR-MM-DD HH24:MI:SS')''',
                    "Null",
                    package_name,
                    procedure_name,
                    table_name,
                    dml_operation_name,
                    record_count,
                    create_user,
                    update_user,
                    job_exception_fl,
                    job_summary_fl,
                    job_status,
                    job_Id)
    print('success')
    cur.close()
    ora_con.close()
