SELECT al.alert_id "key"
    ,  al.alert_id
    , al.alert_status_id
    , al.active_fl
    , al.division_id
    , al.create_ts
    , al.alarm_time
    , al.alarm_type
    , al.alarm_value
    , al.facility_desc "property_name"
    , al.primo_id
    , al.priority
    , al.property_type
    , al.reason_code
    , al.reason_code_required
    , al.route_id
    , al.severity
    , al.severity_id
    , al.alarm_clear_Time
    , al.point_id_long  
    , ack.acknowledge_ts
    , ack.first_name
    , ack.last_name
FROM ial_dba.ial_alert_wide_vw al 
   , ial_dba.ial_acknowledgement_vw ack
WHERE al.alert_id = ack.alert_id(+)
AND 1=1
AND al.active_fl = 'Y'
