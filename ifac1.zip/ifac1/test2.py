from datetime import datetime, timedelta
import configparser
from elasticsearch import Elasticsearch
index_name = 'cygnet_tag_data'+"_10"+datetime.now().strftime ("%Y%m%d")
alias_name = 'es_cygnet_tags'
print(index_name)

esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
config = configparser.ConfigParser()
config.read(esconfigfilename)

es_search_conf = config['FIELDOPSESSTAGE']
print(es_search_conf)
host_name = es_search_conf['HostName']
print(host_name)
time_out = int( es_search_conf['Timeout'])
print(time_out)
esuser = es_search_conf['User']
print(esuser)
espassword = es_search_conf['Password']
print(espassword)
certs =  es_search_conf['VerifyCerts']
print(certs)
header = es_search_conf['Header']
print(header)
h = { "Content-type":"application/json" }

es = Elasticsearch(
            hosts = host_name,#esdatanodes
            timeout = time_out, # increase timeout from default 10s to 120s
            http_auth=(esuser,espassword),
            verify_certs=certs,
            headers = h
                  )

indices = list(es.indices.get(alias_name+'*', ignore=[400,404]))
print(indices)


