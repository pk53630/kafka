###############################################################################
#Usage: Load Data from Elastic Index for iLoe  to ODM
#
#Source: iLoe Elastic Index miloe_entity_summary_net
#
#Target: Stage Table in MRTE_DBA
#
#Purpose: To show Loe data in miRoute/iRoute App
#
#Developed By: Vasudha Putta
#Start Date: 03/21/2019
###############################################################################
import sys
import os
import socket
import time
import datetime
import logging
import configparser
import smtplib
from email.mime.text import MIMEText
from elasticsearch import Elasticsearch
import cx_Oracle as db

SYS_HOSTNAME = socket.gethostname()
SCRIPT_NAME = os.path.basename(sys.argv[0]).replace('.py', '')

ESCONFIGFILENAME = '/home/odmbatch/ece_es_credentials.ini'
ESCONFIG = configparser.ConfigParser()
ESCONFIG.read(ESCONFIGFILENAME)

ES_SEARCH_CONF = ESCONFIG['ILOE']
HOST_NAME = ES_SEARCH_CONF['HostName']
TIME_OUT = int(ES_SEARCH_CONF['Timeout'])
ESUSER = ES_SEARCH_CONF['User']
ESPASSWORD = ES_SEARCH_CONF['Password']
CERTS = ES_SEARCH_CONF['VerifyCerts']
HEADER = ES_SEARCH_CONF['Header']

H = {"Content-type": "application/json"}

CONFIGFILENAME = '/home/odmbatch/ifacility/iloe_es_to_oracle.ini'
CONFIG = configparser.ConfigParser()
CONFIG.read(CONFIGFILENAME)

#Oracle Credentials
ORACONF = CONFIG['IEORACLE']
ORA_HOST = ORACONF['Host']
ORA_USER_NAME = ORACONF['User']
ORA_PASSWORD = ORACONF['Password']

#Oracle Credentials
ODMORACONF = CONFIG['ODMORACLE']
ODM_ORA_HOST = ODMORACONF['Host']
ODM_ORA_USER_NAME = ODMORACONF['User']
ODM_ORA_PASSWORD = ODMORACONF['Password']

#Email
EMAILCONF = CONFIG['EMAIL']
EMAIL_FROM = EMAILCONF['EMAIL_FROM']
EMAIL_TO = EMAILCONF['EMAIL_TO']

#Logging Details
LOGCONF = CONFIG['LOGGING']
LOG_DIR = LOGCONF['LOG_DIR']

#Elastic Details
ESCONF = CONFIG['ELASTIC']
INDEX_NAME = ESCONF['INDEX_NAME']
TYPE_NAME = ESCONF['TYPE_NAME']
SCROLL = ESCONF['SCROLL']
SIZE = ESCONF['SIZE']

####################################################################################################
def send_email(email_msg):
    EMAIL_SUBJECT = SYS_HOSTNAME + ' : ' + SCRIPT_NAME + ' : ' + time.strftime("%d-%m-%Y %H:%M:%S")
    
    EMAIL_MSG = MIMEText(email_msg)
    EMAIL_MSG['Subject'] = EMAIL_SUBJECT
    EMAIL_MSG['From'] = EMAIL_FROM
    EMAIL_MSG['To'] = EMAIL_TO

    try:
        smtpObj = smtplib.SMTP('smtp.eogresources.com')
        smtpObj.sendmail(EMAIL_FROM, EMAIL_TO.split(','),EMAIL_MSG.as_string())
        smtpObj.quit()

    except smtplib.SMTPException as exc:
        error, = exc.args
        error_msg = error.message
        logging.critical(error_msg)

##################################################################################################
def get_oracle_connection(ora_host, ora_user_name, ora_password):
    try:
        ora_conn_str = ora_user_name+"/"+ora_password+"@"+ora_host
        logging.info('CONNECTIOn STRING : %s' %(ora_conn_str))
        ora_con = db.connect(ora_conn_str)       

        return ora_con
    except db.DatabaseError as e:
        error, = e.args
        error_msg = error.message
        logging.critical(error_msg)
        send_email(str(error_msg))
        raise

################################################################################################
def get_date_id():
    try:
        logging.info("IE ORACLE HOST : %s" %(ORA_HOST))
        logging.info("IE ORACLE USERNAME : %s" %(ORA_USER_NAME))

        ie_db_con = get_oracle_connection(ORA_HOST, ORA_USER_NAME, ORA_PASSWORD)
        ie_ora_cursor = ie_db_con.cursor()
        ie_ora_query = "SELECT date_id FROM ie_dba.ie_date\
                        WHERE TRUNC(date_value) = TRUNC(LAST_DAY(ADD_MONTHS(SYSDATE,-2)))"

        logging.info("IE ORACLE QUERY : %s" %(ie_ora_query))

        ie_ora_result = ie_ora_cursor.execute(ie_ora_query).fetchall()

        ie_df = []
        ie_df = ie_ora_result

        return ie_df
    except db.DatabaseError as err:
        error, = err.args
        error_msg = error.message
        logging.critical(ie_ora_query)
        logging.critical(error_msg)
        send_email(str(error_msg))
    finally:
        try:
            #Closing the Cursor and Connection
            ie_ora_cursor.close()
            ie_db_con.close()
        except:
            pass

def main():
    log_filename = LOG_DIR+SCRIPT_NAME+'_'+SYS_HOSTNAME+'_'+datetime.date.strftime(datetime.datetime.today(),"%m%d%Y%H%M%S")+'.log'

    try:
        logging.basicConfig(filename=log_filename, format='%(levelname)s:%(asctime)s:%(message)s', level=logging.INFO)

        date_id_df = []
        date_id_df = get_date_id()
        for i in date_id_df:
            date_id = i[0]

        logging.info("Date Id Fetched : %s" %(date_id))
        logging.info("ES HOST : %s" %(HOST_NAME))
        logging.info("ES TIME OUT : %s" %(TIME_OUT))
        logging.info("ES USER : %s" %(ESUSER))

        es = Elasticsearch(
            hosts=HOST_NAME,  # esdatanodes
            timeout=TIME_OUT,#time_out,  # increase timeout from default 10s to 120s
            http_auth=(ESUSER, ESPASSWORD),
            verify_certs='False',
            headers=H)

        res = es.search(index=INDEX_NAME,
                        doc_type=TYPE_NAME,
                        scroll=SCROLL,
                        body={
                            'size' : SIZE,
                            'query': {
                                "query_string": {"query": " dateId:"+str(date_id)}
                            }
                            })

        #Set the scroll size
        sid = res['_scroll_id']

        logging.info("INITIAL SID : %s" %(sid))

        #Get Total Document Size
        scroll_size = res['hits']['total']

        logging.info("SCROLL SIZE : %s" %(scroll_size))
        logging.info("Oracle Host : %s" %(ODM_ORA_HOST))
        logging.info("Oracle User : %s" %(ODM_ORA_USER_NAME))

        odm_db_con = get_oracle_connection(ODM_ORA_HOST, ODM_ORA_USER_NAME, ODM_ORA_PASSWORD)
        odm_ora_cursor = odm_db_con.cursor()

        #Start Scrolling
        while scroll_size > 0:
            rows = []            
            logging.info("Document Count : %s" %(len(res['hits']['hits'])))
            for doc in res['hits']['hits']:
                for field in doc['_source']:
                    if field == 'originalDivisionNumber':
                        division_id = doc['_source']['originalDivisionNumber']

                    if field == 'entityId':
                        entity_id = doc['_source']['entityId']

                    if field == 'dateId':
                        date_id = doc['_source']['dateId']

                    if field == 'actualTotalLOE':
                        actual_total_iloe = doc['_source']['actualTotalLOE']

                    if field == 'actualBOE':
                        actual_boe = doc['_source']['actualBOE']

                    if field == 'routeListId':
                        route_list_id = doc['_source']['routeListId']

                    if field == 'primoId':
                        primo_id = doc['_source']['primoId']

                rec = [division_id, entity_id, route_list_id, primo_id, date_id, actual_boe, actual_total_iloe]

                rows.append(rec)

            ora_query = ("MERGE INTO mrte_dba.mrte_iloe_data tgt\
                         USING (\
                        SELECT :DIVISION_ID division_id\
						     , :ENTITY_ID entity_id\
							 , :ROUTE_LIST_ID route_list_id\
							 , :PRIMO_ID primo_id\
							 , :DATE_ID date_id\
							 , :ACTUAL_BOE actual_boe\
							 , :ACTUAL_TOTAL_ILOE actual_total_iloe\
                        FROM DUAL)\
                        src\
                        ON\
                        (tgt.division_id = src.division_id\
						AND tgt.entity_id = src.entity_id\
						AND tgt.date_id = src.date_id\
                         )\
                         WHEN MATCHED THEN\
                         UPDATE SET tgt.actual_boe = src.actual_boe\
						          , tgt.actual_total_iloe = src.actual_total_iloe\
                                  , tgt.update_ts = SYSDATE\
                         WHERE NVL(tgt.actual_boe,-9999) <> NVL(src.actual_boe ,-9999)\
						    OR NVL(tgt.actual_total_iloe,-9999) <> NVL(src.actual_total_iloe ,-9999)\
                        WHEN NOT MATCHED THEN\
                        INSERT  (tgt.DIVISION_ID \
                                ,tgt.ENTITY_ID\
                                ,tgt.ROUTE_LIST_ID\
                                ,tgt.PRIMO_ID\
                                ,tgt.DATE_ID\
                                ,tgt.ACTUAL_BOE\
                                ,tgt.ACTUAL_TOTAL_ILOE\
                                ,tgt.CREATE_TS\
                                ,tgt.UPDATE_TS\
                               )\
                        VALUES (src.DIVISION_ID \
                              , src.ENTITY_ID\
                              , src.ROUTE_LIST_ID\
                              , src.PRIMO_ID\
                              , src.DATE_ID\
                              , src.ACTUAL_BOE\
                              , src.ACTUAL_TOTAL_ILOE\
                              , SYSDATE\
                              ,SYSDATE\
                              )")

            logging.info("ORACLE QUERY : %s" %(ora_query))

            odm_ora_cursor.executemany(ora_query, rows)     

            logging.info("Rows Merged/Inserted : %s" %(odm_ora_cursor.rowcount))

            odm_db_con.commit()

            logging.info('Scrolling......')
            res = es.scroll(scroll_id = sid, scroll = '2m') 

            #update scroll id
            sid = res['_scroll_id']
            logging.info('NEXT SID : %s' %(sid))

            # Get the number of results that we returned in the last scroll
            scroll_size = len(res['hits']['hits'])
            logging.info('SCROLL SIZE : %s' %(scroll_size))

    except db.DatabaseError as err:
        error, = err.args
        error_msg = error.message
        logging.critical(ora_query)
        logging.critical(error_msg)
        send_email(str(error_msg))
    except Exception as ex:
        send_email(str(ex))
    finally:
        try:
            odm_ora_cursor.close()
            odm_db_con.close()
        except:
            pass

if __name__ == "__main__":
    try:
        main()
    except BaseException as error:
        send_email(str(error))
        raise
    except Exception as excep:
        send_email(str(excep))
        raise
