 SELECT  mps.pipe_segment_id||mps.primo_prprty||mps.primo_prpsub "key" 
      ,   mps.division_id
      ,   mps.division_code
      ,   mps.pipe_segment_id 
      ,   mps.pipe_segment_name 
      ,   mps.pipeline_id 
      ,   mps.pipeline_name
      ,   mps.primo_prprty
      ,   mps.primo_prpsub
      ,   mps.leg_name
      ,   mps.update_ts
      ,   mps.latitude
      ,   mps.longitude
      ,   mps.latlong
      ,   'PL' "property_type"
      FROM    mrte_dba.mrte_pipeline_search mps
