import json
import multiprocessing as mp
import os
import sys
import time
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from elasticsearch import Elasticsearch, helpers
import socket, smtplib
import cx_Oracle as db
from email.mime.text import MIMEText
import logging
import configparser

def  send_mail(recipients,subject, msg):
    host = socket.gethostname()
    sender = host + "@eogresources.com"
    smtp_host = "smtp.eogresources.com"
    email_msg = msg
    email_msg['Subject'] = subject
    email_msg['From'] = sender
    email_msg['To'] = recipients
    smtpObj = smtplib.SMTP(smtp_host)
    smtpObj.sendmail(sender, recipients, email_msg.as_string())

def replace_value(row):
    new_row=[]
    for i in row:
        for key,value in i.items():
            if value ==-99999:
                i[key]=np.nan
    return row

def div_group(ora_con,eog_user_id):
    cur=ora_con.cursor()
    lrc_cursor=ora_con.cursor()
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_ifac_division',[eog_user_id,lrc_cursor])
    ora_rows=[]
    ora_rows = lrc_cursor.fetchall()
    lrc_cursor.close()
    cur.close()
    print(ora_rows)
    ora_rows = [x[0] for x in ora_rows]
    return ora_rows

def div_parallel_threads(div_data,eog_user_id):
    if __name__ == '__main__':
        pt=mp.Pool(4)
        params = [(division_id,eog_user_id) for division_id in div_data]
        df_results = pt.map(load_asset,params)
        print(df_results)
        pt.close()
        pt.join()
    return df_results

def create_index(index_name,type_name):
    mapping_file="ifac_equip_mapping.json"
    with open('{0}'.format(mapping_file), 'r') as mappingFile:
                            mappings = mappingFile.read()
    shards = 1
    replicas = 0
    es.indices.create(index=index_name, ignore=400, body={"number_of_shards":shards,"number_of_replicas":replicas})
    es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
    es.indices.put_settings(index=index_name, body={"index": {"refresh_interval": "-1"}})

def parallel_generator(ora_rows,index_name,type_name,es_field_names):
    for row in ora_rows:
        data_dict = {}
        data_dict = dict(zip(es_field_names, row))
        yield {
                '_index': index_name,
                '_type': type_name,
                '_id': data_dict['assetId'],
                '_source': data_dict
            }

def category_info(ora_con,eog_user_id,division_id):
    cur=ora_con.cursor()
    lrc_cursor=ora_con.cursor()
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_ifac_category',[eog_user_id,division_id,lrc_cursor])
    ora_rows=[]
    ora_rows = lrc_cursor.fetchall()
    lrc_cursor.close()
    cur.close()
    ora_rows = [x[0] for x in ora_rows]
    return ora_rows 

def div_equip_data(division_id,catgeory_id,ora_con,eog_user_id):
    cur=ora_con.cursor()
    lrc_cursor=ora_con.cursor()
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_ifac_asset_changes_es',[division_id,0,0,catgeory_id,eog_user_id,lrc_cursor])
    ora_rows=[]
    ora_rows = lrc_cursor.fetchall()
    #print(ora_rows)
    ora_count = lrc_cursor.rowcount
    print(ora_count)
    configfilename = 'es_ifac_equipment.ini'
    es_index_list = [configfilename]
    for configfilename in es_index_list:
        config = configparser.ConfigParser()
        config.read(configfilename)
        es_index_conf = config['ESINDEXDETAILS']
        field_mappings = es_index_conf['IndexFieldMappings']
        field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
        field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))
    es_field_names=[(field_mappings_dict[ora_col_name[0].lower()]) for ora_col_name in lrc_cursor.description]
    final_json={}
    if ora_count>0:
        ora_df = pd.DataFrame(ora_rows,columns=es_field_names)
        ora_df['timestamp']=ora_df['updateTs']
        hdr_list = ['timestamp','key','divisionId','equipmentId','assetUuid','assetDesc','assetId','barcode','itemId','itemDesc','categoryId','categoryName','comments','conditionCode','rfId','propertyId','assignmentUuid','propertyNumber','propertySub','propertyName','propertyType','divisionName','serialNumber','stockNumber','startDate','endDate','trend','stateCd','stateName','countyName','fieldName','latitude','longitude','playId','playName','rigId','rigName','subDivisionId','subDivisionName','teamId','teamName','blueWellFl','ecEntityColor','formationNm','operatedFl','operatorName','originationType','phaseName','subphaseName','routeName','foremanName','updateTs','updateUserId','userName','maxApicodNbr','apicodNbr','assocWellId','assocFacilityId','assocUnitFacilityId','wellName','equipSubTypeName','productName','linkId','systemId','systemName','towEquipSk','procountMerrickid','latlong','opStatusCd','groupId','groupName','groupGuid','parentObjectId','groupAssetUuid','groupType','workflowStatus','workflowStatusTs','versionGuid','opStatusReasonCd','parentAssetId']
        attr_list = ['divisionId','facilityId','equipmentId','barcode','serialNumber','assetUuid','assetDesc','categoryId','categoryName','startDate','propertyId','propertyName','assetId','itemId','attributeId','attributeName','attributeLevel','attributeGrouping','uiControlCode','sortOrder','isOverridable','valueListId','isActive','itemNumberValue','itemDateValue','itemShortTextValue','itemLongTextValue','itemValueListEntryId','itemValueListEntryDesc','assetNumberValue','assetDateValue','assetShortTextValue','assetLongTextValue','assetValueListEntryId','assetValueListEntryDesc','updateTs','updateUserId','userName']
        ora_df = ora_df.replace(np.nan,-99999)
        df1 = ora_df.groupby(hdr_list, as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
        df1=df1.replace(-99999,np.nan)
        df1['attributes']= df1['attributes'].apply(lambda row: replace_value(row))
        hdr_list = ['divisionId','equipmentId','assetUuid','assetDesc','assetId','barcode','itemId','itemDesc','categoryId','categoryName','comments','conditionCode','rfId','propertyId','assignmentUuid','propertyNumber','propertySub','propertyName','propertyType','divisionName','serialNumber','stockNumber','startDate','endDate','trend','stateCd','stateName','countyName','fieldName','latitude','longitude','playId','playName','rigId','rigName','subDivisionId','subDivisionName','teamId','teamName','blueWellFl','ecEntityColor','formationNm','operatedFl','operatorName','originationType','phaseName','subphaseName','routeName','foremanName','updateTs','updateUserId','userName','maxApicodNbr','apicodNbr','assocWellId','assocFacilityId','assocUnitFacilityId','wellName','equipSubTypeName','productName','linkId','systemId','systemName','towEquipSk','procountMerrickid','latlong','opStatusCd','groupName','groupId','groupGuid','groupAssetUuid','parentObjectId','groupType','workflowStatus','workflowStatusTs','versionGuid','opStatusReasonCd','parentAssetId','attributes']
                    #df2 = df1.groupby(['key','latlong','assetId','timestamp'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
        if df1['latlong'].isnull().values.any():
           df2 = df1.groupby(['key','assetId','timestamp'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
        else:
           df2 = df1.groupby(['key','latlong','assetId','timestamp'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
        equip_json=df2.to_json(orient='records')
        final_json=json.loads(equip_json)
        lrc_cursor.close()
        cur.close()
        print(len(final_json))
        return final_json,ora_rows,es_field_names
    else:
        return final_json,ora_rows,es_field_names
    
def load_asset(params):
    division_id = params[0]
    eog_user_id = params[1]
    ora_con = db.connect('ifac_dba/Test_345@r1date.eogresources.com')
    #Check for the index and create an index
    index_name = 'ifac_equipment_changes'+str(division_id)+datetime.now().strftime ("%Y%m%d")
    print(index_name)
    type_name = 'ifac_equipment_changes'+str(division_id)
    print(type_name)
    #create_index(index_name,type_name)
    if es.indices.exists(index_name):
        print(index_name+ ' exists')
    else:
        create_index(index_name,type_name)
    cat_data = category_info(ora_con,eog_user_id,division_id)
    for cat_id in cat_data:
        print(cat_id)
        equip_data,ora_rows,es_field_names=div_equip_data(division_id,cat_id,ora_con,eog_user_id)
        if len(equip_data) >= 5000:
                
                # do a bulk push 
                print('Inside of parallel bulk:'+str(cat_id) )
                print('Before Parallel Push'+str(datetime.now()))
                for success, info in helpers.parallel_bulk(es,parallel_generator(ora_rows, index_name, type_name,es_field_names),thread_count=4,chunk_size=2500):
                    #print(success)
                    #print(info)
                    if not success:
                        print('Documents Failed:',info)
                    #else:
                        #print(success)
                        #print(info)
                print('After Parallel Push'+str(datetime.now()))
                es.indices.flush(index= index_name,wait_if_ongoing=True)
                print( 'After Parallel Flush: '+str(datetime.now()))
        else:
                if len(equip_data) > 0:
                    print('Inside of helpers bulk:'+str(cat_id) )
                    asset_data=[]
                    sleepcount=0
                    print('before creating documents: '+str(datetime.now()))
                    for doc in equip_data:
                        action  = {"_index":index_name,"_type":type_name,"_id":doc['assetId'],"_on_type": "update", "_source": doc}
                        asset_data.append(action)
                    print('After creating documents: '+str(datetime.now()))
                    helpers.bulk(es,asset_data)
                    print('After helpers bulk: '+str(datetime.now()))
                    es.indices.flush(index= index_name, wait_if_ongoing=True)
                    print('After helpers flush: '+str(datetime.now()))
                    sleepcount+=1
                if len(equip_data) > 0 and sleepcount > 20:
                    sleepcount = 0
                    time.sleep(100)
    es.indices.put_settings(index=index_name, body={ "index": {"refresh_interval": "1s","number_of_replicas":2}})
    es.indices.put_alias(index = index_name, name = type_name, ignore = 400)
    indices = list(es.indices.get_alias(type_name, ignore=[400,404]))
    for idx in indices:
        day = datetime.now()
        if index_name != idx:
            print("The index that need to be deleted are:",idx)
            es.indices.delete(idx, ignore = 404)
            print("Deleted the index ", idx)

    es.indices.put_alias(index=index_name, name='ifac_equipment', ignore=400)   
    ora_con.close()    

try:
    eog_user_id = 4506215
    #Connect to Oracle
    ora_con = db.connect('ifac_dba/Test_345@r1date.eogresources.com')

    #Connect to Elastic search
    es = Elasticsearch(hosts='ssearch:9200', timeout=120)

    #Get all the div data

    div_data = div_group(ora_con,eog_user_id)

    #create multiple threads for each division
    div_parallel_threads(div_data,eog_user_id)
    #params=[14,4506215]
    #load_asset(params)
   

except Exception as e:
    print(e)
finally:
    print(time.time())
    ora_con.close()
