Select mc.contact_id
   ,        mc.first_name
   ,        mc.last_name
   ,        mc.nick_name
   ,        mc.phone_nbr_mobile
   ,        mc.phone_nbr_work
   ,        mc.phone_nbr_home
   ,        mc.phone_nbr_other
   ,        mc.fax_nbr_work
   ,        mc.fax_nbr_home
   ,        mc.pager_nbr
   ,        mc.email_address_work
   ,        mc.email_address_home
   ,        mc.email_address_other
   ,        mc.network_id
   ,        mc.worker_id
   ,        mc.eog_user_id
   ,        mc.job_title
   ,        mc.mgr_contact_id
   ,        mc.office_location
   ,        NVL((SELECT division_id FROM mrte_dba.mrte_user mu WHERE mu.user_id = mc.eog_user_id), mc.division_id) division_id
   ,        mc.vendor_fl
   ,        mc.vendor_name
   ,        mc.profile_image_url
   ,        mc.profile_image_ts
   ,        mc.comments
   ,        mc.on_call_fl
   ,        mc.off_work_fl
   ,        mcx.role_id
   ,        mr.role_name
   ,        mr.role_descr
   ,        mr.role_hierarchy
   ,        mr.allow_on_call_fl   
   ,        mcr.route_id
   ,        mcr.user_status 
   ,        mc.create_ts
   ,        mc.create_user
   ,        mc.update_ts
   ,        mc.update_user 
from mrte_dba.mrte_contact mc,
mrte_dba.mrte_contact_role_xref mcx,
mrte_dba.mrte_role mr,
mrte_dba.mrte_contact_route_xref mcr   
WHERE  mc.active_fl = 'Y'
AND mc.contact_id = mcx.contact_id(+)
AND mr.role_id = mcx.role_id
AND mr.active_fl = 'Y'
AND mc.contact_id = mcr.contact_id(+)
