#!/usr/local/bin/python3

import json
import multiprocessing as mp
import os
import sys
import time
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from elasticsearch import Elasticsearch, helpers
import socket, smtplib
import cx_Oracle as db
from email.mime.text import MIMEText
import logging
import configparser
from itertools import groupby
from operator import itemgetter
#from pympler import asizeof


def  send_mail(recipients,subject, msg):
    host = socket.gethostname()
    sender = host + "@eogresources.com"
    smtp_host = "smtp.eogresources.com"
    recipients = recipientslist.split(",")
    email_msg = msg
    email_msg['Subject'] = subject
    email_msg['From'] = sender
    email_msg['To'] = recipients
    smtpObj = smtplib.SMTP(smtp_host)
    smtpObj.sendmail(sender, recipients, email_msg.as_string())

def task_grouping(ora_con,eog_user_id):
    cur=ora_con.cursor()
    lrc_cursor=ora_con.cursor()
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_idb_ma_se_task_grouping' ,[eog_user_id,lrc_cursor])
    ora_rows=[]
    ora_rows = lrc_cursor.fetchall()
    lrc_cursor.close()
    cur.close()
    #print(ora_rows)
    ora_rows = [x[0] for x in ora_rows]
    return ora_rows

def grp_parallel_threads(grp_data,eog_user_id,load_fl):
    if __name__ == '__main__':
        pt=mp.Pool(2)
        #print(grp_data)
        params = [(grouping_id, eog_user_id, load_fl) for grouping_id in grp_data]
        #print(params)
        df_results = pt.map(load_tasks,params)
        #print(df_results)
        pt.close()
        pt.join()
    return df_results



def task_type(ora_con,eog_user_id,grouping_id):
    cur=ora_con.cursor()
    lrc_cursor=ora_con.cursor()
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_idb_ma_se_task_type',[eog_user_id,grouping_id,lrc_cursor])
    ora_rows=[]
    ora_rows = lrc_cursor.fetchall()
    lrc_cursor.close()
    cur.close()
    #print(ora_rows)

    ora_rows = [[x[0],x[1]] for x in ora_rows]
    #print(ora_rows)
    return ora_rows

def create_index(index_name,type_name,grouping_id):
    mappings= {

        "dynamic_templates": [{
                "integers": {
                "match_mapping_type": "integer",
                "mapping": {
                  "type": "float"
                }
              }
            },
                              {

                "string_fields": {
                  "mapping": {
                    "index": "analyzed",
                    "omit_norms": True,
                    "type": "string",
                    "fields": {
                      "raw": {
                        "ignore_above": 128,
                        "ignore_malformed":"false",
                        "index": "not_analyzed",
                        "type": "string"
                      }
                    }
                  },
                  "match": "*",
                  "match_mapping_type": "string"
                }
              }]
        }

    grouping_list = [1,5,6,7,11,13,15]

    if grouping_id in grouping_list:
             shards = 2 
             replicas = 2 
    else:
             shards = 1
             replicas =2 
    es.indices.create(index=index_name, ignore=400, body={"number_of_shards":shards,"number_of_replicas":replicas})
    es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
    es.indices.put_settings(index=index_name, body={"index": {"refresh_interval": "-1"}})

def tasks_data(task_type_id,source_app,ora_con,eog_user_id,load_fl):
    cur = ora_con.cursor()
    lrc_cursor = ora_con.cursor()
    lrc_cursor.arraysize = 50000
    final_list = []
    ora_count = 0
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_ma_se_task_es', [0, task_type_id, eog_user_id, source_app, load_fl,interval, lrc_cursor])
    ora_rows = []
    print("Fetching " + str(datetime.now())+ ", for load flg : " + load_fl+" for task type:"+str(task_type_id))
    i = 1
    ora_rows == []
    while True:
        result = lrc_cursor.fetchmany(50000)
        print(str(i * 50000) + " " + str(datetime.now()))
        i = i + 1
        ora_rows = ora_rows + result
        if result == []:
            break
    #ora_rows = lrc_cursor.fetchall()
    i = 1
    print("Done fetching " + str(datetime.now()))
    #print("task_type_id= "+str(task_type_id))
    #print(ora_rows)
    ora_count = lrc_cursor.rowcount
    print('Task total rows:   '+ str(ora_count)+', for load flg : '+load_fl)
    columns = [i[0] for i in lrc_cursor.description]
    #print(columns)
    attr_columns=['taskAttributeUuid'	,
                    'formAttributeUuid'	,
                    'attributeId'	,
                    'attributeName'	,
                    'attributeDesc'	,
                    'requiredCd'	,
                    'isActive'	,
                    'attributeGrouping'	,
                    'value'	,
                    'valueListId'	,
                    'valueListEntryDesc'	,
                    'attributeWorkerId'	,
                    'attributeUpdateTs'	,
                    'uiControlCode'	,
                    'attributeWorkerName'	,
                    'sortOrder'	,
                    'maxAttUpdateTs'
                    ]
    es_field_names=['timeStamp'	,
                                'key'	,
                                'taskUuid'	,
                                'taskId'	,
                                'sourceApp'	,
                                'taskName'	,
                                'formUuid'	,
                                'assetId'	,
                                'assetDesc'	,
                                'assetDescShort'	,
                                'assetUuid'	,
                                'barCode'	,
                                'catalogItemId'	,
                                'catalogItemName'	,
                                'categoryId'	,
                                'categoryName'	,
                                'comments'	,
                                'divisionId'	,
                                'formId'	,
                                'formName'	,
                                'formLevelCode'	,
                                'formComments'	,
                                'groupId'	,
                                'groupName'	,
                                'groupMemberId'	,
                                'groupMemberName'	,
                                'propertyId'	,
                                'propertyNb'	,
                                'propertyName'	,
                                'routeId'	,
                                'temporalKey'	,
                                'routeName'	,
                                'serialNumber'	,
                                'startDate'	,
                                'statusCode'	,
                                'statusGroup'	,
                                'status'	,
                                'stockNb'	,
                                'updateTs'	,
                                'updateWorkerId'	,
                                'updateWorkerName'	,
                                'isUsed'	,
                                'groupingId'	,
                                'groupingName'	,
                                'groupingRgbHex'	,
                                'scheduledFrequencyUnit'	,
                                'scheduledFrequencyPeriod'	,
                                'taskDescription'	,
                                'facilityName'	,
                                'divisionName'	,
                                'foremanName'	,
                                'teamName'	,
                                'countyName'	,
                                'stateName'	,
                                'latlong'	,
                                'deletedFlag'	,
                                'taskUpdateTs',
                                'fileCount']

    sorted_tasks = sorted(ora_rows, key=itemgetter(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,
                                                               36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,72,74))

    for key, grouper in groupby(sorted_tasks,key=itemgetter(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,
                                                               36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,72,74)):

        attr_list = []

        for attr in grouper:
            attr_dict={}
            attr_dict = dict.fromkeys(attr_columns)
            attr_dict['taskAttributeUuid'] = attr[56]
            attr_dict['formAttributeUuid'] = attr[57]
            attr_dict['attributeId'] = attr[58]
            attr_dict['attributeName'] = attr[59]
            attr_dict['attributeDesc'] = attr[60]
            attr_dict['requiredCd'] = attr[61]
            attr_dict['isActive'] = attr[62]
            attr_dict['attributeGrouping'] = attr[63]
            attr_dict['value'] = str(attr[64])
            attr_dict['valueListId'] = attr[65]
            attr_dict['valueListEntryDesc'] = attr[66]
            attr_dict['attributeWorkerId'] = attr[67]
            attr_dict['attributeUpdateTs'] = attr[68]
            attr_dict['uiControlCode'] = attr[69]
            attr_dict['attributeWorkerName'] = attr[70]
            attr_dict['sortOrder'] = attr[71]
            attr_dict['maxAttUpdateTs'] = attr[73]
            attr_list.append(attr_dict)

        key_list = dict(zip(es_field_names, list(key)))
        key_list['attributes']=attr_list
        final_list.append(key_list)
    return final_list

def parallel_generator(ora_rows,index_name,type_name,es_field_names):
    for row in ora_rows:
        yield {
                '_index': index_name,
                '_type': type_name,
                '_id': row['key'],
                '_source': row
            }

def load_tasks(params):
    try:
        grouping_id = params[0]
        eog_user_id = params[1]
        load_fl = params[2]
        es_field_names=['timeStamp'	,
                                'key'	,
                                'taskUuid'	,
                                'taskId'	,
                                'sourceApp'	,
                                'taskName'	,
                                'formUuid'	,
                                'assetId'	,
                                'assetDesc'	,
                                'assetDescShort'	,
                                'assetUuid'	,
                                'barCode'	,
                                'catalogItemId'	,
                                'catalogItemName'	,
                                'categoryId'	,
                                'categoryName'	,
                                'comments'	,
                                'divisionId'	,
                                'formId'	,
                                'formName'	,
                                'formLevelCode'	,
                                'formComments'	,
                                'groupId'	,
                                'groupName'	,
                                'groupMemberId'	,
                                'groupMemberName'	,
                                'propertyId'	,
                                'propertyNb'	,
                                'propertyName'	,
                                'routeId'	,
                                'temporalKey'	,
                                'routeName'	,
                                'serialNumber'	,
                                'startDate'	,
                                'statusCode'	,
                                'statusGroup'	,
                                'status'	,
                                'stockNb'	,
                                'updateTs'	,
                                'updateWorkerId'	,
                                'updateWorkerName'	,
                                'isUsed'	,
                                'groupingId'	,
                                'groupingName'	,
                                'groupingRgbHex'	,
                                'scheduledFrequencyUnit'	,
                                'scheduledFrequencyPeriod'	,
                                'taskDescription'	,
                                'facilityName'	,
                                'divisionName'	,
                                'foremanName'	,
                                'teamName'	,
                                'countyName'	,
                                'stateName'	,
                                'latlong'	,
                                'deletedFlag'	,
                                'taskUpdateTs'	,
                                'fileCount',
                                'attributes'
                                ]

        ora_con = db.connect('ifac_dba/Test_345@r1date.eogresources.com')

        # Check for the index and create an index
        if load_fl == 'Y':
            #Index for Full Load
            index_name = 'ma_se_task_' + str(grouping_id) + datetime.now().strftime("%Y%m%d")
        elif load_fl == 'N':
            #Index Name for Incremental
            index_pattern_name = 'ma_se_task_'
            print('Index search pattern'+index_pattern_name)
            for index in es.indices.get(index_pattern_name + str(grouping_id) + datetime.now().strftime("%Y") + '*'):
                print("Index Name for incremental load"+index)
                index_name = index
        elif load_fl == 'YA':
            #Index Name for Delete Full Load
            #index_name = 'ma_se_task_delete_' + datetime.now().strftime("%Y%m%d")
            index_name = 'ma_se_task_delete_20190724'
        elif load_fl == 'NA':
            #Index Name for Incremental Load for Deleted Tasks
            index_pattern_name = 'ma_se_task_delete_'
            for index in es.indices.get(index_pattern_name + datetime.now().strftime("%Y") + '*'):
                print(index)
                index_name = index

        #type_name
        type_name = '_doc'
		
        #alias_name
        alias_name = "ma_se_tasks"

        print(index_name)
        print(type_name)

        #Create Index for only full load
        if es.indices.exists(index=index_name):
            print(index_name + ' exists')
        else:
            print('creating index ' + index_name)
            create_index(index_name, type_name,grouping_id)

        # For incremental Load if any tasks have been Deleted, then keys from the ES which are no longer exists.
        if load_fl == 'N':
            cur = ora_con.cursor()
            lrc_cursor = ora_con.cursor()
            lrc_cursor.arraysize = 50000
            print('Calling SP..')
            cur.callproc('ifac_dba.ifac_elastic_pkg.sp_ma_se_task_es', [0, 0, eog_user_id, 'NULL', 'D', interval, lrc_cursor])
            ora_rows = []
            ora_rows = lrc_cursor.fetchall()
            print('Delete keys process starts')
            delete_se_ma_task(es, index_name, type_name, ora_rows)
            print('Delete keys process Ends...')

        # Get the task type data
        task_type_data = task_type(ora_con, eog_user_id, grouping_id)
        for row in task_type_data:
            print('------------------------------------------------------------------------------')
            task_data = tasks_data(row[1],row[0],ora_con,eog_user_id,load_fl)
            print("Done with final task data : "+ str(len(task_data))+', for index is : '+index_name)
            if len(task_data) >= 500:
                # do a bulk push
                print('Inside of parallel bulk:' + str(row))
                print('Before Parallel Push' + str(datetime.now()))

                for i in task_data:
                    for key,value in i.items():
                       if value == -9999 or value == '-9999':
                           i[key] = None 
                       if key == 'attributes':
                          for j,val  in enumerate(i[key]):
                              for k in val.keys():
                                 if val[k] == -9999 or val[k] == '-9999':
                                      val[k] = None 
                        
                for success, info in helpers.parallel_bulk(es, parallel_generator(task_data, index_name, type_name,
                                                                                  es_field_names), thread_count=4,
                                                           chunk_size=500):
                    # print(success)
                    # print(info)
                    if not success:
                        print('Documents Failed:', info)
                    # else:
                    # print(success)
                    # print(info)
                print('After Parallel Push' + str(datetime.now()))
                es.indices.flush(index=index_name, wait_if_ongoing=True)
                print('After Parallel Flush: ' + str(datetime.now()))
            else:
                if len(task_data) > 0:
                    print('Inside of helpers bulk:' + str(row))
                    task_data_final = []
                    sleepcount = 0
                    print('before creating documents: ' + str(datetime.now()))
                    #print(type(task_data))
                    for doc in task_data:
                        for key,value in doc.items():
                           #print(key)
                           if value == -9999 or value == '-9999':
                              doc[key]  = None 
                           if key == 'attributes':
                               for j,val  in enumerate(doc[key]):
                                   for k in val.keys():
                                       if val[k] == -9999 or val[k] == '-9999':
                                             val[k] = None 
                        #print("updating UUID "+ doc['key'])
                        action = {"_index": index_name, "_type": type_name, "_id": doc['key'],"_on_type": "update", "_source": doc}
                        task_data_final.append(action)
                    print('After creating documents: ' + str(datetime.now()))
                    success, info = helpers.bulk(es, task_data_final)
                    if success:
                       print("updated")
                    print('After helpers bulk: ' + str(datetime.now()))

                    if load_fl == 'Y' or load_fl == 'YA':
                        es.indices.flush(index=index_name, wait_if_ongoing=True)
                        print('After helpers flush: ' + str(datetime.now()))

                    if load_fl == 'N' or load_fl == 'NA':
                        es.indices.refresh(index=index_name)
                        es.cluster.health(wait_for_no_relocating_shards=True, wait_for_active_shards='all')

                    sleepcount += 1
                if len(task_data) > 0 and sleepcount > 20:
                    sleepcount = 0
                    time.sleep(100)
            #print(' ')

        if load_fl == 'Y' or load_fl == 'YA':
            es.indices.put_settings(index=index_name, body={"index": {"refresh_interval": "1s", "number_of_replicas":1}})
            es.indices.put_alias(index=index_name, name=alias_name, ignore=400)

        #Setting up the search string for the index
        if load_fl == 'Y':
           index_search_name = "ma_se_task_"+str(grouping_id)+'20'
        elif load_fl == 'YA':
           index_search_name = "ma_se_task_delete"

        if load_fl == 'Y' or load_fl == 'YA':
                 print("index_search_name"+index_search_name)
                 indices = list(es.indices.get_alias(alias_name, ignore=[400, 404]))
                 print(indices)
                 for idx in indices:
                       if idx.startswith(index_search_name):
                              print("Existing index is"+idx)
                              print("today's index is"+index_name)
                              day = datetime.now()
                              if index_name != idx:
                                  print("The index that need to be deleted are:", idx)
                                  es.indices.delete(idx, ignore=404)
                                  print("Deleted the index ", idx)

                 es.indices.put_alias(index=index_name, name=alias_name, ignore=400)
        ora_con.close()
    except Exception as e:
        print(e)
        #print('Error')

# Delete Assets which are deleted from log table
def delete_se_ma_task(es, index_name, type_name, ora_del_data):
    try:
        for i in ora_del_data:
            #Asset = list(i)
            #id = Asset[0]
            print("id to be deleted"+str(i))
            try:
                res = es.delete(index=index_name, doc_type=type_name, id= i)
            except Exception as e:
                pass
    except Exception as e:
        print('Error in Delete task changes, ',e)

try:
    print("BEGIN")
    eog_user_id = 4506215

    recipientslist = 'vasudha_putta@eogresources.com'
	
    #load flag to determine whether full or complete load Y - Complete Load  N - Incremental load
    load_fl = sys.argv[1]
    esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'

    #interval specified during the incremental loads - 1 runs every 15 min and 1 runs every 24 hours
    interval = float(sys.argv[2])
    print("running for last "+ str(interval) + " days")

    #esconfigfilename = 'C:/Work/Python/ini/config/ece_es_credentials.ini'
    config = configparser.ConfigParser()
    config.read(esconfigfilename)

    es_search_conf = config['FIELDOPSESSTAGE']
    print(es_search_conf)
    host_name = es_search_conf['HostName']
    print(host_name)
    time_out = int( es_search_conf['Timeout'])
    print(time_out)
    user = es_search_conf['User']
    print(user)
    password = es_search_conf['Password']
    print(password)
    certs =  es_search_conf['VerifyCerts']
    print(certs)
    header = es_search_conf['Header']
    print(header)
    h = { "Content-type":"application/json" }

    h = {"host":"e56bf542763d49e08a4941c7342497ce.esstg.eogresources.com"}
    hosts = ["http://houecestg61.eogresources.com:9200","http://houecestg62.eogresources.com:9200","http://houecestg63.eogresources.com:9200",]

    # Connect to Oracle
    ora_con = db.connect('ifac_dba/Test_345@r1date.eogresources.com')

    # Connect to Elastic search
    es = Elasticsearch(
        hosts=hosts,  # esdatanodes
        timeout=180,  # increase timeout from default 10s to 120s
        http_auth=(user,password),
        verify_certs=certs,
        max_retries=2,
        retry_on_timeout=True,
        headers=h
    )

    # Get all the Task Groupings
    params = []
    grp_data = task_grouping(ora_con, eog_user_id)

    # create multiple threads for each task grouping
    #grp_parallel_threads(grp_data, eog_user_id, load_fl)
	
    ###The below steps are needed to manually run for each group.
    #print('group data : ',grp_data)
    params=[17,4506215,load_fl]
    if params:
        print('params : ', params)
        load_tasks(params)
        print("Task data completed..")
	####

    # create multiple threads for each task grouping
    # below code for to process audit information for Incremental and historical data load
	# YA and NA are flags for loading deleted tasks full and incremental
    if load_fl == 'Y':
        load_fl = 'YA'
    elif load_fl == 'N':
        load_fl = 'NA'
  
    #print(load_fl)
    #grp_parallel_threads(grp_data, eog_user_id, load_fl)
    #print(grp_data)
	
	###The below steps are needed to manually run for each group.
    params=[17,4506215,load_fl]
    if params:
        print('params : ', params)
        load_tasks(params)
        print("Process Completed..")
	###

except Exception as e:
    print(e)
    # send_mail(recipientslist,"Tasks Pivot Index", MIMEText(str(e)+' Tasks Pivot index failed'))
finally:
    pass
    #ora_con.close()
    # send_mail(recipientslist,"Tasks Pivot Index", MIMEText('Tasks Pivot index completed'))
