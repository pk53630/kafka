import csv
import os
import pandas as pd
import numpy as np
import re
import cx_Oracle as db
import datetime
import email_process

sender = 'radhika_tati@eogresources.com'
recipients = 'radhika_tati@eogresources.com'
subject = 'Frac Schedule Load Process'

def load_sched (filename):
    try: 
            
            x = pd.ExcelFile(filename)
            dfall = x.parse('Scheduler')
            ora_con = db.Connection('odm_dba/R1dba_101@r1datd.eogresources.com')
            insert_cursor = ora_con.cursor()
            frac_seq_cur = ora_con.cursor()
            frac_sql_query = """select well_Frac_sched_ver_id_seq.nextval from dual"""
            frac_seq_cur.execute(frac_sql_query)
            frac_sched_ver_id_list =  frac_seq_cur.fetchall()
            for row in frac_sched_ver_id_list:
                frac_sched_ver_id = row[0]
            print(frac_sched_ver_id)
            frac_seq_cur.close()

            print(datetime.datetime.today().strftime('%Y-%m-%d'))
            today_dt = datetime.datetime.today().strftime('%Y-%m-%d')

            #Build insert sql
            insert_query = ''
            insert_query = """INSERT INTO odm_dba.ODM_WELL_FRAC_SCHEDULE_STAGE (PRIMO_PRPRTY,STAGES,ENGINEER,AREA,	TREATED_LENGTH,	 TOTAL_PLANNED_STAGES,well_name,DATE_VALUE,DIVISION_ID,FRAC_COMPANY_NAME ,FRAC_SCHEDULE_VERSION_ID,EOG_USER_ID,derived_well_name,file_name,frac_sched_load_dt)
                            VALUES(:1,:2,:3,:4,:5,:6,:7,to_date(:8,\'YYYY-MM-DD HH24:MI:SS\'),:9,:10,:11,:12,:13,'Eagleford Frac Schedule 2018',to_date(:14,\'YYYY-MM-DD HH24:MI:SS\'))"""

            dfallcrew=dfall.dropna(axis=0,how='all') 
            dfallcrew=dfallcrew.reset_index(drop=True)

            frac_crew_list= dfallcrew.iloc[0].values.tolist()

            frac_final_list =[value for value in frac_crew_list if str(value)!='nan']

            dfallcrew1=dfallcrew.iloc[1:]
            dfallcrew1=dfallcrew1.reset_index(drop=True)

            dfallcrew1 = dfallcrew1.dropna(subset=['Unnamed: 0'], how = 'all')

            df_date=dfallcrew1.iloc[:,0:2]
            
            df_no_date=dfallcrew1.iloc[:,2:]
            
            df_no_date = df_no_date.T.reset_index(drop=True).T

            d={}
            for i in frac_final_list:
                print(i)
                
                d[i] = pd.DataFrame(df_no_date.iloc[:,0:7])
                d[i] = pd.concat([d[i],df_date.iloc[:,0]], axis=1)

                d[i].columns = d[i].iloc[0]
            

                d[i]=d[i].reindex(d[i].index.drop(0))

                #print(d[i].head())

                df_no_date = pd.DataFrame(df_no_date.iloc[:,7:])
                df_no_date = df_no_date.T.reset_index(drop=True).T
                d[i]['well cnt'] = np.nan
                for index,row in d[i].iterrows(): 
                    d[i].at[index, ['Well Name']]=re.sub(r'\(.*?\)', '',str(row[0]))
                #print(d[i].head())
                for index,row in d[i].iterrows():
                    d[i].at[index, ['well cnt']] = len(re.findall("/", str(row[0])))

                d[i]['well cnt']=d[i]['well cnt'].astype(int)
                d[i]['Stages']=d[i]['Stages'].astype(str)
                #print(d[i].head())
                
                total_cnt = max(d[i]['well cnt'])
                print(total_cnt)

                WellNamelist =[]
                stageslist=[]

                #if total_cnt == 0:
                
                #    for j in range(total_cnt+1):
                #        WellNamelist.append('Well Name'+str(j))
                #        print(WellNamelist)
                #        stageslist.append('Stages'+str(j))
                        
                #    print(type(d[i]['Stages']))

                #    df_welllist = pd.DataFrame(d[i]['Well Name'].str.split('/',total_cnt).tolist(), columns = WellNamelist)
                #    df_stagelist = pd.DataFrame(d[i]['Stages'].str.split('/',total_cnt).tolist(), columns = stageslist) 
                #    print(df_stagelist.head())
                #    df_stagelist.index = df_stagelist.index+1

                #print(df_stagelist.head())
                if total_cnt > 0 :
                    m=1
                    d[i]['Prop #'] = d[i]['Prop #'].fillna('baddata')
                    d[i]['Engr'] = d[i]['Engr'].fillna('baddata')
                    d[i]['Area'] = d[i]['Area'].fillna('baddata')
                    d[i]['TL'] = d[i]['TL'].fillna('baddata')
                    d[i]['#'] = d[i]['#'].fillna('baddata')
                    indexlist=[]
                    for index in range(1,len(d[i]['Prop #'])):
                        if (d[i].loc[index,'Prop #']=='baddata'):
                            indexlist.append(index-1) 
                        else:
                            break
                    #print(indexlist)
                    d[i]=d[i].drop(d[i].index[indexlist])

                    d[i] =  d[i].reset_index(drop=True)    
                    d[i].index = d[i].index+1
                    for index,row in d[i].iterrows():
                        d[i].at[index, ['well cnt']] = len(re.findall("/", str(row[0])))
                    d[i]['well cnt']=d[i]['well cnt'].astype(int)
                    total_cnt = max(d[i]['well cnt'])
                    print(total_cnt)
                    for j in range(total_cnt+1):
                        WellNamelist.append('Well Name'+str(j))
                        print(WellNamelist)
                        stageslist.append('Stages'+str(j))
                    
                    #print(type(d[i]['Stages']))

                    df_welllist = pd.DataFrame(d[i]['Well Name'].str.split('/',total_cnt).tolist(), columns = WellNamelist)
                    df_stagelist = pd.DataFrame(d[i]['Stages'].str.split('/',total_cnt).tolist(), columns = stageslist) 
                    #print(df_stagelist.head())
                    df_stagelist.index = df_stagelist.index+1
                    df_welllist.index = df_welllist.index+1

                    #print(df_stagelist.head())
                    #print(d[i].head())
                    for index in range(1,len(d[i]['Prop #'])):
                    #for index in range(1,len(d[i])):
                        ####Property Number####
                            if (d[i].loc[index,'well cnt'] == 0):
                                    prop ='Prop #'+str(m-1)
                                    Engr = 'Engr'+str(m-1)
                                    Area = 'Area'+str(m-1)
                                    TL = 'TL'+str(m-1)
                                    totstages = '#'+str(m-1)
                                    d[i].loc[index,prop]=d[i].loc[index,'Prop #']
                                    d[i].loc[index,Engr]=d[i].loc[index,'Engr']
                                    d[i].loc[index,Area]=d[i].loc[index,'Area']
                                    d[i].loc[index,TL]=d[i].loc[index,'TL']
                                    d[i].loc[index,totstages]=d[i].loc[index,'#']
                            
                            elif (d[i].loc[index,'Prop #']!='baddata' and d[i].loc[index+1,'Prop #']!='baddata' and d[i].loc[index,'well cnt']!= 0):
                                if  m==1:
                                    #print(m)
                                    prop ='Prop #'+str(m-1)
                                    Engr = 'Engr'+str(m-1)
                                    Area = 'Area'+str(m-1)
                                    TL = 'TL'+str(m-1)
                                    totstages = '#'+str(m-1)
                                    date = 'Date'+str(m-1)
                                    d[i].loc[index,prop]=d[i].loc[index,'Prop #']
                                    d[i].loc[index,Engr]=d[i].loc[index,'Engr']
                                    d[i].loc[index,Area]=d[i].loc[index,'Area']
                                    d[i].loc[index,TL]=d[i].loc[index,'TL']
                                    d[i].loc[index,totstages]=d[i].loc[index,'#']
                                    d[i].loc[index,date]=d[i].loc[index,'Date']
                                    m=m+1
                                else:
                                    
                                    #print(str(m)+' m counter')
                                    prop ='Prop #'+str(m-1)
                                    Engr = 'Engr'+str(m-1)
                                    Area = 'Area'+str(m-1)
                                    TL = 'TL'+str(m-1)
                                    totstages = '#'+str(m-1)
                                    date = 'Date'+str(m-1)
                                    d[i].loc[index-(m-1),prop]=d[i].loc[index,'Prop #']
                                    d[i].loc[index-(m-1),Engr]=d[i].loc[index,'Engr']
                                    d[i].loc[index-(m-1),Area]=d[i].loc[index,'Area']
                                    d[i].loc[index-(m-1),TL]=d[i].loc[index,'TL']
                                    d[i].loc[index-(m-1),totstages]=d[i].loc[index,'#']
                                    d[i].loc[index-(m-1),date]=d[i].loc[index,'Date']
                                    m=m+1
                            elif (d[i].loc[index,'Prop #']!='baddata' and d[i].loc[index-1,'Prop #']!='baddata'and d[i].loc[index,'well cnt'] != 0):
                                    #print(str(m)+' m counter')
                                    prop ='Prop #'+str(m-1)
                                    Engr = 'Engr'+str(m-1)
                                    Area = 'Area'+str(m-1)
                                    TL = 'TL'+str(m-1)
                                    totstages = '#'+str(m-1)
                                    date = 'Date'+str(m-1)
                                    d[i].loc[index-(m-1),prop]=d[i].loc[index,'Prop #']
                                    d[i].loc[index-(m-1),Engr]=d[i].loc[index,'Engr']
                                    d[i].loc[index-(m-1),Area]=d[i].loc[index,'Area']
                                    d[i].loc[index-(m-1),TL]=d[i].loc[index,'TL']
                                    d[i].loc[index-(m-1),totstages]=d[i].loc[index,'#']
                                    d[i].loc[index-(m-1),date]=d[i].loc[index,'Date']

                                    m=1
                            
                            else:
                                m=1
                else:
                    d[i]['Prop #'] = d[i]['Prop #'].fillna('baddata')
                    d[i]['Engr'] = d[i]['Engr'].fillna('baddata')
                    d[i]['Area'] = d[i]['Area'].fillna('baddata')
                    d[i]['TL'] = d[i]['TL'].fillna('baddata')
                    d[i]['#'] = d[i]['#'].fillna('baddata')
                    indexlist = []
                    for index in range(1,len(d[i]['Prop #'])):
                            if (d[i].loc[index,'Prop #']=='baddata'):
                                indexlist.append(index-1) 
                            else:
                                break
                    #print(indexlist)
                    if (len(indexlist)) !=0:
                        d[i]=d[i].drop(d[i].index[indexlist])
                        d[i] =  d[i].reset_index(drop=True)    
                        d[i].index = d[i].index+1
                    if total_cnt == 0:
                            
                        for j in range(total_cnt+1):
                            WellNamelist.append('Well Name'+str(j))
                            #print(WellNamelist)
                            stageslist.append('Stages'+str(j))
                            
                        #print(type(d[i]['Stages']))

                        df_welllist = pd.DataFrame(d[i]['Well Name'].str.split('/',total_cnt).tolist(), columns = WellNamelist)
                        df_stagelist = pd.DataFrame(d[i]['Stages'].str.split('/',total_cnt).tolist(), columns = stageslist) 
                        #print(df_stagelist.head())
                        df_stagelist.index = df_stagelist.index+1
                        df_welllist.index = df_welllist.index+1
                    
                    prop ='Prop #'+str(total_cnt)
                    Engr = 'Engr'+str(total_cnt)
                    Area = 'Area'+str(total_cnt)
                    TL = 'TL'+str(total_cnt)
                    totstages = '#'+str(total_cnt)
                    date = 'Date'+str(total_cnt)
                    
                    
                    d[i][prop]=d[i]['Prop #'].apply(lambda row:row)
                    d[i][Engr]=d[i]['Engr'].apply(lambda row:row)
                    d[i][Area]=d[i]['Area'].apply(lambda row:row)
                    d[i][TL]=d[i]['TL'].apply(lambda row:row)
                    d[i][totstages]=d[i]['#'].apply(lambda row:row)
                    d[i][date]=d[i]['Date'].apply(lambda row:row)
                    
                    #d[i][prop,Engr,Area,TL,totstages]   =  d[i][['Prop #','Engr','Area','TL','#']]   
                
                d[i]['Prop #']=d[i]['Prop #'].replace('baddata', np.nan, regex=True)
                d[i]['Engr']=d[i]['Engr'].replace('baddata', np.nan, regex=True)
                d[i]['Area']=d[i]['Area'].replace('baddata', np.nan, regex=True)
                d[i]['TL']=d[i]['TL'].replace('baddata', np.nan, regex=True)
                d[i]['#']=d[i]['#'].replace('baddata', np.nan, regex=True)

                    

                d[i] = pd.concat([d[i],df_stagelist], axis=1) 
                d[i] = pd.concat([d[i],df_welllist], axis=1) 
                #print(d[i].head())
                d[i]['division_id'] =63
                d[i]['frac_name']=i
                d[i]['frac_schedule_ver_id']=frac_sched_ver_id
                d[i]['eog_user_id']=4506215
                d[i]['load_dt']=today_dt
                
                #d[i]=d[i].dropna(subset = ['Well Name'])

                d[i] = d[i].fillna('baddata')
                d[i]=d[i].replace('nan', 'baddata', regex=True)
                
                print(d[i].tail())
                for k in range(total_cnt+1):
                    #print(str(k)+'value')
                    d[i]=d[i].replace('nan', 'baddata', regex=True)
                    d[i] = d[i].fillna('baddata')
                    #print(d[i].tail())
                    WellName = 'Well Name'+str(k)
                    stages = 'Stages'+str(k)
                    prop = 'Prop #'+str(k)
                    Engr = 'Engr'+str(k)
                    Area = 'Area'+str(k)
                    TL = 'TL'+str(k)
                    totstages = '#'+str(k)
                    date = 'Date'+str(k)

                    for index in range(1,len(d[i])+1):
                    #for index in range(len(d[i])):
                    
                            #print(print(index))
                            
                            if(d[i].loc[index,prop]=='baddata' and d[i].loc[index,'Well Name'] !='baddata' and index!=1 and d[i].loc[index,'well cnt']==k) or (d[i].loc[index,prop]=='baddata' and index!=1):
                                #print(index)
                                d[i].loc[index,date] = d[i].loc[index,'Date']
                                d[i].loc[index,WellName] = d[i].loc[index,WellName]
                                d[i].loc[index,prop] = d[i].loc[index-1,prop]
                                d[i].loc[index,Engr] = d[i].loc[index-1,Engr]
                                d[i].loc[index,Area] = d[i].loc[index-1,Area]
                                d[i].loc[index,TL] = d[i].loc[index-1,TL]
                                d[i].loc[index,totstages] = d[i].loc[index-1,totstages]
                            elif (d[i].loc[index,prop]=='baddata'and index!=1 and d[i].loc[index,'well cnt']==k):
                                #print(index)
                                d[i].loc[index,date] = d[i].loc[index,'Date']
                                d[i].loc[index,WellName] = d[i].loc[index,WellName]
                                d[i].loc[index,prop] = d[i].loc[index-1,prop]
                                d[i].loc[index,Engr] = d[i].loc[index-1,Engr]
                                d[i].loc[index,Area] = d[i].loc[index-1,Area]
                                d[i].loc[index,TL] = d[i].loc[index-1,TL]
                                d[i].loc[index,totstages] = d[i].loc[index-1,totstages]
                            else:
                                #print(index)
                                d[i].loc[index,date] = d[i].loc[index,'Date']
                                d[i].loc[index,WellName] = d[i].loc[index,WellName]
                    d[i]=d[i].replace('baddata',np.nan, regex=True)
                    
                    #print(d[i][[prop,stages,Engr,Area,TL,totstages,date,WellName]].tail())
                    #print(d[i][[prop,stages,Engr,Area,TL,totstages,date,WellName]].to_csv(prop)) 
                    d[i]['Date']=d[i]['Date'].astype(str)
                    d[i][date]=d[i][date].astype(str)

                    df_final={}
                    df_final = d[i][[prop,stages,Engr,Area,TL,totstages,'Well Name',date,'division_id','frac_name','frac_schedule_ver_id','eog_user_id',WellName,'load_dt']]
                    df_final=df_final.dropna(subset = ['Well Name'])
                    df_final=df_final.dropna(subset = [WellName])
                    df_final=df_final.dropna(subset = [prop])
                    df_final[date]= df_final[date].astype(str)
                    df_final[prop]= df_final[prop].astype(str)
                    df_final[stages]=df_final[stages].replace('nan','NA', regex=True)
                    df_final[stages]=df_final[stages].replace(np.nan,'NA', regex=True)
                    df_final[stages]=df_final[stages].replace(' ','NA', regex=True)
                    df_final[WellName]=df_final[WellName].replace('nan','NA', regex=True)
                    df_final[WellName]=df_final[WellName].replace(np.nan,'NA', regex=True)

                    

                    insert_cursor.prepare(insert_query)
                    df_values = df_final.values.tolist()
                    print(df_values)
                    #print(df_values[0])
                    insert_cursor.executemany(None,df_values)
                    ora_con.commit()
                
            ora_cursor = ora_con.cursor()
            ora_cursor.callproc('odm_dba.odm_load_frac_schedule_pkg.kp_load_frac_schedule',[63,4506215,frac_sched_ver_id])
            ora_cursor.close()
            insert_cursor.close()
            ora_con.close()
            return 'SUCCESS'
    except db.DatabaseError as e:
        print(str(e)+'DB error')   
        
        email_process.send_email(sender,MIMEText(str(e)+'DB error'),recipients,subject)
        ora_cursor.close()
        insert_cursor.close()
        ora_con.close()
        return 'ERROR'      
    except Exception as e:
        print(str(e)+'Python error')
        email_process.send_email(sender,MIMEText(str(e)+'Python error'),recipients,subject)
        ora_cursor.close()
        insert_cursor.close()
        ora_con.close()
        return 'ERROR'       
    #finally:
        #insert_cursor.close()
        #ora_con.close()
