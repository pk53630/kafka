   WITH     all_categories
   AS
   (
   SELECT   category_id
   ,        category_name
   ,        parent_category_id
   ,        (SELECT category_name FROM mrte_dba.mrte_category p WHERE p.category_id = c.category_id) parent_category_name
   FROM     mrte_dba.mrte_category c
   START WITH parent_category_id IS NULL
   CONNECT BY PRIOR category_id = parent_category_id
   )
SELECT tcx.division_id||t.tag_id||ac.category_id "key", t.tag_id, t.tag_name, t.tag_label, t.system_name, t.tag_color, t.active_fl, t.create_user, t.create_ts, t.update_user, t.update_ts, t.tag_uom, t.tag_precision, t.tag_nice_name, t.tag_generic_name, t.set_point, NVL(tcx.division_id,0) division_id, tcx.category_id, t.tag_data_type, (SELECT category_name FROM mrte_dba.mrte_category mc WHERE mc.category_id = tcx.category_id) category_name, NVL(ac.parent_category_id, -1) parent_category_id, parent_category_name
FROM mrte_dba.mrte_tag t, mrte_dba.mrte_tag_category tcx, all_categories ac
WHERE  t.tag_id = tcx.tag_id(+)
   AND      t.active_fl(+) = 'Y'
   AND      tcx.active_fl(+) = 'Y'
   AND     tcx.category_id = ac.category_id(+)
