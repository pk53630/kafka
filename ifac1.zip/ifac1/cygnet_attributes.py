#!/usr/local/bin/python3
import pandas as pd
import cx_Oracle as db
import pymssql as ms
import os, time, smtplib, socket, datetime
import sys
import email_process
import configparser
from email.mime.text import MIMEText

pd.options.display.max_colwidth = 1000

try:
    configfilename = "/home/odmbatch/ifacility/cygnet_attributes.ini"
    config = configparser.ConfigParser()
    print(configfilename)
    config.read(configfilename)
    #ES email
    es_email_conf = config['EMAIL']
    print(es_email_conf)
    sender = es_email_conf['EmailFrom']
    print(sender)
    recipients = es_email_conf['EmailTo']
    print(recipients)
    subject = es_email_conf['Subject']
    print(subject)

    #SQL Server
    sql_server_conf = config['SQLSERVER']
    host = sql_server_conf['Host']
    user = sql_server_conf['User']
    pwd = sql_server_conf['Password']
    dbname = sql_server_conf['Database']
    views = sql_server_conf['Views']
    views = views.replace("u", "")
    views = views.split(',')
    print(views)

    #Oracle
    ora_conf = config['ORACLE']
    conn_string = ora_conf['ConnectionString']
    meta_table = ora_conf['MetadataTable']
    print(meta_table)
    cygnet_table = ora_conf['CygnetTable']
    print(cygnet_table)

    try:#connect to sql server
        ms_dbcon = ms.connect(host=host, user=user, password=pwd, database=dbname, as_dict=True)
        
        try:
            ora_con = db.connect(conn_string)
            
            for row in views:
                ora_meta_query = """SELECT distinct LISTAGG (':'||cygnet_attribute || ' ' || eog_column_name, ',')WITHIN GROUP
                                (ORDER BY cygnet_attribute) select_clause,
                                LISTAGG (cygnet_attribute, ',') WITHIN GROUP (ORDER BY cygnet_attribute) sql_clause,
                                LISTAGG (' TGT.' || eog_column_name || ' = SRC.' || eog_column_name,',') WITHIN GROUP (ORDER BY cygnet_attribute) upd_clause,
                                LISTAGG (' TGT.' || eog_column_name, ' ,')WITHIN GROUP (ORDER BY eog_column_name) tgt_ins,
                                LISTAGG (' SRC.' || eog_column_name, ' ,')WITHIN GROUP (ORDER BY eog_column_name) src_ins,
                                max(division_id) division_id,max(sub_division_id) sub_division_id FROM """+meta_table+""" WHERE cygnet_view = '""" +row+ """' AND eog_column_name IS NOT NULL"""
                print(ora_meta_query)
                meta_cursor = ora_con.cursor()
                meta_cursor.execute(ora_meta_query) 
                meta_result = meta_cursor.fetchall()
                for rec in meta_result:
                    select_clause = rec[0]
                    sql_clause = rec[1]
                    print(sql_clause)
                    upd_clause = rec[2]
                    tgt_ins = rec[3]
                    src_ins = rec[4]
                    division_id = rec[5]
                    sub_division_id = rec[6]
                    print(division_id)
                sql_clause = ''.join(sql_clause)
                select_clause = ''.join(select_clause)
                
                
                #upd_clause_lst.remove("TGT.CYGNET_FACILITY_ID = SRC.CYGNET_FACILITY_ID")
                #upd_clause = tuple(upd_clause_lst)
                
                upd_clause = ''.join(upd_clause)
                upd_clause = upd_clause.replace("TGT.CYGNET_FACILITY_ID = SRC.CYGNET_FACILITY_ID,"," ")
                print(upd_clause)
                tgt_ins = ''.join(tgt_ins)
                src_ins = ''.join(src_ins)
                print(division_id)
                if row == 'EOG_DEN_FAC_ATTRS':
                   where_con = """AND facility_site = 'DJ'"""
                else:
                   where_con = """AND 1=1"""
                   
                mssql_query="""with data as( SELECT """ +sql_clause+ """, count(*) over (partition by facility_id) as cnt FROM CygNet.dbo."""+ row+""" WHERE facility_service = 'UIS'
                                AND facility_category <> 'COMMDEV' AND (PATINDEX('%[0-9]%', facility_attr0) = 1) AND (PATINDEX('%[.]%',facility_attr0) = 0)
                                """+where_con+""")
                                select """+sql_clause+""" from data
                                where cnt = 1"""
                print(mssql_query)
                ms_cursor = ms_dbcon.cursor()
                ms_cursor.execute(mssql_query)
                ms_sql_data =[]
                for r in ms_cursor.fetchall():
                    ms_sql_data.append(r)

                ora_merge_query = """MERGE INTO """+cygnet_table+ """ tgt using ( select """+str(division_id)+""" division_id,"""+select_clause+""","""+str(sub_division_id)+""" sub_division_id from dual) src
                                   on (tgt.division_id = to_number(src.division_id) AND tgt.cygnet_facility_id = src.cygnet_facility_id AND tgt.sub_division_id = to_number(src.sub_division_id))
                                   WHEN NOT MATCHED THEN INSERT  (tgt.division_id,"""+tgt_ins+""",tgt.sub_division_id) VALUES (src.division_id,"""+src_ins+""",src.sub_division_id) WHEN MATCHED THEN 
                                   UPDATE SET """+ upd_clause
                print(ora_merge_query)
                ora_merge_cur = ora_con.cursor()
                ora_merge_cur.executemany(ora_merge_query, ms_sql_data)
                ora_con.commit()
                meta_cursor.close()
                ora_merge_cur.close()
                ms_cursor.close()
            ora_con.close()
        except db.DatabaseError as exc:
               print(exc)
               error, = exc.args
               error_msg = error.message
               print(error_msg)
               email_process.send_email(sender, MIMEText(error_msg), recipients, subject)
        ms_dbcon.close()       
    except ms.DatabaseError as err:
           error_msg = str(err)
           print(error_msg)
           email_process.send_email(sender, MIMEText(error_msg), recipients, subject)
except Exception as e:
       error_msg = str(e)
       print(error_msg)
       email_process.send_email(sender, MIMEText(error_msg), recipients, subject)

finally:
    #email_process.send_email(sender, MIMEText('cygnet attribute load complete'), recipients, subject)
    print('Successful')






