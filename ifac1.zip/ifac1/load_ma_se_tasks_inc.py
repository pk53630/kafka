#!/usr/local/bin/python3

import json
import multiprocessing as mp
import os
import sys
import time
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from elasticsearch import Elasticsearch, helpers
import socket, smtplib
import cx_Oracle as db
from email.mime.text import MIMEText
import logging
import configparser
from itertools import groupby
from operator import itemgetter

def replace_value(row):
    new_row=[]
    for i in row:
        for key,value in i.items():
            if value ==-99999:
                i[key]=np.nan
    return row

def  send_mail(recipients,subject, msg):
    host = socket.gethostname()
    sender = host + "@eogresources.com"
    smtp_host = "smtp.eogresources.com"
    recipients = recipientslist.split(",")
    email_msg = msg
    email_msg['Subject'] = subject
    email_msg['From'] = sender
    email_msg['To'] = recipients
    smtpObj = smtplib.SMTP(smtp_host)
    smtpObj.sendmail(sender, recipients, email_msg.as_string())

def task_grouping(ora_con,eog_user_id):
    cur=ora_con.cursor()
    lrc_cursor=ora_con.cursor()
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_idb_ma_se_task_grouping' ,[eog_user_id,lrc_cursor])
    ora_rows=[]
    ora_rows = lrc_cursor.fetchall()
    lrc_cursor.close()
    cur.close()
    #print(ora_rows)
    #ora_rows = [x[0] for x in ora_rows]
    return ora_rows


try:
    eog_user_id = 4506215
    #recipientslist = 'radhika.tati@eogresources.com,vasudha.putta@eogresources.com'
    recipientslist = 'todd_knuth@eogresources.com'
    #load_fl = sys.argv[1]
    interval = float(sys.argv[1])
    print("running for last "+ str(interval) + " days")
    esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
    config = configparser.ConfigParser()
    config.read(esconfigfilename)

    es_search_conf = config['FIELDOPSESSTAGE']
    print(es_search_conf)
    host_name = es_search_conf['HostName']
    print(host_name)
    time_out = int( es_search_conf['Timeout'])
    print(time_out)
    user = es_search_conf['User']
    print(user)
    password = es_search_conf['Password']
    print(password)
    certs =  es_search_conf['VerifyCerts']
    print(certs)
    header = es_search_conf['Header']
    print(header)
    h = { "Content-type":"application/json" }
    #esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
    #config = configparser.ConfigParser()
    #config.read(esconfigfilename)

    #es_search_conf = config['FIELDOPSESSTAGE']
    #print(es_search_conf)
    #host_name = es_search_conf['HostName']
    #print(host_name)
    #time_out = int(es_search_conf['Timeout'])
    #print(time_out)
    #user = es_search_conf['User']
    #print(user)
    #password = es_search_conf['Password']
    #print(password)
    #certs = es_search_conf['VerifyCerts']
    #print(certs)
    #header = es_search_conf['Header']
    #print(header)
    h = {"Content-type": "application/json"}

    # Connect to Oracle
    ora_con = db.connect('ifac_dba/Test_345@r1date.eogresources.com')


    #ES email
    configfilename = '/home/odmbatch/ifacility/ma_se_tasks.ini'
    config = configparser.ConfigParser()
    config.read(configfilename)

    es_index_conf = config['ESINDEXDETAILS']
    index_name = es_index_conf['IndexName']
    print(index_name)
    #index_name = index_name + str(grouping_id) + datetime.now().strftime("%Y%m%d")
    type_name = es_index_conf['TypeName']
    #type_name = type_name + str(grouping_id)
    #print(type_name)
    alias_name =  es_index_conf['AliasName']
    ignore =  int(es_index_conf['Ignore'])
    nested_index = es_index_conf['NestedIndex']
    index_id = es_index_conf['IndexFieldId']
    bulk_push_size = int(es_index_conf['BulkPushSize'])
    refresh_interval = es_index_conf['RefreshInterval']
    field_mappings = es_index_conf['IndexFieldMappings']
    field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
    field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))

    #print(field_mappings_dict)

    # Connect to Elastic search
    # es = Elasticsearch(hosts='ssearch:9200', timeout=240)
    es = Elasticsearch(
        hosts=host_name,  # esdatanodes
        timeout=120,#time_out,  # increase timeout from default 10s to 120s
        http_auth=(user,password),
        #http_auth=('elastic', 'dWHXgtISrCbzvaVqgqSMJxAA'),
        verify_certs=certs,
        headers=h
    )

    # Get all the Task Groupings

    grp_data = task_grouping(ora_con, eog_user_id)
    

    for row in grp_data:
        print ("grp_id="+str(row[0]))
        grp_id = row[0]
        cur2=ora_con.cursor()
        lrc_cursor2=ora_con.cursor()
        cur2.callproc('ifac_dba.ifac_elastic_pkg.sp_idb_ma_se_task_type',[0,grp_id,lrc_cursor2])
        ora_rows2=[]
        ora_rows2 = lrc_cursor2.fetchall()
        lrc_cursor2.close()
        cur2.close()
        for index in es.indices.get(index_name  + str(grp_id) + '20' + '*'):
             print (index)
             index_name_full = index
             type_name_full = type_name + str(grp_id)

        try:
                for row2 in ora_rows2:
                    print(row2[0] + " " + str(row2[1]))
                    tt_id = row2[1]
                    s_app = row2[0]
                    cur_det=ora_con.cursor()
                    lrc_cursor_det=ora_con.cursor()
                    cur_det.callproc('ifac_dba.ifac_elastic_pkg.sp_ma_se_task_es', [0, tt_id, 0, s_app, 'N',interval, lrc_cursor_det])
                    ora_rows3=[]
                    ora_rows3 = lrc_cursor_det.fetchall()
                    ora_count = lrc_cursor_det.rowcount
                    if ora_count > 0:
                        print("count="+str(ora_count))
                        #print(lrc_cursor_det.description)
                        es_field_names = [(field_mappings_dict[ora_col_name[0].lower()]) for ora_col_name in lrc_cursor_det.description]
                        ora_df = pd.DataFrame(ora_rows3,columns=es_field_names)
                        #print(ora_df['value'])
                        #print(str(ora_df['value']))
                        ora_df['value'] = ora_df['value'].astype(str)
                        #ora_df['value'] = str(ora_df['value'])
                        #print(ora_df)
                        #ora_df['timestamp']=ora_df['updateTs'][0]
                        #print('hello')
                        hdr_list = ['timeStamp','key','taskUuid','taskId','taskName','formUuid','assetId','assetDesc','assetDescShort','assetUuid','barCode','catalogItemId','catalogItemName','categoryId','categoryName','comments','deletedFlag','divisionId','fileCount','formId','formName','formLevelCode','formComments','groupId','groupName','groupMemberId','groupMemberName','propertyId','propertyNb','propertyName','routeId','temporalKey','routeName','serialNumber','startDate','statusCode','statusGroup','status','stockNb','isUsed','groupingId','groupingName','groupingRgbHex','sourceApp','scheduledFrequencyUnit','scheduledFrequencyPeriod','taskDescription','facilityName','divisionName','foremanName','teamName','countyName','stateName','updateWorkerId','updateWorkerName','updateTs','latlong']
                        attr_list = ['taskId','taskAttributeUuid','formAttributeUuid','attributeId','attributeName','attributeDesc','requiredCd','isActive','attributeGrouping','value','valueListId','valueListEntryDesc','attributeWorkerId','attributeUpdateTs','uiControlCode','attributeWorkerName','sortOrder','maxAttUpdateTs']
                        ora_df = ora_df.replace(np.nan,-99999)

                        df1 = ora_df.groupby(hdr_list,as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
                        df1['attributes']= df1['attributes'].apply(lambda row: replace_value(row))
                    
                        df1=df1.replace(-99999,np.nan)
                        df1['assetId'] = df1['assetId'].replace(np.nan,0)
                        df1['assetId'] =df1['assetId'].astype(int)
                        df1['categoryId'] = df1['categoryId'].replace(np.nan,0)
                        df1['categoryId'] =df1['categoryId'].astype(int)
                        df1['stockNb'] = df1['stockNb'].replace(np.nan,0)
                        df1['stockNb'] =df1['stockNb'].astype(int)
                        df1['catalogItemId'] = df1['catalogItemId'].replace(np.nan,0)
                        df1['catalogItemId'] =df1['catalogItemId'].astype(int)
                        df1['groupId'] = df1['groupId'].replace(np.nan,0)
                        df1['groupId'] =df1['groupId'].astype(int)
                        df1['groupMemberId'] = df1['groupMemberId'].replace(np.nan,0)
                        df1['groupMemberId'] =df1['groupMemberId'].astype(int)
                        
                        equip_json=df1.to_json(orient='records')
                        #print(equip_json['object']['attributes'][0]['value'])
                        json_df=json.loads(equip_json)
                        json_df[0]
                        #print(equip_json)
        
                        if es.indices.exists(index_name):
                                print('Index exists')
                                print("updating index "+ index_name_full)
                                print("updating type "+ type_name_full)
     
                                faclist=[]
                                for doc in json_df:
                                    print("updating UUID "+ doc['key'])
                                    action = {"_index":index_name_full,"_type":type_name_full,"_id":doc['key'],"_on_type": "update", "_source": doc}
                                    faclist.append(action)
                                #print(faclist)
        
                                #print(faclist)

                                success, info = helpers.bulk(es, faclist)
                                if success:
                                      print("updated")
                                if not success:
                                    #print(info)
                                    #resultlist.append({'traceid':7,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info})
                                    raise RuntimeError('error bulk')
        
        
                    lrc_cursor_det.close()
                    cur_det.close()
        except Exception as e:
           print (e)
           
        print ("refreshing index "+ index_name_full)
        es.indices.refresh(index=index_name_full)
        es.cluster.health(wait_for_no_relocating_shards=True, wait_for_active_shards='all')

    #for rw_det in ora_rows:
                #print(row_det)
                
    # create multiple threads for each task grouping
    #grp_parallel_threads(grp_data, eog_user_id, load_fl)
    #print(grp_data)
    #params=[1,4506215,load_fl]
    #load_tasks(params)
    print("done")


except Exception as e:
    print(e)
    # send_mail(recipientslist,"Tasks Pivot Index", MIMEText(str(e)+' Tasks Pivot index failed'))
finally:
    ora_con.close()
    # send_mail(recipientslist,"Tasks Pivot Index", MIMEText('Tasks Pivot index completed'))





