#!/usr/local/bin/python3
def order(frame,var):
    varlist =[w for w in frame.columns if w not in var]
    frame = frame[var+varlist]
    return frame

def replace_value(row):
    new_row=[]
    for i in row:
        for key,value in i.items():
            if value ==-99999:
                i[key]=np.nan
    return row


import sys
import configparser
import cx_Oracle as db
import os, time, smtplib, socket, datetime
import socket
from email.mime.text import MIMEText
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import pandas as pd
import numpy as np
import json
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
import email_process


try:
            pd.options.display.max_colwidth = 1000

            hstname = socket.gethostname()

            esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
            config = configparser.ConfigParser()
            config.read(esconfigfilename)

            es_search_conf = config['FIELDOPSESSTAGE']
            print(es_search_conf)
            host_name = es_search_conf['HostName']
            print(host_name)
            time_out = int( es_search_conf['Timeout'])
            print(time_out)
            user = es_search_conf['User']
            print(user)
            password = es_search_conf['Password']
            print(password)
            certs =  es_search_conf['VerifyCerts']
            print(certs)
            header = es_search_conf['Header']
            print(header)
            h = { "Content-type":"application/json" }

            configfilename = '/home/odmbatch/ifacility/es_mrte_contact.ini'
            print(configfilename)

            es_index_list = [configfilename]
            resultlist =[]


            subject = 'miRoute Contact ES Process'

            for configfilename in es_index_list:
                try:
                    config = configparser.ConfigParser()
                    config.read(configfilename)

                    #ES email
                    es_email_conf = config['EMAIL']
                    sender = es_email_conf['EmailFrom']
                    recipients = es_email_conf['EmailTo']

                    #ES Index Settings to set shards and replicas
                    index_settings = {}
                    index_settings['settings'] = {}

                    for key, val in config.items('ESINDEXBODY'):
                                index_settings['settings'][key] = val
                    #print(index_settings)

                    request_body = index_settings

                    #ES index details
                    es_index_conf = config['ESINDEXDETAILS']
                    alias_name = es_index_conf['AliasName']
                    index_name = datetime.datetime.now().strftime('{0}_%H_%M_%d_%m_%Y'.format(alias_name))
                    print(index_name)
                    type_name = es_index_conf['TypeName']
                    ignore =  int(es_index_conf['Ignore'])
                    nested_index = es_index_conf['NestedIndex']
                    index_id = es_index_conf['IndexFieldId']
                    bulk_push_size = int(es_index_conf['BulkPushSize'])
                    refresh_interval = es_index_conf['RefreshInterval']
                    #print(refresh_interval)
                    field_mappings = es_index_conf['IndexFieldMappings']
                    #print(field_mappings)
                    field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
                    field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))

                    #print(field_mappings_dict)

                    #ES mapping
                    es_mapping_conf = config['ELASTICTEMPLATE']
                    mapping_file = es_mapping_conf['MappingFile']
                    with open('{0}'.format(mapping_file), 'r') as mappingFile:
                            mappings = mappingFile.read()



                    #Oracle settings
                    db_conf = config['DATABASE']
                    connection_string = db_conf['ConnectionString']
                    object_name = db_conf['ObjectName']
                    where_clause = db_conf['WhereClause']
                    sql_path = db_conf['SqlPath']

                      # End of all Parameters--------------------------------------------------------------------------------------------------------------------------------------------------------

                    # Connect to Oracle
                    try:
                        start_time = time.time()
                        ora_con = db.Connection(connection_string)
                        ora_cursor = ora_con.cursor()
                        ora_cursor.arraysize = 10000
                        with open('{0}'.format(sql_path), 'r') as sqlFile:
                            ora_sql = sqlFile.read()

                        ora_query = ora_sql

                        ora_rows=[]
                        ora_cursor.execute(ora_query)
                        ora_rows = ora_cursor.fetchall()
                        print(ora_rows)

                        ora_count = ora_cursor.rowcount
                        #print(ora_count)

                        es_field_names = [(field_mappings_dict[ora_col_name[0].lower()]) for ora_col_name in ora_cursor.description]
                        #print(es_field_names)
                        ora_cursor.close()
                        ora_con.close()
                    except db.DatabaseError as e:
                        raise
                        resultlist.append({'traceid':5,'indextype':'Oracle Database Error ','indexname':index_name,'alias_name':alias_name,'message':'Database Error','output':str(e)})

                    es = Elasticsearch(
                        hosts = host_name,#esdatanodes
                        timeout = time_out, # increase timeout from default 10s to 120s
                        http_auth=(user,password),
                        verify_certs=certs,
                        headers = h
                              )
                    print(es)


                    ora_df = pd.DataFrame(ora_rows,columns=es_field_names)
                    print(ora_df)
                    #print(ora_df['timestamp'])
                    contact_list = ['contactId','firstName','lastName','nickName','phoneNbrMobile','phoneNbrWork','phoneNbrHome','phoneNbrOther','faxNbrWork','faxNbrHome','pagerNbr','emailAddressWork','emailAddressHome','emailAddressOther','networkId','workerId','eogUserId','jobTitle','mgrContactId','officeLocation','divisionId','vendorFl','vendorName','profileImageUrl','profileImageTs','comments','onCallFl','offWorkFl','roleId','roleName','roleDescr','roleHierarchy','allowOnCallFl','createTs','createUser','updateTs','updateUser']
                    route_list = ['routeId','userStatus']

                    ora_df = ora_df.replace(np.nan,-99999)
                    #print(ora_df)
                    df1 = ora_df.groupby(contact_list, as_index=False).apply(lambda x: x[route_list].to_dict('r')).reset_index().rename(columns={0:'routeList'})
                    #print(df1)

                    df1 = df1.replace(-99999, np.nan)
                    df1['routeList']= df1['routeList'].apply(lambda row: replace_value(row))

                    contact_json=df1.to_json(orient='records')
                    json_df=json.loads(contact_json)
                    json_df[0]
                    #print(json_df[0])

                    if es.indices.exists(index_name):
                        print('Index eixsts')
                        contactlist=[]
                        for doc in json_df:
                            #print(doc)
                            action = {"_index":index_name,"_type":type_name,"_id":doc['contactId'],"_on_type": "update", "_source": doc}
                            contactlist.append(action)
                        #print(faclist)

                        #print(faclist)
                        success, info = helpers.bulk(es, contactlist)
                        if not success:
                            #print(info)
                            resultlist.append({'traceid':7,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info})
                            raise RuntimeError('error bulk')
                    elif not es.indices.exists(index_name):
                        es.indices.create(index=index_name, ignore=400, body=request_body)
                        print('Index Created'+index_name)
                        es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
                        count = es.count(index=index_name, doc_type=type_name, body={"query": {"match_all": {}}})


                        contactlist=[]
                        for doc in json_df:
                            #print(doc)
                            action = {"_index":index_name,"_type":type_name,"_id":doc['contactId'],"_on_type": "update", "_source": doc}
                            contactlist.append(action)

                        #print(faclist)
                        success, info = helpers.bulk(es, contactlist)

                        if success:
                            print('Data pushed to index')
                        if not success:
                            print(info)
                            resultlist.append({'traceid':7,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info})
                            raise RuntimeError('error bulk')

                    es.indices.put_alias(index=index_name, name=alias_name, ignore=400)

                    indices = list(es.indices.get(alias_name + '*', ignore=[400, 401]))

                    for idx in indices:
                        if idx != index_name and es.indices.exists(idx):
                            print('Index deleted' + idx)
                            es.indices.delete(idx, ignore=404)


                except Exception as e:
                    print(e)
                    resultlist.append({'traceid':4,'indextype':' ','indexname':index_name,'alias_name':alias_name,'message':'unexpected Error','output':str(e)})

finally:
            try:
                subject = hstname + ': miRoute Contact List ES process'
                if len(resultlist) > 0:
                   message = hstname + ' :  miRoute Contact List ES process complete '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")
                   email_process.send_email(sender,MIMEText(str(order(pd.DataFrame(resultlist),['traceid','indexname','alias_name','message','output']).to_html(classes='table',index=False,escape=False)),'html'),recipients,subject)
            except Exception as e:
                message = hstname+ ':  miROUte Contact List ES process complete unexpected Error '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")+str(e)
                print(e)
                email_process.send_email(sender,MIMEText(message),recipients,subject)


