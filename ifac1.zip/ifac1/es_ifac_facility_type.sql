SELECT ref_value_id "key", ref_value "facility_type"
FROM ( SELECT DISTINCT ref_value_id,ref_value, rank() over(partition by ref_value order by ref_value_id) rnk
       FROM fdm_dba.fdm_attribute_vw faw, fdm_dba.fdm_ref_value frv
       WHERE faw.attribute_id = 109
       AND frv.ref_value_type_id = faw.ref_value_type_id
     )
WHERE rnk=1
