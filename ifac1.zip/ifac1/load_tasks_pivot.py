#!/usr/local/bin/python3
#------------------------------------------------------------------------------------------
# ScriptName :Task Pivot Index                                                                                   
# Author:Radhika Tati
# Date: 11/29/2017                                                                           
#                                                                                          
#                                                                                          
#                                                                                          
#-------------------------------------------------------------------------------------------
import json
import multiprocessing as mp
import os
import sys
import time
from datetime import datetime, timedelta
import pandas as pd
from elasticsearch import Elasticsearch, helpers
import socket, smtplib
import cx_Oracle as db
from email.mime.text import MIMEText
import logging
import configparser


def  send_mail(recipients,subject, msg):
    host = socket.gethostname()
    sender = host + "@eogresources.com"
    smtp_host = "smtp.eogresources.com"
    recipients = recipientslist.split(",")
    email_msg = msg
    email_msg['Subject'] = subject
    email_msg['From'] = sender
    email_msg['To'] = recipients
    smtpObj = smtplib.SMTP(smtp_host)
    smtpObj.sendmail(sender, recipients, email_msg.as_string())

def task_grouping(ora_con,eog_user_id):
    cur=ora_con.cursor()
    lrc_cursor=ora_con.cursor()
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_idb_task_grouping',[eog_user_id,lrc_cursor])
    ora_rows=[]
    ora_rows = lrc_cursor.fetchall()
    lrc_cursor.close()
    cur.close()
    print(ora_rows)
    ora_rows = [x[0] for x in ora_rows]
    return ora_rows

def grp_parallel_threads(grp_data,eog_user_id,load_fl):
    if __name__ == '__main__':
        pt=mp.Pool(4)
        params = [(grouping_id,eog_user_id,load_fl) for grouping_id in grp_data]
        df_results = pt.map(load_tasks,params)
        print(df_results)
        pt.close()
        pt.join()
    return df_results

def task_type(ora_con,eog_user_id,grouping_id):
    cur=ora_con.cursor()
    lrc_cursor=ora_con.cursor()
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_idb_task_type',[eog_user_id,grouping_id,lrc_cursor])
    ora_rows=[]
    ora_rows = lrc_cursor.fetchall()
    lrc_cursor.close()
    cur.close()
    ora_rows = [x[0] for x in ora_rows]
    return ora_rows 

def create_index(index_name,type_name):
    mappings= {
        "dynamic_templates": [{
                "integers": {
                "match_mapping_type": "integer",
                "mapping": {
                  "type": "float"
                }
              }
            },
                              {

                "string_fields": {
                  "mapping": {
                    "index": "analyzed",
                    "omit_norms": True,
                    "type": "string",
                    "fields": {
                      "raw": {
                        "ignore_above": 256,
                        "index": "not_analyzed",
                        "type": "string"
                      }
                    }
                  },
                  "match": "*",
                  "match_mapping_type": "string"
                }
              }]
        }

    shards = 1
    replicas = 0
    es.indices.create(index=index_name, ignore=400, body={"number_of_shards":shards,"number_of_replicas":replicas})
    es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
    es.indices.put_settings(index=index_name, body={"index": {"refresh_interval": "-1"}})

def pivot_task_type(task_type_id,ora_con,eog_user_id,load_fl):
    cur=ora_con.cursor()
    lrc_cursor=ora_con.cursor()
    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_idb_task_pivot',[eog_user_id,task_type_id,load_fl,lrc_cursor])
    ora_rows=[]
    ora_rows = lrc_cursor.fetchall()
    #print(ora_rows)
    ora_count = lrc_cursor.rowcount
    print(ora_count)
    es_field_names=[]
    final_json={}
    if ora_count>0:
        es_field_names = [x[0] for x in lrc_cursor.description]
        task_df = pd.DataFrame(ora_rows,columns=es_field_names)
        task_type_json=task_df.to_json(orient='records')
        final_json=json.loads(task_type_json)
        lrc_cursor.close()
        cur.close()
        print(len(final_json))
        return final_json,ora_rows,es_field_names
    else:
        return final_json,ora_rows,es_field_names


def parallel_generator(ora_rows,index_name,type_name,es_field_names):
    for row in ora_rows:
        data_dict = {}
        data_dict = dict(zip(es_field_names, row))
        yield {
                '_index': index_name,
                '_type': type_name,
                '_id': data_dict['eventGuid'],
                '_source': data_dict
            }


def load_tasks(params):
  try:  
    grouping_id = params[0]
    eog_user_id = params[1]
    load_fl = params[2]
    #load_fl = params[2]
    ora_con = db.connect('fdm_admin/Test_123@r1datd.eogresources.com')
    #Check for the index and create an index
    index_name = 'idb_task_pivot'+str(grouping_id)+datetime.now().strftime ("%Y%m%d")
    print(index_name)
    type_name = 'idb_task_pivot'+str(grouping_id)
    print(type_name)
    if es.indices.exists(index=index_name):
        print(index_name+' exists')
    else:
        create_index(index_name,type_name)

    # Get the task type data
    task_type_data = task_type(ora_con,eog_user_id,grouping_id)
    for row in task_type_data:
        print(row)
        pivot_data,ora_rows,es_field_names=pivot_task_type(row,ora_con,eog_user_id,load_fl)
        if len(pivot_data) >= 5000:
            
            # do a bulk push 
            print('Inside of parallel bulk:'+str(row) )
            print('Before Parallel Push'+str(datetime.now()))
            for success, info in helpers.parallel_bulk(es,parallel_generator(ora_rows, index_name, type_name,es_field_names),thread_count=4,chunk_size=2500):
                #print(success)
                #print(info)
                if not success:
                    print('Documents Failed:',info)
                #else:
                    #print(success)
                    #print(info)
            print('After Parallel Push'+str(datetime.now()))
            es.indices.flush(index= index_name,wait_if_ongoing=True)
            print( 'After Parallel Flush: '+str(datetime.now()))
        else:
            if len(pivot_data) > 0:
                print('Inside of helpers bulk:'+str(row) )
                task_data=[]
                sleepcount=0
                print('before creating documents: '+str(datetime.now()))
                for doc in pivot_data:
                    action  = {"_index":index_name,"_type":type_name,"_id":doc['eventGuid'],"_on_type": "update", "_source": doc}
                    task_data.append(action)
                print('After creating documents: '+str(datetime.now()))
                helpers.bulk(es,task_data)
                print('After helpers bulk: '+str(datetime.now()))
                es.indices.flush(index= index_name, wait_if_ongoing=True)
                print('After helpers flush: '+str(datetime.now()))
                sleepcount+=1
            if len(pivot_data) > 0 and sleepcount > 20:
                sleepcount = 0
                time.sleep(100)
    es.indices.put_settings(index=index_name, body={ "index": {"refresh_interval": "1s","number_of_replicas":2}})
    es.indices.put_alias(index = index_name, name = type_name, ignore = 400)
    indices = list(es.indices.get_alias(type_name, ignore=[400,404]))
    for idx in indices:
        day = datetime.now()
        if index_name != idx:
            print("The index that need to be deleted are:",idx)
            es.indices.delete(idx, ignore = 404)
            print("Deleted the index ", idx)

    es.indices.put_alias(index=index_name, name='idb_task_type_pivot', ignore=400)   
    ora_con.close()    
  except Exception as e:
    print(e)
    #ora_con.close()
try:
    eog_user_id = 4506215
    recipientslist = 'radhika.tati@eogresources.com,vasudha.putta@eogresources.com'
    load_fl=sys.argv[1]

    esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
    config = configparser.ConfigParser()
    config.read(esconfigfilename)

    es_search_conf = config['FIELDOPSESSTAGE']
    print(es_search_conf)
    host_name = es_search_conf['HostName']
    print(host_name)
    time_out = int( es_search_conf['Timeout'])
    print(time_out)
    user = es_search_conf['User']
    print(user)
    password = es_search_conf['Password']
    print(password)
    certs =  es_search_conf['VerifyCerts']
    print(certs)
    header = es_search_conf['Header']
    print(header)
    h = { "Content-type":"application/json" }

    
    #Connect to Oracle
    ora_con = db.connect('fdm_admin/Test_123@r1datd.eogresources.com')

    #Connect to Elastic search
    #es = Elasticsearch(hosts='ssearch:9200', timeout=240)
    es = Elasticsearch(
                hosts = host_name,#esdatanodes
                timeout = time_out, # increase timeout from default 10s to 120s
                http_auth=(user,password),
                verify_certs=certs,
                headers = h
                       )

    #Get all the Task Groupings

    grp_data = task_grouping(ora_con,eog_user_id)

    #create multiple threads for each task grouping
    grp_parallel_threads(grp_data,eog_user_id,load_fl)
    #params=[1,4506215,load_fl]
    #load_tasks(params)
   

except Exception as e:
    print(e)
    #send_mail(recipientslist,"Tasks Pivot Index", MIMEText(str(e)+' Tasks Pivot index failed'))
finally:
    ora_con.close()
    #send_mail(recipientslist,"Tasks Pivot Index", MIMEText('Tasks Pivot index completed'))


