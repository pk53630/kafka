SELECT DISTINCT kp.property_id key,
       kp.property_id ,
       kp.property_nb ,
       kp.property_sub ,
       kp.property_name ,
       kp.division_Id ,
       kp.county_cd ,
       kp.show_fl ,
       kp.api_nb ,
       kp.dda_group_name ,
       kp.primo_property_type ,
       kp.well_type_desc ,
       kp.producing_status_desc ,
       kp.team_name ,
       kp.prospect_name ,
       kp.trend_name ,
       kp.latitude ,
       kp.longitude ,
       kp.route_name ,
       kp.foreman_name ,
       kp.property_urn ,
       kp.operator_name ,
       kp.property_nb_text ,
       to_char(to_timestamp_tz(to_char(kp.first_sales_dt,'YYYY-MM-DD'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM')) first_sales_dt,
       to_char(to_timestamp_tz(to_char(kp.spud_dt,'YYYY-MM-DD'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM')) spud_dt ,
       to_char(to_timestamp_tz(to_char(kp.rig_release_dt,'YYYY-MM-DD'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM')) rig_release_dt ,
       kp.max_completion_cd ,
       lower(REGEXP_REPLACE(kp.property_guid, '(.{8})(.{4})(.{4})(.{4})(.*)', '\1-\2-\3-\4-\5')) property_guid ,
       to_char(to_timestamp_tz(to_char(kp.first_prod_dt,'YYYY-MM-DD'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM')) first_prod_dt ,
       kp.route_id ,
       kp.rig_name ,
       kp.ke_status ,
       to_char(to_timestamp_tz(to_char(kp.sold_dt,'YYYY-MM-DD'), 'YYYY-MM-DD"T"HH24:MI:SS.ff3TZH:TZM')) sold_dt ,
       kp.sold_dt_source ,
       kp.ec_entity_id ,
       kp.property_stage ,
       kp.odm_fdm_prprty_id
FROM ke_dba.ke_property kp
WHERE NOT EXISTS(                   
SELECT 1
FROM(
     SELECT fwx.division_id, fwx.well_id, fwx.facility_id, fwx.start_date, fwx.end_date, ow.primo_prprty, ow.primo_prpsub FROM(
                         (SELECT division_id, well_id, facility_id, start_date, end_date,
                                 row_number() OVER (PARTITION BY division_id, well_id,facility_id ORDER BY end_date DESC) rnum
                         FROM fdm_dba.fdm_fac_well_xref)) fwx, odm_dba.odm_well ow
                         WHERE fwx.rnum=1
                         AND fwx.end_date > TRUNC(SYSDATE)
                         AND fwx.division_id = ow.division_id
                         AND fwx.well_id = ow.well_id
                         UNION ALL
                         SELECT fux.division_id, fux.unit_facility_id, fux.facility_id, fux.start_date, fux.end_date, fuf.primo_prprty, fuf.primo_prpsub FROM(
                         (SELECT division_id, unit_facility_id, facility_id, start_date, end_date,
                                 row_number() OVER (PARTITION BY division_id, unit_facility_id, facility_id ORDER BY end_date DESC) rnum
                         FROM fdm_dba.fdm_unit_fac_xref)) fux, fdm_dba.fdm_unit_facility fuf
                         WHERE fux.rnum=1
                         AND fux.end_date > TRUNC(SYSDATE)
                         AND fux.division_id = fuf.division_id
                         AND fux.unit_facility_id = fuf.unit_facility_id) a
                         WHERE a.primo_prprty = kp.property_nb
                         AND a.primo_prpsub = kp.property_sub)
                         AND NVL(kp.primo_property_type, '~') NOT IN ('LEASE - NON PRODUCING','WEL')
                         AND NVL(kp.producing_status_desc,'~') <> 'SOLD'
