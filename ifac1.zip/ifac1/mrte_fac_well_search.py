#!/usr/local/bin/python3
def order(frame,var):
    varlist =[w for w in frame.columns if w not in var]
    frame = frame[var+varlist]
    return frame


def generate_actions(rows,index_name,type_name,index_id):
    for ora_row in rows:
        data_dict = {}
        data_dict = dict(zip(es_field_names, ora_row))

        yield {
                '_index': index_name,
                '_type': type_name,
                '_id': data_dict[index_id],
                '_source': data_dict
            }


import configparser
import sys
import pandas as pd
import cx_Oracle as db
import os, time, smtplib, socket, datetime
import email_process
import numpy as np
import json
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
from email.mime.text import MIMEText
import pyproj
from pyproj import Proj
import pymssql as ms
import socket
#import set_logging

pd.options.display.max_colwidth = 1000

hstname = socket.gethostname()

try:
    esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
    config = configparser.ConfigParser()
    config.read(esconfigfilename)

    es_search_conf = config['FIELDOPSESSTAGE']
    print(es_search_conf)
    host_name = es_search_conf['HostName']
    print(host_name)
    time_out = int( es_search_conf['Timeout'])
    print(time_out)
    esuser = es_search_conf['User']
    #print(esuser)
    espassword = es_search_conf['Password']
    #print(espassword)
    certs =  es_search_conf['VerifyCerts']
    #print(certs)
    header = es_search_conf['Header']
    #print(header)
    h = { "Content-type":"application/json" }

    CONFIGFILENAME = '/home/odmbatch/ifacility/mrte_fac_well_search.ini'
    CONFIG = configparser.ConfigParser()
    #print(CONFIGFILENAME)
    CONFIG.read(CONFIGFILENAME)

    #ES email
    ES_EMAIL_CONF = CONFIG['EMAIL']
    #print(ES_EMAIL_CONF)
    recipients = ES_EMAIL_CONF['EmailTo']
    #print(recipients)
    sender = ES_EMAIL_CONF['EmailFrom']
    #print(sender)
    subject = ES_EMAIL_CONF['Subject']
    #print(subject)    

    #View Details
    view_conf = CONFIG['VIEWS']
    views = view_conf['Views']    
    views = views.split(',')
    #print(views)

    #Index View Mapping
    index_vw_map = CONFIG['ESVIEWINDEXDETAILS']

    #IndexTypeMapping
    index_type_map = CONFIG['ESVIEWINDEXTYPEDETAILS']

    index_settings = {}
    index_settings['settings'] = {}
    
    for key, val in CONFIG.items('ESINDEXBODY'):
            index_settings['settings'][key] = val
            #print(index_settings)

    #ES Index Details
    es_index_conf = CONFIG['ESINDEXDETAILS']       
    nested_index = es_index_conf['NestedIndex']
    index_id = es_index_conf['IndexFieldId']
    bulk_push_size = int(es_index_conf['BulkPushSize'])
    refresh_interval = es_index_conf['RefreshInterval']

    #print(refresh_interval)
    #Oracle
    ora_conf = CONFIG['DATABASE']
    conn_string = ora_conf['ConnectionString']    

    sql_server_conf = CONFIG['SQLSERVER']
    host = sql_server_conf['Host']
    user = sql_server_conf['User']
    pwd = sql_server_conf['Password']
    dbname = sql_server_conf['Database']

    #ES mapping
    es_mapping_conf = CONFIG['ELASTICTEMPLATE']

    #connect to elastic search and index setup-----------------------------------------------------------------
    es = Elasticsearch(
                hosts = host_name,#esdatanodes
                timeout = time_out, # increase timeout from default 10s to 120s
                http_auth=(esuser,espassword),
                verify_certs=certs,
                headers = h
                      )
    #print(es)
    request_body = index_settings

    try:#connect to oracle
       ora_con = db.connect(conn_string)
            
       for view in views:
           print('view name')
           print(view)

           if view == 'MRTE_FACILITY_SEARCH':
                sql_path = ora_conf['FacilitySqlPath']
                field_mappings = es_index_conf['FacilityIndexFieldMappings']
                mapping_file = es_mapping_conf['FacilityMappingFile']
           elif view == 'MRTE_WELL_SEARCH':
                sql_path = ora_conf['WellSqlPath']  
                field_mappings = es_index_conf['WellIndexFieldMappings']
                mapping_file = es_mapping_conf['WellMappingFile']
           elif view == 'MRTE_PIPELINE_SEARCH':
                sql_path = ora_conf['PipelineSqlPath']
                field_mappings = es_index_conf['PipelineIndexFieldMappings']
                mapping_file = es_mapping_conf['PipelineMappingFile']
           elif view == 'MRTE_ROUTE_SEARCH':
                sql_path = ora_conf['RouteSqlPath']
                field_mappings = es_index_conf['RouteIndexFieldMappings']
                mapping_file = es_mapping_conf['RouteMappingFile']
           

           field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
           field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))
           print(field_mappings_dict)

           with open('{0}'.format(mapping_file), 'r') as mappingFile:
                    mappings = mappingFile.read()

           print(mappings)

           print(sql_path)   


           #ES Index Details
           index_name_config = index_vw_map[view]
           print(index_name_config)

           #ES Type Details
           if view == 'MRTE_ROUTE_SEARCH':
               alias_name = es_index_conf[index_name_config]
               type_name_config = index_type_map[view]
           else:
               alias_name = es_index_conf['FacWellAliasName']
               type_name = es_index_conf['FacWellTypeName']
           print(alias_name)
           #type_name_config = index_type_map[view]
           #type_name =  es_index_conf[type_name_config]
           print(type_name)

           if view != 'MRTE_FACILITY_SEARCH':
                 index_name = datetime.datetime.now().strftime('{0}_%H_%M_%d_%m_%Y'.format(alias_name))
           print(index_name)

           #print(alias_name)
           with open('{0}'.format(sql_path), 'r') as sqlFile:
               ora_sql = sqlFile.read()

           ora_query = ora_sql
           print('query'+ora_query)

           ora_result=[]
           ora_cursor = ora_con.cursor()
           ora_cursor.execute(ora_query)
           ora_result = ora_cursor.fetchall()
           ora_count = ora_cursor.rowcount
           print(ora_count)
           ora_df=[]
           final_ora_df = []

           #print(ora_result)

           if view != 'MRTE_ROUTE_SEARCH':

              for rec in ora_result:
                 #print(rec)

                 #     sql_clause = ''.join(sql_clause)
                 #print(latitude)
                 #print(longitude)
                 if view == 'MRTE_FACILITY_SEARCH':
                       latitude = rec[18]
                       longitude = rec[19]
                 elif view == 'MRTE_WELL_SEARCH':
                       latitude = rec[50]
                       longitude = rec[51]
                 elif view == 'MRTE_PIPELINE_SEARCH':
                       latitude = rec[11]
                       longitude = rec[12]

               
                 if latitude != None and longitude != None and latitude <= 90 and longitude <= 180: 
                      inputCoordinate = (float(longitude),float(latitude))
                      #print(inputCoordinate)
                      inProj = Proj(init='epsg:4267')
                      outProj = Proj(init='epsg:4326')

                      if view != 'MRTE_PIPELINE_SEARCH':
                           wgs84_longitude, wgs84_latitude = pyproj.transform(inProj,outProj,inputCoordinate[0],inputCoordinate[1])

                           wgs84_latitude = round(wgs84_latitude,7)
                           wgs84_longitude = round(wgs84_longitude,7)
                           wgs84_latlong = str(wgs84_latitude)+','+str(wgs84_longitude)

                      #print(wgs84_latitude,wgs84_longitude)
                      #print(wgs84_latlong)
                      #print(ora_query2)

                           rec = rec+(wgs84_latitude,wgs84_longitude,wgs84_latlong)
                 elif latitude is None and longitude is None:
                      if  view != 'MRTE_PIPELINE_SEARCH':
                          rec=rec+(None,None,None)
                 ora_df.append(rec)
           else:
              ora_df = ora_result 

           #print(ora_result)

           if view not in ['MRTE_ROUTE_SEARCH','MRTE_PIPELINE_SEARCH']:
              try:
                  ms_con = ms.connect(host=host, user=user, password=pwd, database=dbname, as_dict=True)

                  ms_query = """SELECT LTRIM(RTRIM(P.PropertyNumber)) primo_prprty
                                     , LTRIM(RTRIM(WR.MeterSN)) power_meter 
                                FROM DBO.vwPropertyComplete P 
                                LEFT JOIN SAIT.Electrical.CommercialWorkRequest WR ON P.PropertyNumber = WR.PropertyNumber and WR.activeflag = 1 
                                LEFT JOIN CompletionTB C on C.PropertyNumber=P.PropertyNumber 
                                LEFT JOIN SAIT.Electrical.CommercialCOOP COOP ON COOP.idCoop = WR.idCoop
                                WHERE WR.IsPrimary IN (1,2)"""
                  #print(ms_query)
                  ms_cursor = ms_con.cursor()
                  ms_cursor.execute(ms_query)
                  ms_result = ms_cursor.fetchall()
                  #print(ms_result)
                  
                  ms_df = []

                  ms_df = pd.DataFrame(ms_result)

                  #print(ms_df)
                 
                  ms_cursor.close()
              except ms.DatabaseError as exc:
                  raise


           collist=[]

           for colname in ora_cursor.description:
                 collist=collist+[colname[0].lower()]

           if view not in ['MRTE_ROUTE_SEARCH','MRTE_PIPELINE_SEARCH']:
              collist=collist+['wgs84_latitude','wgs84_longitude','wgs84_latlong']

           ora_df_conv = []
           new_row = []

           for row in ora_df:
               rec=list(row)
               for element in rec: 
                   #print(element)
                   if element == None:
                      rec[rec.index(element)] = -9999
               new_row = tuple(rec)
               ora_df_conv.append(new_row)

           final_ora_df = pd.DataFrame(ora_df_conv,columns=collist)

           print(final_ora_df.dtypes)

           if view not in ['MRTE_ROUTE_SEARCH','MRTE_PIPELINE_SEARCH']:
               collist=collist+['power_meter']

           print(collist)

           #print(es_df)

           es_field_names = [(field_mappings_dict[ora_col_name]) for ora_col_name in collist]
           print(es_field_names)
           
           es_df = []
           if view not in ['MRTE_ROUTE_SEARCH','MRTE_PIPELINE_SEARCH']:
              result_df = []
              result_df = pd.merge(final_ora_df,ms_df,left_on='primo_prprty',right_on='primo_prprty',how='left')
              result_df.reset_index()
              print(len(result_df))
              es_df = pd.DataFrame(result_df.values,columns=es_field_names)
           else:
              es_df = pd.DataFrame(ora_df_conv,columns=es_field_names)

           print(es_df)
           
#print(result_df.dtypes)

           json_df = []
           json_df=json.loads(es_df.to_json(orient='records'))
           print(len(json_df))
           #json_df=json.loads(es_df)


           #print(es_field_names)

           start_time=time.time()

           indices = list(es.indices.get(alias_name+'*', ignore=[400,401]))


           if not es.indices.exists(index_name):
                    #print('inside create')
                    #print(mappings)
                    es.indices.create(index=index_name, ignore=400,body=request_body)
                    es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
           count = es.count(index=index_name, doc_type=type_name, body={ "query": {"match_all" : { }}})
           print(count)

           if ora_count > 0:

              if ora_count < bulk_push_size:
                   bulk_data = []
                   cnt = 0

                   for row in json_df:
                      cnt=cnt+1
                         #data_dict = {}
                         #data_dict = dict(zip(es_field_names, row))

                         #print(data_dict)
  
                      for key, value in row.items():
                                    # do something with value
                                    if value  == -9999:
                                         row[key] = None

                      action = {
                               '_index': index_name,
                               '_type': type_name,
                               '_id': row[index_id],
                               '_source':row 
                               }

                      bulk_data.append(action)

                   success,info=helpers.bulk(es, bulk_data)
                   if not success:
                           print("response", info)
                           email_body=info
                           subject = hstname+':miRoute Facility and Well Search Elastic Index Update Errored'
                           email_process.send_email(sender, MIMEText(email_body), recipients, subject)

           else:
              for success, info in helpers.parallel_bulk(es, generate_actions(ora_df,index_name,type_name,index_id), thread_count=5, chunk_size=bulk_push_size):
                      if not success:
                           print("response", info)
                           email_body=info
                           subject = hstname+':miRoute Facility and Well Search Elastic Index Update Errored'
                           email_process.send_email(sender, MIMEText(email_body), recipients, subject)

           print('count row'+str(cnt))

           es.indices.refresh(index=index_name)
           count = es.count(index=index_name, doc_type=type_name, body={ "query": {"match_all" : { }}})
           print(count)
           es.indices.put_alias(index=index_name, name=alias_name, ignore=400)
           es.indices.put_settings({"index": {"refresh_interval": refresh_interval}}, index=index_name)

           end_time=time.time()
           print("Time taken to upload index data : %s seconds " % (end_time - start_time))

           for idx in indices:
               if idx != index_name and es.indices.exists(idx):
                    print('INdex deleted'+idx)
                    es.indices.delete(idx, ignore = 404)

       ora_cursor.close()
       ora_con.close()
            
    except db.DatabaseError as err:
            raise
            #set_logging.logtofile(50,'database Error')
            #resultlist.append({'traceid':5,'indextype':'Oracle Database Error ','indexname':index_name,'alias_name':index_name,'message':'Database Error','output':str(err)})

except Exception as e:
       print(e)
       #resultlist.append({'traceid':4,'indextype':' ','indexname':index_name,'alias_name':index_name,'message':'unexpected Error','output':str(e)})
       #set_logging.logtofile(40,'Unexpected Error')
       subject = hstname+':miRoute Facility and Well Search Elastic Index Update Errored'
       email_process.send_email(sender,MIMEText(str(e)),recipients,subject)

finally:
    try:
        print('successful')
    except Exception as e:
        message = 'miRoute Facility and Well Search Elastic Index Update Errored '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")+str(e)
        subject = hstname+subject
        print(e)
        email_process.send_email(sender,MIMEText(str(e)),recipients,subject)

