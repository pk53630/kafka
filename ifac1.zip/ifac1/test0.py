import cx_Oracle as db
import configparser


esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
config = configparser.ConfigParser()
config.read(esconfigfilename)

es_search_conf = config['ORASTAGE_IFAC_DBA']
host_name = es_search_conf['HostName']
user_name = es_search_conf['User']
password  = es_search_conf['Password']
port      = es_search_conf['Port']
print(host_name, user_name, password, port)

string = user_name+'/'+password+'@'+host_name
ora_con = db.connect(string)
cur = ora_con.cursor()

print('success')
cur.close()
ora_con.close()




