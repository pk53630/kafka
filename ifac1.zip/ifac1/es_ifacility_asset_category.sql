SELECT category_id "key", category_name, category_name_short
FROM im_dba.im_category
