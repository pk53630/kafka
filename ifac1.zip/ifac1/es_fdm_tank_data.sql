SELECT division_id||cygnet_primo_prprty||cygnet_designation "key"
     , division_id 
     , equipment_name 
     , scada_id
     , itrack_asset_id 
     , procount_merrickid
     , tank_size 
     , cygnet_designation 
     , cygnet_primo_prprty 
FROM fdm_dba.fdm_equipment 
WHERE cygnet_primo_prprty is not null
