select
a.value_list_id "key"
, a.value_list_id 
, a.value_list_name 
, to_char(to_timestamp_tz(to_char(a.update_ts,'YYYY-MM-DD"T"HH24:MI:SS'), 'YYYY-MM-DD"T"HH24:MI:SS'),'YYYY-MM-DD"T"HH24:MI:SS') as time_stamp
, b.short_text_value 
, b.sort_order 
, b.value_list_entry_id 
, b.active_fl is_active 
, to_char(to_timestamp_tz(to_char(b.update_ts,'YYYY-MM-DD"T"HH24:MI:SS'), 'YYYY-MM-DD"T"HH24:MI:SS'),'YYYY-MM-DD"T"HH24:MI:SS') update_ts
from im_dba.im_value_list a,
(select * From im_dba.im_value_list_entry order by 1) b
where trim(a.value_list_id) = trim(b.value_list_id)
