#!/usr/local/bin/python3

######################################################################################################
# Description:
# Script is used for log the error information
#  Created on : 11-20-2018
#  Created By : Vijaya prasad
#----------------------------------------------------------------------------------------------------
#  Ver no 	Modified By      Modified Date               Description
#
#
#######################################################################################################

import sys
import datetime

startTs = datetime.datetime.now()

lExeSqlStmt = '''
DECLARE

    grec_job_summ       fdm_dba.fdm_job_pkg.rec_job_run;
    ln_rac_node_id      NUMBER;
    lv_service_name     VARCHAR2(100);
    lv_job_id           NUMBER;
    lv_job_run_id       NUMBER;

BEGIN
    BEGIN
        SELECT USERENV( 'INSTANCE' ) rac_node_id, service_name
          INTO ln_rac_node_id, lv_service_name
          FROM v$session
         WHERE sid = USERENV( 'SID' );
    EXCEPTION
        WHEN OTHERS THEN
            ln_rac_node_id := 0;
            lv_service_name := 'NO_DATA';
    END;
    lv_job_id := fdm_dba.fdm_job_pkg.fn_get_job_id({19});

	grec_job_summ.job_run_id          := fdm_dba.fdm_job_pkg.fn_get_job_run_id;    -- CONSTANT
	grec_job_summ.job_run_date        := SYSDATE;          -- CONSTANT
	grec_job_summ.job_id              := lv_job_id;
	grec_job_summ.division_id         := {0};
	grec_job_summ.job_status_id       := fdm_dba.fdm_code_value_pkg.fn_get_code_value_id( 'JOB_STATUS', {1});
	grec_job_summ.complete_load_fl    := {2};
	grec_job_summ.rac_node_id         := ln_rac_node_id;   -- CONSTANT
	grec_job_summ.ora_service_name    := lv_service_name;  -- CONSTANT
	grec_job_summ.ora_err_code        := {3};              -- 0:- Success, 1:-Error
	grec_job_summ.ora_err_message     := {4};
	grec_job_summ.job_message         := {5};
	grec_job_summ.start_ts            := {6};
	grec_job_summ.end_ts              := {7};
	grec_job_summ.last_run_ts         := {8};
	grec_job_summ.package_name        := {9};       -- CONSTANT
	grec_job_summ.procedure_name      := {10};    -- CONSTANT
	grec_job_summ.table_name          := {11};     -- CONSTANT
	grec_job_summ.dml_operation_name  := {12};             -- CONSTANT
	grec_job_summ.record_count        := {13};
	grec_job_summ.create_user         := {14};
	grec_job_summ.update_user         := {15};
	grec_job_summ.job_exception_fl    := {16};
	grec_job_summ.job_summary_fl      := {17};
	grec_job_summ.job_status          := {18};

	fdm_dba.FDM_JOB_PKG.sp_update_job_run(grec_job_summ);

EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
'''
lExeSqlStmt1= None
def run_sql_stmt(divisionId,
                    jobStatusId,
                    completeLoad_fl,
                    oraErrcode,
                    oraErrMessage,
                    jobMessage,
                    startTs,
                    endTs,
                    lastRunTs,
		    package_name,
		    procedure_name,
		    table_name,
		    dml_operation_name,
                    RecCount,
                    createUser,
                    UpdateUser,
                    jobException_fl,
                    jobSummary_fl,
                    jobStatus,
		    job_Id
                    ):
    import cx_Oracle as db
    ora_con = db.connect('fdm_load/FdmLoad_201807@r1datd.eogresources.com')
    cur = ora_con.cursor()
    lExeSqlStmt_1 = lExeSqlStmt.format(divisionId,
                                    jobStatusId,
                                    completeLoad_fl,
                                    oraErrcode,
                                    oraErrMessage,
                                    jobMessage,
                                    startTs,
                                    endTs,
                                    lastRunTs,
				    package_name,
				    procedure_name,
				    table_name,
				    dml_operation_name,
                                    RecCount,
                                    createUser,
                                    UpdateUser,
                                    jobException_fl,
                                    jobSummary_fl,
                                    jobStatus,
				    job_Id
                                    )
    #print(lExeSqlStmt_1)
    cur.execute(lExeSqlStmt_1)
    cur.close()
    ora_con.close()
