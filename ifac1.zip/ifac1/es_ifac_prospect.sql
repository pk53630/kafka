SELECT DISTINCT prospect_id "key", prospect_id, prospect_name
FROM odm_info.odm_completion
WHERE PROSPECT_ID IS NOT NULL