#!/usr/local/bin/python3
def order(frame,var):
    varlist =[w for w in frame.columns if w not in var]
    frame = frame[var+varlist]
    return frame


def generate_actions(rows,index_name,type_name,index_id):
    for ora_row in rows:
        data_dict = {}
        data_dict = dict(zip(es_field_names, ora_row))

        yield {
                '_index': index_name,
                '_type': type_name,
                '_id': data_dict[index_id],
                '_source': data_dict
            }

import configparser
import sys
import pandas as pd
import cx_Oracle as db
import os, time, smtplib, socket, datetime
import email_process
import numpy as np
import json
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
from email.mime.text import MIMEText
import socket
#import set_logging

pd.options.display.max_colwidth = 1000

hstname = socket.gethostname()

try:
    esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
    config = configparser.ConfigParser()
    config.read(esconfigfilename)

    es_search_conf = config['FIELDOPSESSTAGE']
    print(es_search_conf)
    host_name = es_search_conf['HostName']
    print(host_name)
    time_out = int(es_search_conf['Timeout'])
    print(time_out)
    esuser = es_search_conf['User']
    # print(esuser)
    espassword = es_search_conf['Password']
    # print(espassword)
    certs = es_search_conf['VerifyCerts']
    # print(certs)
    header = es_search_conf['Header']
    # print(header)
    h = {"Content-type": "application/json"}

    CONFIGFILENAME = '/home/odmbatch/ifacility/es_mrte_list.ini'
    CONFIG = configparser.ConfigParser()
    # print(CONFIGFILENAME)
    CONFIG.read(CONFIGFILENAME)

    # ES email
    ES_EMAIL_CONF = CONFIG['EMAIL']
    # print(ES_EMAIL_CONF)
    recipients = ES_EMAIL_CONF['EmailTo']
    # print(recipients)
    sender = ES_EMAIL_CONF['EmailFrom']
    # print(sender)
    subject = ES_EMAIL_CONF['Subject']
    # print(subject)




    index_settings = {}
    index_settings['settings'] = {}

    for key, val in CONFIG.items('ESINDEXBODY'):
        index_settings['settings'][key] = val
        # print(index_settings)

    # ES Index Details
    es_index_conf = CONFIG['ESINDEXDETAILS']
    nested_index = es_index_conf['NestedIndex']
    index_id = es_index_conf['IndexFieldId']
    bulk_push_size = int(es_index_conf['BulkPushSize'])
    refresh_interval = es_index_conf['RefreshInterval']
    alias_name = es_index_conf['AliasName']
    type_name = es_index_conf['TypeName']
    index_name = datetime.datetime.now().strftime('{0}_%H_%M_%d_%m_%Y'.format(alias_name))

    # print(refresh_interval)
    # Oracle
    ora_conf = CONFIG['DATABASE']
    conn_string = ora_conf['ConnectionString']
    #ES mapping
    es_mapping_conf = CONFIG['ELASTICTEMPLATE']

    #connect to elastic search and index setup-----------------------------------------------------------------
    es = Elasticsearch(
                hosts = host_name,#esdatanodes
                timeout = time_out, # increase timeout from default 10s to 120s
                http_auth=(esuser,espassword),
                verify_certs=certs,
                headers = h
                      )
    #print(es)
    request_body = index_settings

    sql_path = ora_conf['SqlPath']
    field_mappings = es_index_conf['IndexFieldMappings']
    mapping_file = es_mapping_conf['MappingFile']

    field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
    field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))
    print(field_mappings_dict)

    with open('{0}'.format(mapping_file), 'r') as mappingFile:
        mappings = mappingFile.read()

    print(mappings)

    try:  # connect to oracle
        ora_con = db.connect(conn_string)

        with open('{0}'.format(sql_path), 'r') as sqlFile:
            ora_sql = sqlFile.read()

        ora_query = ora_sql

        #ora_result=[]
        ora_cursor = ora_con.cursor()
        ora_cursor.execute(ora_query)
        #ora_result = ora_cursor.fetchall()
        #ora_count = ora_cursor.rowcount

        collist = []
        for colname in ora_cursor.description:
            collist = collist + [colname[0].lower()]

        es_field_names = [(field_mappings_dict[ora_col_name]) for ora_col_name in collist]
        print(es_field_names)

        ora_rows = []

        if any(x[1] == db.CLOB for x in ora_cursor.description):
            ora_rows = [tuple([(json.loads(c.read()) if type(c) == db.LOB else c) for c in r]) for r in ora_cursor.fetchall()]

        ora_count = len(ora_rows)
        start_time = time.time()

        indices = list(es.indices.get(alias_name + '*', ignore=[400, 401]))

        if not es.indices.exists(index_name):
            es.indices.create(index=index_name, ignore=400, body=request_body)
            es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
        count = es.count(index=index_name, doc_type=type_name, body={"query": {"match_all": {}}})
        print(count)

        if ora_count > 0:
            if ora_count < bulk_push_size:
                bulk_data = []

                # generate documents
                for ora_row in ora_rows:
                    data_dict = {}
                    data_dict = dict(zip(es_field_names, ora_row))
                    action = {
                        '_index': index_name,
                        '_type': type_name,
                        '_id': data_dict[index_id],
                        '_source': data_dict
                    }

                    bulk_data.append(action)
                # print("==================================================================")
                # print(bulk_data)
                # print("==================================================================")
                success, info = helpers.bulk(es, bulk_data)


            else:
                for success, info in helpers.parallel_bulk(es,generate_actions(ora_rows, index_name, type_name, index_id),
                                                           thread_count=5, chunk_size=bulk_push_size):
                    if not success:
                        raise RuntimeError('error parallel bulk')

            es.indices.refresh(index=index_name)

            es.indices.put_settings({"index": {"refresh_interval": refresh_interval}}, index=index_name)

            indices = list(es.indices.get(alias_name + '*', ignore=[400, 404]))
            print("hello")
            print(indices)

            for idx in indices:
                print(" the index to be deleted is ", idx)
                print("the index name for today is", index_name)

                if index_name != idx:
                    print("The index that need to be deleted are:", idx)
                    es.indices.delete(idx, ignore=404)
                    print("Deleted the index ", idx)

            es.indices.put_alias(index=index_name, name=alias_name, ignore=400)

            idx_count = es.count(index=index_name)['count']
            print(idx_count)
            if ora_count != idx_count:
                info = "Count Mismatch between Oracle Rows %s" % ora_count + " and Index Documents %s" % idx_count

                raise RuntimeError('error record count')



            ora_cursor.close()
            ora_con.close()

    except Exception as e:
        print(e)
        ora_cursor.close()
        ora_con.close()

except Exception as e:
    print(e)





