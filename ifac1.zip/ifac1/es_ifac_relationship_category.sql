SELECT ir.relationship_id||'-'||from_category_id||'-'||to_category_id "key",
       ir.relationship_id,
       ir.relationship_cd,
       ir.relationship_desc,
       CASE WHEN ir.product_cd='OUTPUT' THEN 'MIXED' WHEN ir.product_cd = 'CONTROL' THEN 'ECD' ELSE ir.product_cd END product_cd,
       irc.from_category_id,
       from_cat.category_name from_category_name,
       irc.to_category_id,
       to_cat.category_name to_category_name
  FROM ifac_dba.ifac_relationship ir,
       ifac_dba.ifac_relationship_category irc,
       im_dba.im_category from_cat,
       im_dba.im_category to_cat
 WHERE     ir.relationship_id = irc.relationship_id
       AND irc.from_category_id = from_cat.category_id
       AND irc.to_category_id = to_cat.category_id
