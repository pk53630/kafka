def order(frame,var):
    varlist =[w for w in frame.columns if w not in var]
    frame = frame[var+varlist]
    return frame

def es_results(res,trace_id,index_type):
    for key,value in res.items():
        if key == 'acknowledged':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           return 'Success'
        elif key == 'error':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           #print(value)
           return 'Error'
        elif key == 'status':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})

def replace_value(row):
    new_row=[]
    for i in row:
        for key,value in i.items():
            if value ==-99999:
                i[key]=np.nan
    return row

import sys
import configparser
import cx_Oracle as db
import os, time, smtplib, socket, datetime
from email.mime.text import MIMEText
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import json
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
# sys.path.append(r"C:\Users\rtati\Documents\python_files")
import email_process
import logging

from flask import Flask
from flask_restplus import Api, Resource, fields, reqparse, marshal

app = Flask(__name__)
api = Api(app, version='1.0', title='iFacilities Task Services',
    description='iFacilities Task Services',
)

@api.route('/ma_se_tasks/<string:configFile>/<string:sourceApp>/<int:groupingId>/<int:task_id>/<int:eog_user_id>')
class ElasticSync(Resource):
  # @api.marshal_with(responseBody)
  def get(self, configFile, sourceApp, groupingId, task_id, eog_user_id):
        try:
            print ("start")
            pd.options.display.max_colwidth = 1000

            esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
            config = configparser.ConfigParser()
            config.read(esconfigfilename)

            es_search_conf = config['FIELDOPSESSTAGE']
            print(es_search_conf)
            host_name = es_search_conf['HostName']
            print(host_name)
            time_out = int( es_search_conf['Timeout'])
            print(time_out)
            user = es_search_conf['User']
            print(user)
            password = es_search_conf['Password']
            print(password)
            certs =  es_search_conf['VerifyCerts']
            print(certs)
            header = es_search_conf['Header']
            print(header)
            h = { "Content-type":"application/json" }


            # All Parameters--------------------------------------------------------------------------------------------------------------------
            # print(sys.argv[0])
            configfilename = configFile#sys.argv[1]
            # print(sys.argv[1])
            task_id = task_id
            eog_user_id = eog_user_id
            source_app = sourceApp
            grouping_id = groupingId
            
            print("task_id="+str(task_id))
            print("grouping_id="+str(grouping_id))
            print("source_app="+ source_app)

            es_index_list = [configfilename]
            resultlist =[]


            sender = 'taskpyhouvlxodmtest@eogresources.com'
            recipients = 'todd_knuth@eogresources.com'

            subject = 'MA SE ES Process'

            for configfilename in es_index_list:
                try:
                    print("a")
                    config = configparser.ConfigParser()
                    config.read(configfilename)
                    

                    #ES email
                    es_email_conf = config['EMAIL']
                    sender = es_email_conf['EmailFrom']
                    recipients = es_email_conf['EmailTo']
                    print(recipients)
                    #Elastic Search
                    #elastic_conf = config['ELASTICSEARCH']
                    #cluster_name = elastic_conf['ClusterName']
                    #time_out = int(elastic_conf['TimeOut'])
                    #host_list = elastic_conf['HostList']
                    #host_list = host_list.replace("\n", "")
                    #host_list = host_list.split(',')
                    
                    #Logging Info
                    #log_conf = config['LOGGING']
                    #log_path = log_conf['LogFilePath']

                    #ES Index Settings to set shards and replicas
                    index_settings = {}
                    index_settings['settings'] = {}

                    for key, val in config.items('ESINDEXBODY'):
                                index_settings['settings'][key] = val
                    #print(index_settings)


                    #ES index details
                    es_index_conf = config['ESINDEXDETAILS']
                    index_name = es_index_conf['IndexName']
                    #index_name = index_name + str(grouping_id) + datetime.now().strftime("%Y%m%d")
                    type_name = es_index_conf['TypeName']
                    type_name = type_name + str(grouping_id)
                    print(type_name)
                    alias_name =  es_index_conf['AliasName']
                    ignore =  int(es_index_conf['Ignore'])
                    nested_index = es_index_conf['NestedIndex']
                    index_id = es_index_conf['IndexFieldId']
                    bulk_push_size = int(es_index_conf['BulkPushSize'])
                    refresh_interval = es_index_conf['RefreshInterval']
                    field_mappings = es_index_conf['IndexFieldMappings']
                    field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
                    field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))

                    print(field_mappings_dict)

                    #ES mapping
                    es_mapping_conf = config['ELASTICTEMPLATE']
                    #mapping_file = es_mapping_conf['MappingFile']
                    #with open('{0}'.format(mapping_file), 'r') as mappingFile:
                            #mappings = mappingFile.read()

                    #print("MAPPINGS")
                    #print(mappings)

                    #Oracle settings
                    db_conf = config['DATABASE']
                    connection_string = db_conf['ConnectionString']
                    object_name = db_conf['ObjectName']
                    where_clause = db_conf['WhereClause']
                    sql_path = db_conf['SqlPath']

                    #logging.basicConfig(level=logging.DEBUG,
                    #            format='%(asctime)s %(levelname)-8s %(message)s',
                    #            datefmt='%a, %d %b %Y %H:%M:%S',
                    #            filename=log_path+datetime.date.strftime(datetime.datetime.today(),"%m%d%Y")+'_get.log',
                    #            filemode='w')

                      # End of all Parameters--------------------------------------------------------------------------------------------------------------------------------------------------------

                    # Connect to Oracle
                    try:
                        print("oracle")
                        start_time = time.time()
                        ora_con = db.Connection(connection_string)

                        ora_cursor = ora_con.cursor()
                        ora_cursor.arraysize = 10000
                        lrc_cursor = ora_con.cursor()

                        #print(select_query)
                        ora_rows=[]
                        ora_cursor.callproc(sql_path,[task_id,'',eog_user_id,source_app, 'N',0, lrc_cursor])
                        ora_rows = lrc_cursor.fetchall()
                        print(ora_rows)

                        ora_count = lrc_cursor.rowcount
                        print("ora_count=" + str(ora_count))
                        if ora_count == 0:
                           exit()
                        es_field_names = [(field_mappings_dict[ora_col_name[0].lower()]) for ora_col_name in lrc_cursor.description]
                        print(es_field_names)
                        lrc_cursor.close()
                        ora_cursor.close()
                        ora_con.close()
                        print("connected")
                    except db.DatabaseError as e:
                        error = e.args
                        error_msg = error.message
                        #logging.critical(error_msg+' '+error_msg)
                        print(e)
                        raise
                        resultlist.append({'traceid':5,'indextype':'Oracle Database Error ','indexname':index_name,'alias_name':alias_name,'message':'Database Error','output':str(e)})

                    #connect to elastic search and index setup-----------------------------------------------------------------
                    #es = Elasticsearch(hosts=host_list,timeout=time_out)
                    es = Elasticsearch(
                        hosts = host_name,#esdatanodes
                        timeout = time_out, # increase timeout from default 10s to 120s
                        http_auth=(user,password),
                        verify_certs=certs,
                        headers = h
                              )
                    print(index_name)
                    print("looking for index")
                    for index in es.indices.get(index_name  + str(grouping_id) + '201' + '*'):
                        print (index)
                    print(index)
                    index_name = index
 
                    ora_df = pd.DataFrame(ora_rows,columns=es_field_names)
                    #print(ora_df)
                    #ora_df['timestamp']=ora_df['updateTs'][0]
                    #print('hello')
                    hdr_list = ['timeStamp','key','taskUuid','taskId','taskName','formUuid','assetId','assetDesc','assetDescShort','assetUuid','barCode','catalogItemId','catalogItemName','categoryId','categoryName','comments','deletedFlag','divisionId','fileCount','formId','formName','formLevelCode','formComments','groupId','groupName','groupMemberId','groupMemberName','propertyId','propertyNb','propertyName','routeId','temporalKey','routeName','serialNumber','startDate','statusCode','statusGroup','status','stockNb','isUsed','groupingId','groupingName','groupingRgbHex','scheduledFrequencyUnit','scheduledFrequencyPeriod','taskDescription','facilityName','divisionName','foremanName','teamName','countyName','stateName','updateWorkerId','updateWorkerName','taskUpdateTs','latlong']
                    attr_list = ['taskId','taskAttributeUuid','formAttributeUuid','attributeId','attributeName','attributeDesc','requiredCd','isActive','attributeGrouping','value','valueListId','valueListEntryDesc','attributeWorkerId','attributeUpdateTs','uiControlCode','attributeWorkerName','sortOrder','maxAttUpdateTs']
                    ora_df = ora_df.replace(np.nan,-99999)
                    df1 = ora_df.groupby(hdr_list,as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
                    df1['attributes']= df1['attributes'].apply(lambda row: replace_value(row))
                    df1=df1.replace(-99999,np.nan)
                    #df1['updateTs']=ora_df['updateTsHdr']
                    #df1['updateWorkerId']=ora_df['updateWorkerIdHdr']
                    #df1['updateWorkerName']=ora_df['updateWorkerNameHdr']
                    hdr_list = ['taskUuid','taskId','taskName','formUuid','assetId','assetDesc','assetDescShort','assetUuid','barCode','catalogItemId','catalogItemName','categoryId','categoryName','comments','deletedFlag','divisionId','fileCount','formId','formName','formLevelCode','formComments','groupId','groupName','groupMemberId','groupMemberName','propertyId','propertyNb','propertyName','routeId','temporalKey','routeName','serialNb','startDate','statusCode','statusGroup','status','stockNb','updateWorkerId','updateWorkerName','taskUpdateTs','isUsed','groupingId','groupingName','groupingRgbHex','scheduledFrequencyUnit','scheduledFrequencyPeriod','taskDescription','facilityName','divisionName','foremanName','teamName','countyName','stateName','latlong','attributes']
                    #df2 = df1.groupby(['key','latlong','assetId','timestamp'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
                    #if df1['latlong'].isnull().values.any():
                    df2 = df1.groupby(['key','taskId','timeStamp'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
                    #else:
                    #df2 = df1.groupby(['key','latlong','taskId','timestamp'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
                    df2=df2.replace(-99999,np.nan)
                    equip_json=df2.to_json(orient='records')
                    print("json")
                    #print(equip_json)
                    json_df=json.loads(equip_json)
                    #print(json_df)
                    json_df[0]


                    if es.indices.exists(index_name):
                        print('Index exists')
                        print("updating index "+ index_name)
                        print("updating type "+ type_name)
                        faclist=[]
                        for doc in json_df:
                            print("updating UUID "+ doc['object']['taskUuid'])
                            #print(doc['object']['comments'])
                            #print(doc['object']['attributes'])
                            action = {"_index":index_name,"_type":type_name,"_id":doc['object']['taskUuid'],"_on_type": "update", "_source": doc}
                            faclist.append(action)
                        #print(faclist)

                        #print(faclist)
                        success, info = helpers.bulk(es, faclist)
                        if success:
                            print("updated")
                        if not success:
                            #print(info)
                            #resultlist.append({'traceid':7,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info})
                            raise RuntimeError('error bulk')

                except Exception as e:
                    print("ERROR")
                    print(e)
                    #logging.critical(error_msg+' '+str(e))
                    #resultlist.append({'traceid':4,'indextype':' ','indexname':index_name,'alias_name':alias_name,'message':'unexpected Error','output':str(e)})




        finally:
            try:
                subject = 'Task ES process'
                print("SUCCESS")
                #if len(resultlist) > 0:
                if 1 > 0:
                   #message = 'Task ES process complete '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")
                   message = 'Task ES process complete '+ str(datetime.now())
                   #email_process.send_email(sender,MIMEText(str(order(pd.DataFrame(resultlist),['traceid','indexname','alias_name','message','output']).to_html(classes='table',index=False,escape=False)),'html'),recipients,subject)
            except Exception as e:
                #message = 'Task ES process complete unexpected Error '+ datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")+str(e)
                message = 'Task ES process complete unexpected Error '+str(datetime.now()) +str(e)
                print(message)
                #logging.critical(error_msg+' '+str(e))
                print(e)
                email_process.send_email(sender,MIMEText(message),recipients,subject)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port= 5007,debug=True)
