SELECT "key",event_type_id, event_type_name, sort_order, regulatory_fl, active_fl, attribute_id, attribute_name, ui_control_style, ui_control_cd,display_format, data_type_cd,attr_active_fl,attribute_grouping, attribute_id_mapping, es_attribute_name
FROM
(
SELECT LISTAGG (attribute_id|| ' AS "'|| LOWER ( SUBSTR (REGEXP_REPLACE(INITCAP(der_attribute_name), '[^0-9A-Za-z]', '') , 1, 1))|| SUBSTR (REGEXP_REPLACE(INITCAP(der_attribute_name), '[^0-9A-Za-z]', ''), 2, 29)|| '" ',',')
             WITHIN GROUP (ORDER BY attribute_id) attribute_id_mapping,
             attribute_id,
             attribute_name,
             LOWER (SUBSTR (REGEXP_REPLACE(INITCAP(der_attribute_name), '[^0-9A-Za-z]', '') , 1, 1))|| SUBSTR (REGEXP_REPLACE(INITCAP(der_attribute_name), '[^0-9A-Za-z]', ''), 2, 29) es_attribute_name,
             event_type_id,
             event_type_name,
             "key",
             sort_order,
             regulatory_fl,
             active_fl,
             ui_control_style,
             ui_control_cd,
             display_format,
             data_type_cd,
             active_fl attr_active_fl,
             attribute_grouping
        FROM (SELECT attribute_id,
                   CASE
                      WHEN cnt > 1 THEN attribute_id || '-' || der_attribute_name
                      ELSE der_attribute_name
                   END
                      der_attribute_name,
                   event_type_id,
                   event_type_name,
                   "key",
                   sort_order,
                   regulatory_fl,
                   active_fl,
                   attribute_name,
                   ui_control_style,
                   ui_control_cd,
                   display_format,
                   data_type_cd,
                   active_fl attr_active_fl,
                   attribute_grouping
              FROM (SELECT ma.attribute_id,
                       COUNT (*) OVER (PARTITION BY met.event_type_id,CASE WHEN LENGTH (REGEXP_REPLACE(ma.attribute_name, '[^0-9A-Za-z]', '')) > 30 THEN LOWER(SUBSTR (REGEXP_REPLACE(ma.attribute_name, '[^0-9A-Za-z]', ''), -30, 30))ELSE LOWER(REGEXP_REPLACE(ma.attribute_name, '[^0-9A-Za-z]', '')) END)cnt,
                       CASE WHEN LENGTH (REGEXP_REPLACE(ma.attribute_name, '[^0-9A-Za-z]', '')) > 30 THEN SUBSTR (REGEXP_REPLACE(ma.attribute_name, '[^0-9A-Za-z]', ''), -30, 30) ELSE ma.attribute_name END der_attribute_name,
                       met.event_type_id,
                       met.event_type_name,
                       ma.attribute_name actual_attr_name,
                       met.event_type_id||'-'||ma.attribute_id "key",
                       met.sort_order,
                       met.regulatory_fl,
                       met.active_fl,
                       ma.attribute_name,
                       ma.ui_control_style,
                       ma.ui_control_cd,
                       ma.display_format,
                       ma.data_type_cd,
                       meta.active_fl attr_active_fl,
                       meta.attribute_grouping
                      FROM ma_dba.ma_event_type met,
                           ma_dba.ma_attribute ma,
                           ma_dba.ma_event_type_attribute meta
                     WHERE met.event_type_id = meta.event_type_id
                           AND meta.attribute_id = ma.attribute_id))
                           group by attribute_id,attribute_name,der_attribute_name,event_type_id,
                   event_type_name,
                   "key",sort_order,regulatory_fl,active_fl,attribute_name,ui_control_style,ui_control_cd,display_format,data_type_cd,attr_active_fl,attribute_grouping
                   UNION ALL
                   SELECT (attribute_id|| ' AS "'|| LOWER ( SUBSTR (REGEXP_REPLACE(INITCAP(attribute_name), '[^0-9A-Za-z]', '') , 1, 1))|| SUBSTR (REGEXP_REPLACE(INITCAP(attribute_name), '[^0-9A-Za-z]', ''), 2, 29)|| '" ') attribute_id_mapping,
                   attribute_id,
             attribute_name,
             es_attribute_name,
             NULL event_type_id,
             'Event Hdr Attributes' event_type_name,
             to_char(attribute_id) "key",
             NULL sort_order,
             NULL regulatory_fl,
             NULL active_fl,
             NULL ui_control_style,
             NULL ui_control_cd,
             NULL display_format,
             CASE WHEN attribute_name IN ('update_ts','creation_ts','start_dt') THEN 'Date' 
	          WHEN attribute_name IN ('asset_id','assigned_worker_id','route_id','property_nb','division_id','stock_nb','category_id','item_id','assigned_group_id') THEN 'Number' ELSE NULL END data_type_cd,
             NULL attr_active_fl,
             'Event Headers' attribute_grouping
                   FROM ma_dba.ma_task_hdr_attribute)
