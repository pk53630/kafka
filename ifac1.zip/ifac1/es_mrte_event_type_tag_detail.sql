SELECT tag_id "key",
       tag_id,
       RAWTOHEX(form_guid) "form_guid",
       is_header_attribute,
       es_header_attribute,
       attribute_id,
       date_format
FROM mrte_dba.mrte_event_type_tag_detail

