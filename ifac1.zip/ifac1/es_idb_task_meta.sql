SELECT met.event_type_id||'-'||mg.grouping_id||'-'||metg.group_id||'-'||meta.attribute_id key, 
       met.event_type_id,
       met.event_type_name,
       met.active_fl event_type_active_fl,
       met.event_type_level,
       met.regulatory_fl,
       met.iemissions_fl,
       mg.grouping_id,
       mg.grouping_name,
       metg.group_id,
       ma.group_name,
       meta.attribute_id,
       maa.attribute_name,
       meta.active_fl attribute_active_fl,
       meta.attribute_grouping 
  FROM ma_dba.ma_event_type met,
       ma_dba.ma_grouping mg,
       ma_dba.ma_group ma,
       ma_dba.ma_event_type_group metg,
       ma_dba.ma_attribute maa,
       ma_dba.ma_event_type_attribute meta
 WHERE     met.grouping_id = mg.grouping_id
       AND met.event_type_id = metg.event_type_id
       AND metg.group_id = ma.group_id
       AND met.event_type_id = meta.event_type_id
       AND meta.attribute_id = maa.attribute_id