SELECT division_id||'-'||trend_id "key"
       , division_id
       , trend_id
       , trend
FROM ( SELECT distinct division_id
              , trend_id
              , trend
       FROM odm_info.odm_well
      )