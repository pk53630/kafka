def order(frame,var):
    varlist =[w for w in frame.columns if w not in var]
    frame = frame[var+varlist]
    return frame

def es_results(res,trace_id,index_type):
    for key,value in res.items():
        if key == 'acknowledged':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           return 'Success'
        elif key == 'error':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           #print(value)
           return 'Error'
        elif key == 'status':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})

def replace_value(row):
    new_row=[]
    for i in row:
        for key,value in i.items():
            if value ==-99999:
                i[key]=np.nan
    return row



import sys
import configparser
import cx_Oracle as db
import os, time, smtplib, socket, datetime
from email.mime.text import MIMEText
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import pandas as pd
import numpy as np
import json
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
# sys.path.append(r"C:\Users\rtati\Documents\python_files")
import email_process

from flask import Flask
from flask_restplus import Api, Resource, fields, reqparse, marshal

app = Flask(__name__)
api = Api(app, version='1.0', title='iFacilities Item Services',
    description='iFacilities Item Services',
)


@api.route('/iFacItem/<string:configFile>/<int:division_id>/<int:item_id>/<int:facility_id>/<int:eog_user_id>')
class ElasticSync(Resource):
  # @api.marshal_with(responseBody)
  def get(self, configFile, division_id, item_id, facility_id, eog_user_id):

   try:
            pd.options.display.max_colwidth = 1000
            # All Parameters--------------------------------------------------------------------------------------------------------------------
                #print(sys.argv[0])
                #configfilename = 'es_ifac_item.ini'
                #print(sys.argv[1])
                #division_id = 10
                #print(sys.argv[2])
            configfilename = configFile#sys.argv[1]
            division_id = division_id# sys.argv[2]
            item_id = item_id
            facility_id = facility_id
            eog_user_id = eog_user_id


            es_index_list = [configfilename]
            resultlist =[]


            sender = 'radhika_tati@eogresources.com'
            recipients = 'radhika_tati@eogresources.com'

            subject = 'item ES Process'

            for configfilename in es_index_list:
                    try:
                        config = configparser.ConfigParser()
                        config.read(configfilename)

                        #ES email
                        es_email_conf = config['EMAIL']
                        sender = es_email_conf['EmailFrom']
                        recipients = es_email_conf['EmailTo']

                        #Elastic Search
                        elastic_conf = config['ELASTICSEARCH']
                        cluster_name = elastic_conf['ClusterName']
                        time_out = int(elastic_conf['TimeOut'])
                        host_list = elastic_conf['HostList']
                        host_list = host_list.replace("\n", "")
                        host_list = host_list.split(',')



                        #ES Index Settings to set shards and replicas

                        es_index_body = config['ESINDEXBODY']
                        shards= es_index_body['number_of_shards']
                        replicas= es_index_body['number_of_replicas']
                        #print(index_settings)


                        #ES index details
                        es_index_conf = config['ESINDEXDETAILS']
                        index_name = es_index_conf['IndexName']
                        type_name = es_index_conf['TypeName']
                        alias_name =  es_index_conf['AliasName']
                        ignore =  int(es_index_conf['Ignore'])
                        nested_index = es_index_conf['NestedIndex']
                        index_id = es_index_conf['IndexFieldId']
                        bulk_push_size = int(es_index_conf['BulkPushSize'])
                        refresh_interval = es_index_conf['RefreshInterval']
                        field_mappings = es_index_conf['IndexFieldMappings']
                        field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
                        field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))

                        #print(field_mappings_dict)

                        #ES mapping
                        es_mapping_conf = config['ELASTICTEMPLATE']
                        mapping_file = es_mapping_conf['MappingFile']
                        with open('{0}'.format(mapping_file), 'r') as mappingFile:
                                mappings = mappingFile.read()



                        #Oracle settings
                        db_conf = config['DATABASE']
                        connection_string = db_conf['ConnectionString']
                        sql_path = db_conf['SqlPath']

                        # End of all Parameters--------------------------------------------------------------------------------------------------------------------------------------------------------

                        # Connect to Oracle
                        try:
                            start_time = time.time()
                            ora_con = db.Connection(connection_string)
                            ora_cursor = ora_con.cursor()
                            ora_cursor.arraysize = 10000
                            lrc_cursor = ora_con.cursor()



                            ora_rows=[]
                            ora_cursor.callproc(sql_path,[division_id,facility_id,item_id,eog_user_id,lrc_cursor])
                            ora_rows = lrc_cursor.fetchall()
                            #print(ora_rows)

                            ora_count = lrc_cursor.rowcount
                            #print(ora_count)

                            es_field_names = [(field_mappings_dict[ora_col_name[0]]) for ora_col_name in lrc_cursor.description]
                            lrc_cursor.close()
                            ora_cursor.close()
                            ora_con.close()
                        except db.DatabaseError as e:
                            #error = e.args
                            #error_msg = error.message
                            #print(e)
                            raise
                            resultlist.append({'traceid':5,'indextype':'Oracle Database Error ','indexname':index_name,'alias_name':alias_name,'message':'Database Error','output':str(e)})

                        #connect to elastic search and index setup-----------------------------------------------------------------
                        es = Elasticsearch(hosts=host_list,timeout=time_out)

                        ora_df = pd.DataFrame(ora_rows,columns=es_field_names)
                        print(ora_df)
                        #print(ora_df.head())
                        ora_df['timestamp']=ora_df['updateTs']
                        hdr_list = ['timestamp','key','divisionId','itemGuid','itemId','itemDesc','categoryId','categoryName','propertyId','assignmentUuid','propertyNumber','propertySub','propertyName','propertyType','divisionName','stockNumber','selectableFl','primoDesc','activeFl','comments','stockNbApprovedFl','allocateableFl','controllableFl','genericFl','startDate','endDate','trend','stateCd','stateName','countyName','fieldName','latitude','longitude','playId','playName','rigId','rigName','subDivisionId','subDivisionName','teamId','teamName','blueWellFl','ecEntityColor','formationNm','operatedFl','operatorName','originationType','phaseName','subphaseName','routeName','foremanName','updateTs','updateUserId','userName','assocWellId','assocFacilityId','assocUnitFacilityId','wellName','systemId','systemName','latlong','joints','acctQuantity','acctJoints','verifiedStatusCd','categoryShortName','pendingTransaction','propertyLatitude','propertyLongitude','sendToMaterials','hasJoints','quantity']
                        attr_list = ['divisionId','facilityId','itemId','categoryId','categoryName','startDate','propertyId','propertyName','attributeId','attributeName','attributeLevel','attributeGrouping','uiControlCode','sortOrder','isOverridable','valueListId','isActive','itemNumberValue','itemDateValue','itemShortTextValue','itemLongTextValue','itemValueListEntryId','itemValueListEntryDesc','updateTs','updateUserId','userName']
                        ora_df = ora_df.replace(np.nan,-99999)
                        df1 = ora_df.groupby(hdr_list, as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
                        df1=df1.replace(-99999,np.nan)
                        
                        if df1['attributes'].isnull().values.any():
                            pass
                        else:
                            #print(df1.attributes)
                            df1['attributes']= df1['attributes'].apply(lambda row: replace_value(row))
                        hdr_list = ['divisionId','itemGuid','itemId','itemDesc','categoryId','categoryName','propertyId','assignmentUuid','propertyNumber','propertySub','propertyName','propertyType','divisionName','stockNumber','selectableFl','primoDesc','activeFl','comments','stockNbApprovedFl','allocateableFl','controllableFl','genericFl','startDate','endDate','trend','stateCd','stateName','countyName','fieldName','latitude','longitude','playId','playName','rigId','rigName','subDivisionId','subDivisionName','teamId','teamName','blueWellFl','ecEntityColor','formationNm','operatedFl','operatorName','originationType','phaseName','subphaseName','routeName','foremanName','updateTs','updateUserId','userName','assocWellId','assocFacilityId','assocUnitFacilityId','wellName','systemId','systemName','latlong','joints','acctQuantity','acctJoints','verifiedStatusCd','categoryShortName','pendingTransaction','propertyLatitude','propertyLongitude','sendToMaterials','hasJoints','quantity','attributes']
                        
                        if df1['latlong'].isnull().values.any():
                            df2 = df1.groupby(['key','itemId','timestamp'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
                        else:
                            df2 = df1.groupby(['key','latlong','itemId','timestamp'], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')[0]).reset_index().rename(columns={0:'object'})
                        #print(df2.head())
                        equip_json=df2.to_json(orient='records')
                        json_df=json.loads(equip_json)
                        json_df[0]

                        if es.indices.exists(index_name):
                            print('Index eixsts')
                            faclist=[]
                            for doc in json_df:
                                action = {"_index":index_name,"_type":type_name,"_id":doc['key'],"_on_type": "update", "_source": doc}
                                faclist.append(action)
                            success, info = helpers.bulk(es, faclist)
                            if not success:
                                #print(info)
                                resultlist.append({'traceid':7,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info})
                                raise RuntimeError('error bulk')
                        else:
                             print('Create Index')
                             es.indices.create(index=index_name, ignore=400, body={"number_of_shards":shards,"number_of_replicas":replicas})
                             es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
                             es.indices.put_settings(index=index_name, body={"index": {"refresh_interval":refresh_interval}})
                             faclist=[]
                             for doc in json_df:
                                action = {"_index":index_name,"_type":type_name,"_id":doc['key'],"_on_type": "update", "_source": doc}
                                faclist.append(action)
                             success, info = helpers.bulk(es, faclist)
                             if not success:
                                #print(info)
                                resultlist.append({'traceid':7,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info})
                                raise RuntimeError('error bulk')
                    except Exception as e:
                        print(e)
                        resultlist.append({'traceid':4,'indextype':' ','indexname':index_name,'alias_name':alias_name,'message':'unexpected Error','output':str(e)})




   finally:
            try:
                subject = 'Item ES process'
                if len(resultlist) > 0:
                   message = 'Item ES process complete '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")
                   email_process.send_email(sender,MIMEText(str(order(pd.DataFrame(resultlist),['traceid','indexname','alias_name','message','output']).to_html(classes='table',index=False,escape=False)),'html'),recipients,subject)
            except Exception as e:
                message = 'EquipmItement ES process complete unexpected Error '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")+str(e)
                print(e)
                email_process.send_email(sender,MIMEText(message),recipients,subject)

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5008,debug=True)
