﻿#!/usr/local/bin/python3
def order(frame,var):
    varlist =[w for w in frame.columns if w not in var]
    frame = frame[var+varlist]
    return frame

def generate_actions(rows,index_name,type_name,index_field_id):
    for ora_row in rows:
        data_dict = {}
        data_dict = dict(zip(es_field_names, ora_row))
        yield {
                '_index': index_name,
                '_type': type_name,
                '_id': data_dict[index_field_id],
                '_source': data_dict
            }

def generate_actions_nested(rows,index_name,type_name,index_field_id):
    for doc in rows:
        #data_dict = {}
        #data_dict = dict(zip(es_field_names, ora_row))
        yield {
                '_index': index_name,
                '_type': type_name,
                '_id': doc[index_field_id],
                '_source': doc
            }


def es_results(res,trace_id,index_type):
    for key,value in res.items():
        if key == 'acknowledged':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           return 'Success'
        elif key == 'error':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})
           print(value)
           return 'Error'
        elif key == 'status':
           resultlist.append({'traceid':trace_id,'indextype':index_type,'indexname':index_name,'alias_name':alias_name,'message':key,'output':value})


try:
    import sys
    import configparser
    import cx_Oracle as db
    import os, time, smtplib, socket, datetime
    from email.mime.text import MIMEText
    from elasticsearch import Elasticsearch
    from elasticsearch import helpers
    import pandas as pd
    from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
    sys.path.append(r"C:\Users\rtati\Documents\python_files")
    import email_process

    pd.options.display.max_colwidth = 1000

    # All Parameters--------------------------------------------------------------------------------------------------------------------
    print(sys.argv[0])
    configfilename = sys.argv[1]
    print(sys.argv[1])
    complete_load = sys.argv[2]
    print(sys.argv[2])
    request_id = sys.argv[3]
    print(sys.argv[3])

    if configfilename is not None:
        es_index_list = [configfilename]
    elif request_id is not None:
        es_index_list = []
    elif configfilename is None:
        es_index_list = []

    resultlist=[]
    sender = 'radhika_tati@eogresources.com'
    recipients = 'radhika_tati@eogresources.com'

    subject = 'ES Process'

    for configfilename in es_index_list:
        try:
            config = configparser.ConfigParser()
            config.read(configfilename)

            #ES email
            es_email_conf = config['EMAIL']
            sender = es_email_conf['EmailFrom']
            recipients = es_email_conf['EmailTo']

            #Elastic Search
            elastic_conf = config['ELASTICSEARCH']
            cluster_name = elastic_conf['ClusterName']
            time_out = int(elastic_conf['TimeOut'])
            host_list = elastic_conf['HostList']
            host_list = host_list.replace("\n", "")
            host_list = host_list.split(',')



            #ES Index Settings to set shards and replicas
            index_settings = {}
            index_settings['settings'] = {}
  
            for key, val in config.items('ESINDEXBODY'):
                        index_settings['settings'][key] = val
            print(index_settings)


            #ES index details
            es_index_conf = config['ESINDEXDETAILS']
            index_name = es_index_conf['IndexName']
            type_name = es_index_conf['TypeName']
            alias_name =  es_index_conf['AliasName']
            ignore =  int(es_index_conf['Ignore'])
            nested_index = es_index_conf['NestedIndex']
            index_id = es_index_conf['IndexFieldId']
            bulk_push_size = int(es_index_conf['BulkPushSize'])
            refresh_interval = es_index_conf['RefreshInterval']
            print(refresh_interval)
            field_mappings = es_index_conf['IndexFieldMappings']
            print(field_mappings)
            field_mappings = field_mappings.replace("\n", "").replace("<", "").replace(">", "")
            print(field_mappings)
            field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))

            print(field_mappings_dict)

            #ES mapping
            es_mapping_conf = config['ELASTICTEMPLATE']
            mapping_file = es_mapping_conf['MappingFile']
            with open('{0}'.format(mapping_file), 'r') as mappingFile:
                    mappings = mappingFile.read()



            #Oracle settings
            db_conf = config['DATABASE']
            connection_string = db_conf['ConnectionString']
            object_name = db_conf['ObjectName']
            where_clause = db_conf['WhereClause']
            sql_path = db_conf['SqlPath']

            
            # End of all Parameters--------------------------------------------------------------------------------------------------------------------------------------------------------

            # Connect to Oracle 
            try:
                start_time = time.time()
                ora_con = db.Connection(connection_string)
                ora_cursor = ora_con.cursor()
                ora_cursor.arraysize = 10000
                
                with open('{0}'.format(sql_path), 'r') as sqlFile:
                      ora_sql = sqlFile.read()

                if complete_load == 'Y':
                    where_clause = ""
                    index_name =  datetime.datetime.now().strftime('{0}_%H_%M_%d_%m_%Y'.format(alias_name))
                elif complete_load == 'N' and request_id is not None:
                    where_clause = 'and request_id = '+request_id

                select_query = ora_sql +' '+ where_clause

                print(select_query)

                ora_rows=[]               
                ora_cursor.execute(select_query)
                ora_rows = ora_cursor.fetchall()
                #print(ora_rows)

                ora_count = ora_cursor.rowcount
                print(ora_count)
                print(ora_cursor.description)
                es_field_names = [(field_mappings_dict[ora_col_name[0].lower()]) for ora_col_name in ora_cursor.description]

                ora_cursor.close()
                ora_con.close()
            except db.DatabaseError as e:
                #error = e.args
                #error_msg = error.message
                print(e)
                raise
                resultlist.append({'traceid':5,'indextype':'Oracle Database Error ','indexname':index_name,'alias_name':alias_name,'message':'Database Error','output':str(e)})





            #connect to elastic search and index setup-----------------------------------------------------------------
            es = Elasticsearch(hosts=host_list,timeout=time_out)
            # request body
            request_body= index_settings

            start_time=time.time()
            # Check if the index doesnot exist and create
            if not es.indices.exists(index_name):
                res = es.indices.create(index= index_name, body=request_body)
                print(res)
                output=es_results(res,1,'index create')
                if output=='Error':
                    raise
                print("Index created")
                print ("Time taken to create ES Index : %s seconds " % (time.time() - start_time))

           
            res=es.indices.put_settings({"index": {"refresh_interval": -1}}, index=index_name)
            output=es_results(res,2,'index settings')
            if output=='Error':
                raise
            res=es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=ignore)
            print(res)
            output=es_results(res,3,'index mapping')
            if output=='Error':
               raise
            #-------------------------------------------------------------------------------------------------------------

            if nested_index=='NO':
                if ora_count>0:
                    if ora_count < bulk_push_size:
                        bulk_data=[]
                        
                        #generate documents
                        for ora_row in ora_rows:
                            data_dict = {}
                            data_dict = dict(zip(es_field_names, ora_row))
                            action = {
                                    '_index': index_name,
                                    '_type': type_name,
                                    '_id': data_dict[index_id],
                                    '_source': data_dict
                                    }

                            bulk_data.append(action)
                        print(bulk_data)
                        success, info = helpers.bulk(es, bulk_data)
                        if not success:
                            print(info)
                            resultlist.append({'traceid':7,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info}) 
                            raise RuntimeError('error bulk')
                    else:
                        for success, info in helpers.parallel_bulk(es, generate_actions(ora_rows,index_name,type_name,index_id), thread_count=5, chunk_size=bulk_push_size):
                            if not success:
                               resultlist.append({'traceid':6,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info}) 
                               raise RuntimeError('error parallel bulk')
                    res=es.indices.refresh(index=index_name)
                    output=es_results(res,8,'refresh index')
                    if output=='Error':
                       raise
                    print(alias_name)
                    res=es.indices.put_alias(index=index_name, name=alias_name, ignore=ignore)
                    output=es_results(res,9,'index alias')
                    if output=='Error':
                       raise
                    res=es.indices.put_settings({"index": {"refresh_interval": refresh_interval}}, index=index_name)
                    output=es_results(res,10,'index settings')
                    if output=='Error':
                       raise
                    print(es.count(index=index_name))
                    print ("Time taken to index data : %s seconds " % (time.time() - start_time))

                    indices = list(es.indices.get_alias(alias_name, ignore=[400,404]))
                    print(indices)
                    if complete_load == 'Y':
                        for idx in indices:
                            print(" the index is ",idx)
                            
                            if index_name != idx:
                               #print("The index that need to be deleted are:",idx)
                               es.indices.delete(idx, ignore = 404)
                               print("Deleted the index ", idx)

                            es.indices.put_alias(index=index_name, name=alias_name, ignore=400)

                     
                            idx_count=es.count(index=index_name)['count']
                            if ora_count != idx_count:
                               info="Count Mismatch between Oracle Rows %s" %ora_count + " and Index Documents %s" %idx_count
                               resultlist.append({'traceid':10,'indextype':'count mismatch ','indexname':index_name,'message':info,'output':idx_count}) 
                               raise RuntimeError('error record count')


            elif nested_index=='YES':
                if ora_count>0:
                    if ora_count < bulk_push_size:
                        ora_df = pd.DataFrame(ora_rows,columns=es_field_names)
                        print(ora_df)
                        if not hdr_list:
                            attr_df = ora_df.groupby([key], as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
                            attr_df[key_list] = ora_df.reindex(index=final_df.index,columns=key_list)
                            final_df = attr_df[key_list,'attributes']
                        else:
                            attr_df = ora_df.groupby([key], as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
                            obj_df=ora_df.groupby([key], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')).reset_index().rename(columns={0:'object'})
                            final_df=ora_df[key_list]+attr_df['attributes']+obj_df['object']
                       
                        if es.indices.exists(index_name):
                            print('Index eixsts')
                            doclist=[]
                            for doc in final_df:
                                action = {"_index":index_name,"_type":type_name,"-id":doc[key],"_on_type": "update", "_source": doc }
                                doclist.append(action)
                            print(doclist)
                            success, info = helpers.bulk(es, doclist)
                            if not success:
                                print(info)
                                resultlist.append({'traceid':11,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info}) 
                                raise RuntimeError('error bulk')
                    else:
                        ora_df = pd.DataFrame(ora_rows,columns=es_field_names)
                        print(ora_df)
                        if not hdr_list:
                            attr_df = ora_df.groupby([key], as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
                            attr_df[key_list] = ora_df.reindex(index=final_df.index,columns=key_list)
                            final_df = attr_df[key_list,'attributes']
                        else:
                            attr_df = ora_df.groupby([key], as_index=False).apply(lambda x: x[attr_list].to_dict('r')).reset_index().rename(columns={0:'attributes'})
                            obj_df=ora_df.groupby([key], as_index=False).apply(lambda x: x[hdr_list].to_dict('r')).reset_index().rename(columns={0:'object'})
                            final_df=ora_df[key_list]+attr_df['attributes']+obj_df['object']
                        for success, info in helpers.parallel_bulk(es, generate_actions_nested(final_df,index_name,type_name,index_id), thread_count=5, chunk_size=bulk_push_size):
                            if not success:
                               resultlist.append({'traceid':12,'indextype':'helpers parallel bulk ','indexname':index_name,'alias_name':alias_name,'message':info,'output':info}) 
                               raise RuntimeError('error parallel bulk')
                    res=es.indices.refresh(index=index_name)
                    output=es_results(res,13,'refresh index')
                    if output=='Error':
                       raise
                    print(alias_name)
                    res=es.indices.put_alias(index=index_name, name=alias_name, ignore=ignore)
                    output=es_results(res,14,'index alias')
                    if output=='Error':
                       raise
                    res=es.indices.put_settings({"index": {"refresh_interval": refresh_interval}}, index=index_name)
                    output=es_results(res,15,'index settings')
                    if output=='Error':
                       raise
                    print(es.count(index=index_name))
                    print ("Time taken to index data : %s seconds " % (time.time() - start_time))

                    indices = list(es.indices.get_alias(alias_name, ignore=[400,404]))
                    print(indices)
                    if complete_load == 'Y':
                        for idx in indices:
                            print(" the index is ",idx)
                            
                            if index_name != idx:
                               #print("The index that need to be deleted are:",idx)
                               es.indices.delete(idx, ignore = 404)
                               print("Deleted the index ", idx)

                            es.indices.put_alias(index=index_name, name=alias_name, ignore=400)

                     
                            idx_count=es.count(index=index_name)['count']
                            if ora_count != idx_count:
                               info="Count Mismatch between Oracle Rows %s" %ora_count + " and Index Documents %s" %idx_count
                               resultlist.append({'traceid':16,'indextype':'count mismatch ','indexname':index_name,'message':info,'output':idx_count}) 
                               raise RuntimeError('error record count')
                
        except RuntimeError as e:
             pass
        except Exception as e:
            print(e)
            resultlist.append({'traceid':4,'indextype':' ','indexname':index_name,'alias_name':alias_name,'message':'unexpected Error','output':str(e)})
            



finally:
    try:
        subject = 'ES process'
        if len(resultlist) > 0:
           message = 'ES process complete '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")
           email_process.send_email(sender,MIMEText(str(order(pd.DataFrame(resultlist),['traceid','indexname','alias_name','message','output']).to_html(classes='table',index=False,escape=False)),'html'),recipients,subject)
    except Exception as e:
        message = 'ES process complete unexpected Error '+datetime.date.strftime(datetime.datetime.today(),"%m-%d-%Y %H:%M:%S")+str(e)
        print(e)
        email_process.send_email(sender,MIMEText(message),recipients,subject)
