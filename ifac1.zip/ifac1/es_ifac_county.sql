SELECT frv.ref_value_id "key", frv.ref_value_id  "county_id", frv.ref_value "county_name"
FROM  fdm_dba.fdm_ref_value frv, fdm_dba.fdm_ref_value_type frvt 
WHERE frvt.ref_value_type_id = 109
AND frvt.ref_value_type_id = frv.ref_value_type_id
AND TRIM(frv.ref_value) IS NOT NULL
