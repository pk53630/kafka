#!/bin/sh

chk_file_cnt=`ls -l /home/odmbatch/iFluid/data/*.csv|wc -l`

if [ $chk_file_cnt > 0 ]
then
    echo "File found."
#    python3 /home/odmbatch/iFluid/Scripts/iFulid_test.py
    python3 /home/odmbatch/iFluid/Scripts/iFluid_echometer_fluid_survey.py
else
    echo "File not found."
fi
