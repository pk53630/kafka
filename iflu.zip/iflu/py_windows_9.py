#!/usr/bin/python3
import csv
import sys
import shutil
import glob
import os
import arrow
import gzip
import cx_Oracle
import datetime
import pandas as pd

path = '/home/odmbatch/iFluid/data/*.csv'
archived_path='/home/odmbatch/iFluid/archive/' 
files=glob.glob(path)

qry_dt=""" SELECT sysdate from dual"""
qry_cnt="""SELECT count(*) FROM ODM_INFO.ODM_COMPLETION WHERE PRIMO_PRPRTY ="""
query=""" SELECT distinct Division_ID FROM ODM_INFO.ODM_COMPLETION WHERE PRIMO_PRPRTY ="""
#connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE """
connection = cx_Oracle.connect('iprod_dba/Test_123@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)


for file in files: 
    #print(file)
    
    df1 = pd.read_csv(file,sep=',',encoding="ISO-8859-1")
    df2 = df1.dropna(subset=['Well ID'])
    df3 = df2.iloc[:,[0,1,2,3,4,8,24,25,26,27,31,32,33,35,36,39,41,44,50,51,60,61,62,63,126,128,166,220,224,225,227,240,241,245,252,253,257,260,269,270,271,272,278,279,283,293,298,300,306,307,310,318,330,333,336,338,341,343,346]]
    df3=df3.fillna('XXXXXXXXXX')
    #print(df3.shape)
    rows = [list(x) for x in df3.values]
    print(len(rows))
    final_lst=[]

    for i in range(0,len(rows)):
        #print(len(rows[i]))
        if (rows[i][51] == 74320):
            print(i)
            print(rows[i])
            #del rows[i]
   


    del rows[31]
    print(len(rows))

cursor.close()
connection.close()

