#!/usr/bin/python3
import csv
import sys
import shutil
import glob
import os
import arrow
import gzip
import cx_Oracle
import datetime
import pandas as pd
import email
import email.utils
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from os.path import basename
import email.mime.application

dt=arrow.now().format('YYYYMMDD')
path = '/home/odmbatch/iFluid/data/*.csv'
archived_path='/home/odmbatch/iFluid/archive/' 
files=glob.glob(path)

qry_dt=""" SELECT sysdate from dual"""
qry_cnt="""SELECT count(*) FROM ODM_INFO.ODM_COMPLETION WHERE PRIMO_PRPRTY ="""
query=""" SELECT distinct Division_ID FROM ODM_INFO.ODM_COMPLETION WHERE PRIMO_PRPRTY ="""
#connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE """
connection = cx_Oracle.connect('iprod_dba/Test_123@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)


for file in files: 
    #print(file)
    filename_w_ext = os.path.basename(file)
    nan_rows_invalid=archived_path+"NULL_WELL_ID_"+filename_w_ext
    df1 = pd.read_csv(file,sep=',',encoding="ISO-8859-1")
    nan_rows = df1[df1['Well ID'].isnull()]
    print(nan_rows.shape[0])
    invalid_well_id=[] 
    for index, row in df1.iterrows():
        if(row["Well ID"] > 0):
            cursor.execute(qry_cnt+str(row["Well ID"]))
            rowi = cursor.fetchone()
            DIVISION_ID = rowi[0]
            if(DIVISION_ID == 0):
                invalid_well_id.append(row['Well ID'])
                
    print(invalid_well_id)
    print(len(invalid_well_id))
    
    if(len(invalid_well_id) > 0 or nan_rows.shape[0] >0):
        with open(nan_rows_invalid, 'a+') as f:
            nan_rows.to_csv(f, header=True)
   
        print(os.path.basename(file).split('.')[0])
        print(os.path.splitext(nan_rows_invalid)[0])
 
        in_data = open(nan_rows_invalid, "rb").read()
        out_gz = nan_rows_invalid+".gz"
        gzf = gzip.open(out_gz, "wb")
        gzf.write(in_data)
        gzf.close()		
    
        gzip_filename_w_ext = os.path.basename(out_gz)
		
        #html to include in the body section
        html = "Hi Team,\n\nThis is is zipped file list of NULL WELL ID\n\n Filename:"+gzip_filename_w_ext+"\n\n DivisionID is not mapped to WELL ID in ODM_INFO.ODM_COMPLETION for PRIMO_PRPRTY of "+str(invalid_well_id)+"\n\n\n Regards,\nFDM TEAM"
 
        # Creating message.
        msg = MIMEMultipart('alternative')
        msg['Subject'] = """Zip file report """+gzip_filename_w_ext+""" on """+dt
        msg['From'] = "Praveen_Kshirsagaray@eogresources.com"
        msg['To'] = "Praveen_Kshirsagaray@eogresources.com"
 
        # The MIME types for text/html
        HTML_Contents = MIMEText(html, 'text')
 
        # Adding pptx file attachment
        filename=out_gz
        fo=open(filename,'rb')
        attach = email.mime.application.MIMEApplication(fo.read(),_subtype="gzip")
        fo.close()
        attach.add_header('Content-Disposition','attachment',filename=gzip_filename_w_ext)
 
        # Attachment and HTML to body message.
        msg.attach(attach)
        msg.attach(HTML_Contents)
 
 
        # Your SMTP server information
        s_information = smtplib.SMTP()

        s_information.connect('smtp.eogresources.com')

        s_information.sendmail(msg['From'], msg['To'], msg.as_string())
        s_information.quit()
		
		
		
		
#print(nan_rows)



cursor.close()
connection.close()


