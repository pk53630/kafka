#!/usr/local/bin/python3
import sys



es_field_names = [
        'assetId',
        'assignmentUuid',
        'equipmentUuid',
        'barcode',
        'categoryId',
        'categoryName',
        'catalogItemId',
        'catalogItemDesc',
        'assetDesc',
        'conditionCode',
        'latitude',
        'longitude',
        'categoryNameShort',
        'assetDescShort',
        'divisionId',
        'divisionName',
        'propertyId',
        'propertyName',
        'propertyNumber',
        'propertySub',
        'propertyLatitude',
        'propertyLongitude',
        'propertyTypeCode',
        'isPropertyFavorite',
        'routeName',
        'countyName',
        'countyCode',
        'stockNumber',
        'serialNumber',
        'serialNumber2',
        'quantity',
        'joints',
        'sendToMaterials',
        'operationalStatusCode',
        'verifiedStatusCode',
        'verifiedStatusDate',
        'hasPendingTransaction',
        'hasJoints',
        'missingGhgAttribute',
        'startDate',
        'parentDesc',
        'parentAssetId',
        'parentDescOrCategoryName',
        'categoryScope',
        'tasks'
        ]




mappings = '''
    {
        "mappings":
		{
            "equipmenttest":
			{
                "transform": [
                    {
                        "inline": "ctx._source.location = [ctx._source.longitude,ctx._source.latitude];"
                    },
                    {
                        "inline": "ctx._source.assetDescWithStockNumber = ctx._source.assetDesc + ' Stock # ' + ctx._source.stockNumber;"
                    },
                    {
                        "inline": "if (ctx._source.routeName == null) { ctx._source.routeNameRaw = '** Not Specified **';} else { ctx._source.routeNameRaw = ctx._source.routeName};"
                    },
                    {
                        "inline": "ctx._source.location = [ctx._source.longitude,ctx._source.latitude];"
                    },
                    {
                        "inline": "ctx._source.assetDescWithStockNumber = ctx._source.assetDesc + ' Stock # ' + ctx._source.stockNumber;"
                    },
                    {
                        "inline": "if (ctx._source.routeName == null) { ctx._source.routeNameRaw = '** Not Specified **';} else { ctx._source.routeNameRaw = ctx._source.routeName};"
                    }
                ],
                "dynamic_templates": [
                    {
                        "string_fields": {
                            "mapping": {
                                "index": "analyzed",
                                "omit_norms": "true",
                                "fields": {
                                    "raw": {
                                        "ignore_above": "256",
                                        "index": "not_analyzed",
                                        "type": "string"
                                    }
                                },
                                "type": "string"
                            },
                            "match": "*",
                            "match_mapping_type": "string"
                        }
                    }
                ],
                "properties": {
                    "assignmentUuid": {
                        "type": "string",
                        "index": "not_analyzed"
                    },
					"equipmentUuid": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"assetId": {
                        "type": "long"
                    },
                    "barcode": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
                    "categoryId": {
                        "type": "long"
                    },
                    "categoryName": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
                    "catalogItemId": {
                        "type": "long"
                    },
					"catalogItemDesc": {
                        "type": "string",
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        },
                        "analyzer": "desc_analyzer"
                    },
					"assetDesc": {
                        "type": "string",
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        },
                        "analyzer": "desc_analyzer"
                    },
					"conditionCode": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"latitude": {
                        "type": "double"
                    },
                    "longitude": {
                        "type": "double"
                    },
					"location": {
                        "type": "double"
                    },
					"categoryNameShort": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"assetDescShort": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"divisionId": {
                        "type": "long"
                    },
                    "divisionName": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"propertyId": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"propertyName": {
                        "type": "string",
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        },
                        "analyzer": "desc_analyzer"
                    },
                    "propertyNumber": {
                        "type": "string",
                        "index": "no",
                        "fields": {
                            "integer": {
                                "type": "integer"
                            },
                            "string": {
                                "type": "string"
                            }
                        }
                    },
					"propertySub": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"propertyLatitude": {
                        "type": "double"
                    },
                    "propertyLongitude": {
                        "type": "double"
                    },
					"propertyTypeCode": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"isPropertyFavorite": {
                        "type": "boolean"
                    },
					"routeName": {
                        "type": "string",
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        },
                        "analyzer": "desc_analyzer"
                    },
					"countyName": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"countyCode": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"stockNumber": {
                        "type": "string",
                        "index": "no",
                        "fields": {
                            "integer": {
                                "type": "integer"
                            },
                            "string": {
                                "type": "string"
                            }
                        }
                    },
					"serialNumber": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
                    "serialNumber2": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"quantity": {
                        "type": "double"
                    },
					"joints": {
                        "type": "long"
                    },
					"sendToMaterials": {
                        "type": "boolean"
                    },
					"operationalStatusCode": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"verifiedStatusCode": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    }
					"verifiedStatusDate": {
                        "type": "date",
                        "format": "epoch_millis||dateOptionalTime"
                    },
					"hasPendingTransaction": {
                        "type": "boolean"
                    },
					"hasJoints": {
                        "type": "boolean"
                    },
                    "missingGhgAttribute": {
                        "type": "boolean"
                    },
					"startDate": {
                        "type": "date",
                        "format": "epoch_millis||dateOptionalTime"
                    },
                    "parentDesc": {
                        "type": "text",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"parentAssetId": {
                        "type": "long"
                    },
					"parentDescOrCategoryName": {
                        "type": "text",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
					"categoryScope": {
                        "type": "string",
                        "norms": {
                            "enabled": false
                        },
                        "fields": {
                            "raw": {
                                "type": "string",
                                "index": "not_analyzed",
                                "ignore_above": 256
                            }
                        }
                    },
                    "tasks": {
                        "properties": {
                            "assignmentUuid": {
                                "type": "string",
                                "norms": {
                                    "enabled": false
                                },
                                "fields": {
                                    "raw": {
                                        "type": "string",
                                        "index": "not_analyzed",
                                        "ignore_above": 256
                                    }
                                }
                            },
                            "formName": {
                                "type": "string",
                                "norms": {
                                    "enabled": false
                                },
                                "fields": {
                                    "raw": {
                                        "type": "string",
                                        "index": "not_analyzed",
                                        "ignore_above": 256
                                    }
                                }
                            },
                            "startDate": {
                                "type": "date",
                                "format": "epoch_millis||dateOptionalTime"
                            },
                            "taskDesc": {
                                "type": "string",
                                "norms": {
                                    "enabled": false
                                },
                                "fields": {
                                    "raw": {
                                        "type": "string",
                                        "index": "not_analyzed",
                                        "ignore_above": 256
                                    }
                                }
                            },
                            "taskId": {
                                "type": "long"
                            }
                        }
                    }
                }
            }
        }
    }
'''

l_sql_task_query1 ="""
SELECT asset_id, im_dba.fn_listagg_clob(CAST(COLLECT(Data) as im_dba.type_varchar2_tab)) data
   FROM (
            SELECT UNIQUE me.asset_id , '{''formName'':'''||met.event_type_name ||''',''startDate'':'||
                    me.start_dt ||',''taskDesc'':'''||
                    nvl(me.event_desc,'NA') ||''',''taskId'':'|| me.event_id ||'}' AS Data
            FROM ma_dba.ma_event me, ma_dba.ma_event_type met
            WHERE me.event_type_id  =  met.event_type_id
            --AND me.asset_id IN ( 2720074, 2720425,3764545)
            AND EXISTS (SELECT 1 FROM IM_DBA.IM_EQUIPMENT_VW2 VW WHERE vw.asset_id =  me.asset_id))
            GROUP BY  asset_id
            HAVING COUNT( asset_id) > 0
            """


l_new = '''
(SELECT im_dba.fn_listagg_clob(cast(collect('{"formName":"'||met.event_type_name ||'","startDate":"'||
NVL(me.start_dt,SYSDATE) ||'","taskDesc":"'||
nvl(me.event_desc,'NA') ||'","taskId":"'|| me.event_id ||'"}') as im_dba.type_varchar2_tab))
                                        FROM ma_dba.ma_event me, ma_dba.ma_event_type met
                                        WHERE me.event_type_id  =  met.event_type_id
                                        AND me.asset_id = ie.asset_id)

            '''
l_sql_task_query = '''
SELECT asset_id, im_dba.fn_listagg_clob(cast(collect(JSON_OBJECT('formName' VALUE formName,
    																'startDate' VALUE  startDate,
    																'taskDesc' VALUE taskDesc,
    																'taskId' VALUE taskId)) as im_dba.type_varchar2_tab)) data
   FROM (
            SELECT me.asset_id , met.event_type_name formName,
                    nvl(me.start_dt,sysdate) startDate,
                    nvl(me.event_desc,'NA') taskDesc,
                    me.event_id taskId
            FROM ma_dba.ma_event me, ma_dba.ma_event_type met
            WHERE me.event_type_id  =  met.event_type_id
            --AND me.asset_id IN ( 2720074, 2720425,3764545, 3825005)
            AND EXISTS (SELECT 1 FROM IM_DBA.IM_EQUIPMENT_VW2 VW WHERE vw.asset_id =  me.asset_id))
            GROUP BY  asset_id
            HAVING COUNT( asset_id) > 0
'''
