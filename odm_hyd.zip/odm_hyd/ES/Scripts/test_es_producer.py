#!/usr/bin/python3

import sys
from pathlib import Path
import arrow
import re
from kafka import KafkaProducer
from kafka import KafkaConsumer
import threading
import cx_Oracle
import configparser
import logging
from logging.config import dictConfig
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime, timedelta
import json
from bson import json_util
import os, time, smtplib, socket, datetime
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
import multiprocessing as mp

producer = KafkaProducer(bootstrap_servers=["ktyprdkafka01.eogresources.com:9092","ktyprdkafka02.eogresources.com:9092","ktyprdkafka03.eogresources.com:9092"])

qry="""select WELL_ID,DIVISION_ID,PRIMO_ID,PRIMO_PRPRTY,PRIMO_PRPSUB,PERC_WELL_ID_NBR,TOW_SCHEMA from ODM_DBA.ODM_WELL_DELTA where division_id =10 and well_id in (6093,18368)"""

connection = cx_Oracle.connect('odm_dba/R1dba_101@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)

cursor.execute(qry)
rows = [x for x in cursor]
cols = [x[0] for x in cursor.description]
jds = []
for row in rows:
    jd = {}
    for prop, val in zip(cols, row):
        jd[prop] = val
    jds.append(jd)

#j_dump=json.dumps(jds, indent=4, default=json_util.default)#.encode('utf-8')
#print(jds[0])
#print(len(jds))



es = Elasticsearch(
		hosts = "http://e56bf542763d49e08a4941c7342497ce.esstg.eogresources.com:9200",
		timeout = 120,
                http_auth=("elastic","dWHXgtISrCbzvaVqgqSMJxAA"),
                verify_certs=False,
                headers = { "Content-type":"application/json" }
                )

index_name="odm_well_load520190418"
				

es.delete_by_query(index=index_name, doc_type="places",body='{"query":{"match_all":{}}}')

for i in range(0,2):
    j=i+1
    es.index(index=index_name, doc_type="places",id=j, body=jds[i])
    res=es.get(index=index_name, doc_type="places", id=j)
    producer.send('test', res['_source'].encode('utf-8'))



for k in range(0,2):
    l=k+1
    res=es.get(index=index_name, doc_type="places", id=l)
    print(res['_source'])




cursor.close()
connection.close()
