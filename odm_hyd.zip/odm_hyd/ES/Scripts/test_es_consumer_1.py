#!/usr/bin/python3

import sys
import os
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re
import json
from bson import json_util
from kafka import KafkaConsumer
import threading
import time
from ast import literal_eval


# To consume latest messages and auto-commit offsets 
consumer = KafkaConsumer('test', bootstrap_servers=["ktyprdkafka01.eogresources.com:9092","ktyprdkafka02.eogresources.com:9092","ktyprdkafka03.eogresources.com:9092"])
 
for message in consumer: 
# message value and key are raw bytes -- decode if necessary! 
# e.g., for unicode: `message.value.decode('utf-8')` 
    #print ("%s:%d:%d: key=%s value=%s" % (message.topic, message.partition, message.offset, message.key, message.value))
    value_to_process = message.value
    print(value_to_process.decode("utf-8", errors="ignore"))
    #print(type(value_to_process))
    #data = literal_eval(value_to_process.decode('utf8'))
    #print(type(data[0]))
    #print(data[0])
    #print(data)



# consume earliest available messages, don't commit offsets 
KafkaConsumer(auto_offset_reset='earliest', enable_auto_commit=False)

# consume json messages 
KafkaConsumer(value_deserializer=lambda m: json.loads(m.decode('ascii')))

# consume msgpack 
KafkaConsumer(value_deserializer=msgpack.unpackb)

# StopIteration if no message after 1sec 
KafkaConsumer(consumer_timeout_ms=1000)

# Subscribe to a regex topic pattern 
consumer = KafkaConsumer() 
consumer.subscribe(pattern='^awesome.*')


