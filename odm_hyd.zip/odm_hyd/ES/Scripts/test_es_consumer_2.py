#!/usr/bin/python3

import sys
from pathlib import Path
import arrow
import re
from kafka import KafkaProducer
from kafka import KafkaConsumer
import threading
import cx_Oracle
import configparser
import logging
from logging.config import dictConfig
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime, timedelta
import json
from bson import json_util
import os, time, smtplib, socket, datetime
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
import multiprocessing as mp


es = Elasticsearch(
		hosts = "http://e56bf542763d49e08a4941c7342497ce.esstg.eogresources.com:9200",
		timeout = 120,
                http_auth=("elastic","dWHXgtISrCbzvaVqgqSMJxAA"),
                verify_certs=False,
                headers = { "Content-type":"application/json" }
                )

index_name="odm_well_load520190418"

es.delete_by_query(index=index_name, doc_type="places",body='{"query":{"match_all":{}}}')

i=0
# To consume latest messages and auto-commit offsets 
consumer = KafkaConsumer('test', bootstrap_servers=["ktyprdkafka01.eogresources.com:9092","ktyprdkafka02.eogresources.com:9092","ktyprdkafka03.eogresources.com:9092"])
 
for message in consumer: 
# message value and key are raw bytes -- decode if necessary! 
# e.g., for unicode: `message.value.decode('utf-8')` 
    #print ("%s:%d:%d: key=%s value=%s" % (message.topic, message.partition, message.offset, message.key, message.value))
    value_to_process = message.value
    #print(value_to_process.decode("utf-8", errors="ignore"))
    i=i+1
    es.index(index=index_name, doc_type="places",id=i, body=value_to_process.decode("utf-8", errors="ignore"))
    res=es.get(index=index_name, doc_type="places", id=i)
    print(res['_source'])
    #print(type(value_to_process))
    #data = literal_eval(value_to_process.decode('utf8'))
    #print(type(data[0]))
    #print(data[0])
    #print(data)



# consume earliest available messages, don't commit offsets 
KafkaConsumer(auto_offset_reset='earliest', enable_auto_commit=False)

# consume json messages 
KafkaConsumer(value_deserializer=lambda m: json.loads(m.decode('ascii')))

# consume msgpack 
KafkaConsumer(value_deserializer=msgpack.unpackb)

# StopIteration if no message after 1sec 
KafkaConsumer(consumer_timeout_ms=1000)

# Subscribe to a regex topic pattern 
consumer = KafkaConsumer() 
consumer.subscribe(pattern='^awesome.*')


