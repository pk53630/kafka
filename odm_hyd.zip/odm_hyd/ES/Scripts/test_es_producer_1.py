#!/usr/bin/python3

import sys
from pathlib import Path
import arrow
import re
from kafka import KafkaProducer
from kafka import KafkaConsumer
import threading
import cx_Oracle
import configparser
import logging
from logging.config import dictConfig
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime, timedelta
import json
from bson import json_util
import os, time, smtplib, socket, datetime
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
import multiprocessing as mp

producer = KafkaProducer(bootstrap_servers=["ktyprdkafka01.eogresources.com:9092","ktyprdkafka02.eogresources.com:9092","ktyprdkafka03.eogresources.com:9092"])

qry="""select WELL_ID,DIVISION_ID,PRIMO_ID,PRIMO_PRPRTY,PRIMO_PRPSUB,PERC_WELL_ID_NBR,TOW_SCHEMA from ODM_DBA.ODM_WELL_DELTA where division_id =10 and well_id in (6093,18368)"""

connection = cx_Oracle.connect('odm_dba/R1dba_101@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)

cursor.execute(qry)
#rows = cursor.fetchall()
rows = [x for x in cursor]
cols = [x[0] for x in cursor.description]
jds = []
for row in rows:
    jd = {}
    for prop, val in zip(cols, row):
        jd[prop] = val
    producer.send('test', json.dumps(jd, indent=4, default=json_util.default).encode('utf-8'))
    print(jd)



cursor.close()
connection.close()
