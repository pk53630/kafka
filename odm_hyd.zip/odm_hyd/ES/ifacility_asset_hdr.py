#!/usr/local/bin/python3
import cx_Oracle as db
import configparser
import logging
import datetime as dt
from datetime import datetime, timedelta
import datetime, json, ast
import os, time, smtplib, socket, datetime, sys
from email.mime.text import MIMEText
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import pandas as pd
import numpy as np
import ifacility_asset_hdr_mapping as var
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
import multiprocessing as mp


logger = logging.getLogger(__name__)
logger.info('-----------------------------------------------------')
logger.info('Start process for iFacility asset headers load ')
logger.info('-----------------------------------------------------')

scripts_path = '{0}'.format(os.path.abspath(os.path.join(__file__, "../ini/config/")))
log_path = '{0}'.format(os.path.abspath(os.path.join(__file__, "../ini/logs/")))

'''
load_type = os.environ["param1"]
interval_seconds = os.environ["param2"]
print('Load type: ', load_type)
print('Interval run time: ', interval_seconds)
logger.info(load_type)
logger.info(interval_seconds)
logger.info("Version: ", sys.version_info)
#logger.info("version :", platform.python_version())
'''
oraConfigFileName = scripts_path + '/ora_credentials.ini'
logger.info(oraConfigFileName)
esConfigFileName = scripts_path + '/ece_es_credentials.ini'
logger.info(esConfigFileName)
print(oraConfigFileName)

#commnet below lines of code in docker
args = sys.argv[1:]
load_type = args[0]
print('Load type: ', load_type)
start_time = str(dt.datetime.now())
logging.basicConfig(filename='iFacility_asset_headers_'+load_type+'_'+start_time[:10]+'.log',
                    level=logging.INFO,
                    format="%(asctime)s:%(levelname)s:%(message)s")
#commnet above lines of code in docker
''''
oraConfigFileName = '/home/odmbatch/ora_credentials.ini'
esConfigFileName = '/home/odmbatch/ece_es_credentials.ini'
oraConfigFileName = 'C:/Work/Python/ini/config/ora_credentials.ini'
esConfigFileName = 'C:/Work/ython/ini/config/ece_es_credentials.ini'
'''

databaseName = 'IFAC_DBA_STAGE'

class Initialization():
    def __init__ (self, oraConfigFileName, esConfigFileName, databaseName):
        # Oracle DB details
        config = configparser.ConfigParser()
        config.read(oraConfigFileName)
        db_search_config = config[databaseName]
        self.db_host_name = db_search_config['HostName']
        self.db_user_name = db_search_config['User']
        self.db_password  = db_search_config['Password']
        self.db_port      = db_search_config['Port']

        # ES details
        config.read(esConfigFileName)
        es_search_conf = config['FIELDOPSESSTAGE']
        self.host_name = es_search_conf['HostName']
        self.time_out = int( es_search_conf['Timeout'])
        self.time_out = 1800
        self.user = es_search_conf['User']
        self.password = es_search_conf['Password']
        self.certs =  es_search_conf['VerifyCerts']
        self.header = es_search_conf['Header']
        self.h = { "Content-type":"application/json" }

    def db_logon(self):
        string = self.db_user_name+'/'+self.db_password+'@'+self.db_host_name
        print(string)
        ora_con = db.connect(string)
        return ora_con
    def es_login(self):
        es = Elasticsearch(
                           hosts = self.host_name,
                           timeout =  self.time_out,
                           http_auth = (self.user,  self.password),
                           verify_certs = self.certs,
                           headers = self.h
                           )
        return es

# close the Oracle connections
def close_conn(cur, con):
    cur.close()
    con.close()

# Delete Assets which are deleted from log table
def delete_asset(es, index_name, type_name, ora_del_data):
    try:
        for i in ora_del_data:
            #Asset = list(i)
            #id = Asset[0]
            try:
                res = es.delete(index=index_name, doc_type=type_name, id= i)
            except Exception as e:
                pass
    except Exception as e:
        print('Error in Delete asset, ',e)
        logger.info('Error in Delete asset '+ str(e))

# split the data into multiple sets
def split_dataframe_to_chunks(df, n):
    df_len = len(df)
    count = 0
    dfs = []
    while True:
        if count > df_len-1:
            break
        start = count
        count += n
        #dfs.append(df.iloc[start : count])
        dfs.append(df[start : count])
    return dfs

# Process for load data into ES
def parallel_generator(ora_rows,index_name,type_name,es_field_names):
    for row in ora_rows:
        data_dict = {}
        try:
            data_dict = dict(zip(es_field_names, row))
            data_dict_task =  eval(str(data_dict['tasks']).replace(':null,',''))
            '''
            data_dict['sendToMaterials'] = ast.literal_eval(data_dict['sendToMaterials'])
            data_dict['hasPendingTransaction'] = ast.literal_eval(data_dict['hasPendingTransaction'])
            data_dict['isPropertyFavorite'] = ast.literal_eval(data_dict['isPropertyFavorite'])
            data_dict['missingGhgAttribute'] = ast.literal_eval(data_dict['missingGhgAttribute'])
            data_dict['hasJoints'] = ast.literal_eval(data_dict['hasJoints'])
            '''
            try:
                if data_dict_task is not None :
                    data_dict['tasks'] = data_dict_task
            except Exception as e:
                print("Error in task:", e)
            #print('final: ', data_dict_task)
            #print(type(data_dict))
            #ast.literal_eval(json.dumps(k, ensure_ascii=False))
            #data_dict = dict((k,ast.literal_eval(v)) for k,v in data_dict.items())
        except Exception as e:
            print("Error in row :", e)
            logger.info("Error in row :", str(e))
        yield {
                '_index': index_name,
                '_type': type_name,
                '_id': data_dict['assetId'],
                '_score': 1,
                '_source': data_dict
            }

def delete_old_index(es, index_name, type_name, alias_name):
    es.indices.put_settings(index=index_name,
                            body={"index": {"refresh_interval": "1s", "number_of_replicas": 1}})
    es.indices.put_alias(index=index_name, name=alias_name, ignore=400)
    indices = list(es.indices.get_alias(alias_name, ignore=[400, 404]))
    for idx in indices:
        if index_name != idx:
            es.indices.delete(idx, ignore=404)
            print("Deleted the index ", idx)
    es.indices.put_alias(index=index_name, name=alias_name, ignore=400)

def process():
    while True:
        l_Excpt_flg = 0
        try:
            try:
                conn = C_var.db_logon()
                print('DB Starts at : '+ str(dt.datetime.now()))
                logger.info('DB Starts at '+ str(dt.datetime.now()))
                cur = conn.cursor()
                lrc1_cursor = conn.cursor()
                lrc2_cursor = conn.cursor()
                ora_ins_data =[]
                ora_upd_data =[]
                ora_del_data =[]
                if load_type == 'FULL':
                    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_ifac_asset_hdr_es',[load_type, lrc1_cursor, lrc2_cursor])
                    ora_ins_data = lrc1_cursor.fetchall()
                else:
                    cur.callproc('ifac_dba.ifac_elastic_pkg.sp_ifac_asset_hdr_es',[load_type, lrc1_cursor, lrc2_cursor])
                    ora_upd_data = lrc1_cursor.fetchall()
                    ora_del_data = lrc2_cursor.fetchall()
                print('DB Success at : '+ str(dt.datetime.now()))
                #cur.close()
                #ora_con.close()
                logger.info('DB Data success at '+ str(dt.datetime.now()))
            except Exception as e:
                logger.error(e)
                l_Excpt_flg = 1
                print('Error in DataBase : ', e)
                logger.info("Error in DataBase : ", str(e))
                raise
            try:
                es = C_var.es_login()
                print("Success ES "+ str(dt.datetime.now()))
                logger.info('ES connection and login Success ')
            except Exception as e:
                logger.error(e)
                l_Excpt_flg = 1
                print('Error at ES: ', e)
                logger.info("Error in ES : " + str(e))
                raise

            index_name = 'ifacility_asset_headers' + dt.datetime.now().strftime("%Y%m%d")
            type_name = 'object'
            alias_name = 'ifacility_asset_headers'
            if load_type == 'FULL':
                ora_data = ora_ins_data
                if not ora_data:
                    logger.info('No data found in Equipment load for Full, Process exists.')
                    print('No data for Full load..')
                    exit()
            elif load_type == 'INCR':
                ora_data = ora_upd_data
                if not ora_del_data and not ora_data:
                    logger.info('No data found in Equipment load for Incremental, Process exists.')
                    print("No data for Incremental load")
                    exit()
                delete_asset(es, index_name, type_name, ora_del_data)
                print("Deleted old assets is completed")
                logger.info("Deleted old assets is completed.")

            es_field_names = var.es_field_names
            print('Total records: ',len(ora_data))
            chunk_data = split_dataframe_to_chunks(ora_data, 70000)
            chunk_size = len(chunk_data)
            print('Total Chunks: ',len(chunk_data))
            logger.info('Total records : '+str(len(ora_data))+', total chunks : ' +str(len(chunk_data)))

            try:
                if load_type == 'FULL':
                    if es.indices.exists(index=index_name):
                        logger.info('Index already exists : ' + index_name + ', Type name : ' + type_name)
                    else:
                        shards = 1
                        replicas = 0
                        es.indices.create(index=index_name, ignore=400,
                                          body={"number_of_shards": shards, "number_of_replicas": replicas})
                        #es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
                        es.indices.put_settings(index=index_name, body={"index": {"refresh_interval": "-1"}})
                        logger.info('New Index created  ' + index_name + ' and Type is ' + type_name)
                else:
                    if es.indices.exists(index=index_name):
                        logger.info('Index already exists : ' + index_name + ', Type name : ' + type_name)
                    else:
                        shards = 1
                        replicas = 1
                        es.indices.create(index=index_name, ignore=400,
                                          body={"number_of_shards": shards, "number_of_replicas": replicas})
                        #es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
                        logger.info('New Index created  ' + index_name + ' and Type is ' + type_name)
                print('Index name is ' + index_name)
            except Exception as e:
                logger.error(e)
                l_Excpt_flg = 1
                print('Error in Index : ', e)
                logger.info("Error in Index : " + str(e))
                raise
            # Process for ES
            try:
                logger.info('ES loads starts at ' + str(dt.datetime.now()))
                for chunk_number in range(chunk_size):
                    es_data = chunk_data[chunk_number]
                    for success, info in helpers.parallel_bulk( es,
                                                                parallel_generator( es_data,
                                                                                    index_name,
                                                                                    type_name,
                                                                                    es_field_names),
                                                                thread_count=5,
                                                                chunk_size=2500):
                        if not success:
                            print('Documents Failed:........................................', info)
                            logger.info('Error in load ES', str(e))
                    es.indices.flush(index=index_name, wait_if_ongoing=True)
                    print('After parallel Flush: ' + str(dt.datetime.now()))
                    logger.info('After parallel Flush : '+ str(dt.datetime.now()))
                logger.info('ES Load completed.')
                if load_type == 'FULL':
                    try:
                        logger.info("Delete old index's Starts")
                        delete_old_index(es, index_name, type_name, alias_name)
                        logger.info("Delete old index's is completed")
                    except Exception as e:
                        logger.error(e)
                        l_Excpt_flg = 1
                        print('Error at delete Index : ', e)
                        logger.info("Error at delete Index : ", str(e))
            except Exception as e:
                logger.error(e)
                l_Excpt_flg = 1
                print('Error at load data to ES : ', e)
                logger.info("Error at load data to ES :", str(e))
        except Exception as e:
            logger.error(e)
            l_Excpt_flg = 1
            print('Error in iFacility asset headers load : ', e)
            logger.info("Error in iFacility asset headers load : " + str(e))
        finally:
            end_time = str(dt.datetime.now())
            if l_Excpt_flg == 1:
                logger.info('Equipment load for iFacility asset headers failed at :'+end_time)
            else:
                logger.info('Equipment load for iFacility asset headers Successfully completed at :'+end_time)
            logger.info('-----------------------------------------------------')
            logger.info('')
            print("Completed...")

if __name__ == '__main__':
    C_var = Initialization(oraConfigFileName, esConfigFileName, databaseName)
    logging.basicConfig(level=logging.DEBUG)
    logger.info("Process start at " + str(dt.datetime.now()))
    process()
    logger.info("Process ends at " + str(dt.datetime.now()))
