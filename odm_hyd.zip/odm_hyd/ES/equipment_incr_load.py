#!/usr/local/bin/python3
import cx_Oracle as db
import configparser
import logging
import datetime as dt
from datetime import datetime, timedelta
import json
import os, time, smtplib, socket, datetime
from email.mime.text import MIMEText
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import pandas as pd
import numpy as np
from elasticsearch.helpers import bulk, streaming_bulk, parallel_bulk
import multiprocessing as mp
import equipment_load_variables as var

start_time = str(dt.datetime.now())
logging.basicConfig(filename='equipment_load_'+start_time[:10]+'.log',
                    level=logging.INFO,
                    format="%(asctime)s:%(levelname)s:%(message)s")
logging.info('-----------------------------------------------------')
logging.info('Start process for Equipment load for ifacility '+start_time)
logging.info('-----------------------------------------------------')

def conn_db(p_config_name):
    #'/home/odmbatch/ece_es_credentials.ini'
    esconfigfilename = 'C:/Users/vprasad/python/ini/ora_credentials.ini'
    config = configparser.ConfigParser()
    config.read(esconfigfilename)
    db_search_config = config[p_config_name]
    host_name = db_search_config['HostName']
    user_name = db_search_config['User']
    password  = db_search_config['Password']
    port      = db_search_config['Port']
    #print(host_name, user_name, password, port)
    logging.info('host name:'+host_name+', user name:'+user_name+', password:'+password+', port:'+ port)
    string = user_name+'/'+password+'@'+host_name
    ora_con = db.connect(string)
    cur = ora_con.cursor()
    cur.execute(var.lSqlQuery)
    ora_data = cur.fetchall()
    print('DB Success at : '+ str(dt.datetime.now()))
    cur.close()
    ora_con.close()
    logging.info('DB Data success at '+ str(dt.datetime.now()))
    return ora_data

def equip_load(p_config_name):
    l_Excpt_flg = 0
    try:
        print('Starts at : '+ str(dt.datetime.now()))
        ora_data = conn_db(p_config_name)
        if not ora_data:
            logging.info('No data found in Equipment load, Process exists.')
            raise
        try:
            # split the data into multiple sets
            def split_dataframe_to_chunks(df, n):
                df_len = len(df)
                count = 0
                dfs = []
                while True:
                    if count > df_len-1:
                        break
                    start = count
                    count += n
                    #dfs.append(df.iloc[start : count])
                    dfs.append(df[start : count])
                return dfs

            # create the index foe ES
            def create_index(index_name,type_name):
                mappings= var.mappings
                shards = 1
                replicas = 0
                es.indices.create(index=index_name, ignore=400, body={"number_of_shards":shards,"number_of_replicas":replicas})
                es.indices.put_mapping(index=index_name, doc_type=type_name, body=mappings, ignore=400)
                es.indices.put_settings(index=index_name, body={"index": {"refresh_interval": "-1"}})
                logging.info('Index created '+ index_name)

            def delete_old_index(es, index_name, type_name):
                es.indices.put_settings(index=index_name, body={ "index": {"refresh_interval": "1s","number_of_replicas":2}})
                es.indices.put_alias(index = index_name, name = type_name, ignore = 400)
                indices = list(es.indices.get_alias(type_name, ignore=[400,404]))
                for idx in indices:
                    if index_name != idx:
                        print("The index that need to be deleted are:",idx)
                        es.indices.delete(idx, ignore = 404)
                        print("Deleted the index ", idx)

                es.indices.put_alias(index=index_name, name='ifac_equipment', ignore=400)

            # ES run in parallel bulk
            def parallel_generator(ora_rows,index_name,type_name,es_field_names):
                for row in ora_rows:
                    data_dict = {}
                    data_dict = dict(zip(es_field_names, row))
                    yield {
                            '_index': index_name,
                            '_type': type_name,
                            '_id': data_dict['assetId'],
                            '_score': 1,
                            '_source': data_dict
                        }

            #esconfigfilename = '/home/odmbatch/ece_es_credentials.ini'
            esconfigfilename = 'C:/Users/vprasad/python/ini/ece_es_credentials.ini'
            config = configparser.ConfigParser()
            config.read(esconfigfilename)
            es_search_conf = config['FIELDOPSESSTAGE']
            host_name = es_search_conf['HostName']
            time_out = int( es_search_conf['Timeout'])
            user = es_search_conf['User']
            password = es_search_conf['Password']
            certs =  es_search_conf['VerifyCerts']
            header = es_search_conf['Header']
            h = { "Content-type":"application/json" }
            es = Elasticsearch(
                               hosts = host_name,
                               timeout = time_out,
                               http_auth=(user,password),
                               verify_certs=certs,
                               headers = h
                               )
            print("Success ES "+ str(dt.datetime.now()))
            logging.info('ES connection and login Succes for host: '+host_name)
            index_name = 'equipment_load' + dt.datetime.now().strftime("%Y%m%d")
            index_name = 'equipment520190131'
            type_name = 'equipment5'

            if es.indices.exists(index=index_name):
                pass
            else:
                create_index(index_name, type_name)
            print('Index name is '+ index_name)

            es_field_names = var.es_field_names
            field_mappings = var.IndexFieldMappings.replace("\n", "").replace("<", "").replace(">", "")
            field_mappings_dict = dict(x.split(':') for x in field_mappings.split(','))
            es_field_names = [(field_mappings_dict[ora_col_name]) for ora_col_name in var.es_field_names]
            print('Total records: ',len(ora_data))
            chunk_data = split_dataframe_to_chunks(ora_data, 70000)
            chunk_size = len(chunk_data)
            print('Total Chunks: ',len(chunk_data))
            #print(chunk_data)
            try:
                #print(chunk_data)
                logging.info('ES loads starts at ' + str(dt.datetime.now()))
                #for chunks_data in chunk_data:
                for chunk_number in range(chunk_size):
                    #print(type(chunks_data))
                    #equip_json = chunks_data.to_json(orient='records')
                    #final_json = json.loads(equip_json)
                    #print(len(chunks_data))
                    #if len(chunks_data) >= 500:
                    #list_data = data.values.tolist()
                    #es_data = []
                    #for l_data in list_data:
                        #es_data.append(tuple(l_data))
                    #print(es_data)
                    es_data = chunk_data[chunk_number]
                    #print('increment value :' ,k)
                    #print('es_data  : ',(es_data))
                    #print('ora_data : ',(ora_data))
                    #print('list_data: ',(list_data))
                    #print('chunk_data: ',(chunk_data))
                    print(len(es_data))
                    #print((ora_data))
                    #print(len(list_data))
                    #print((chunk_data))
                    if 1 == 1:
                        for success, info in helpers.parallel_bulk( es,
                                                                    parallel_generator( es_data,
                                                                                        index_name,
                                                                                        type_name,
                                                                                        es_field_names),
                                                                    thread_count=5,
                                                                    chunk_size=2500):
                            if not success:
                                print('Documents Failed:........................................', info)
                        es.indices.flush(index=index_name, wait_if_ongoing=True)
                        print('After Parallel Flush: ' + str(dt.datetime.now()))
                logging.info('ES Load completed.')
                try:
                    delete_old_index(es, index_name, type_name)
                except Exception as e:
                    logging.error(e)
                    l_Excpt_flg = 1
                    print('Error at delete Index : ', e)
            except Exception as e:
                logging.error(e)
                l_Excpt_flg = 1
                print('Error at ES: ', e)
        except Exception as e:
            logging.error(e)
            l_Excpt_flg = 1
            print('Error at DataFrame: ', e)
    except Exception as e:
        logging.error(e)
        l_Excpt_flg = 1
        print('Error at DB: ', e)
    finally:
        print('Final...')
        end_time = str(dt.datetime.now())
        if l_Excpt_flg == 1:
            logging.info('Equipment load for ifacility failed at :'+end_time)
        else:
            logging.info('Equipment load for ifacility Successfully completed at :'+end_time)
        logging.info('-----------------------------------------------------')

if __name__ == '__main__':
    p_config_name = 'IM_DBA_STAGE'
    equip_load(p_config_name)
