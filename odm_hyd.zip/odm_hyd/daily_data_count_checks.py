#!/usr/bin/python3
import sys
import os
import cx_Oracle
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re
import smtplib
import email.utils
import email
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

dt=arrow.now().format('YYYYMMDD')
filename="""/home/odmbatch/odm/logs/DAILY_DATA_COUNT_CHECKS_"""+dt+""".log"""

my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    #print("file is not present")
    Path(filename).touch()

log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("##################################### DAILY DATA COUNT CHECKS STARTED ##########################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")


query1="""select abs(a.ifac_sche - b.ea_assoc) as v_cnt_assoc from (select count(*) as ifac_sche from ifac_dba.ifac_schematic where update_ts>sysdate-1) a, (select count(*) as ea_assoc from im_dba.ea_assoc where update_ts>sysdate-1) b"""
query2="""select count(*) as v_cnt_asset from im_dba.im_asset a, im_dba.im_property_asset pa where a.asset_id=pa.asset_id and a.update_ts>sysdate-1 order by a.update_ts desc"""


#connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE_TAF.EOGRESOURCES.COM')
connection = cx_Oracle.connect('odm_dba/R1dba_101@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)

cursor.execute(query1)
result1 = cursor.fetchall()
print (result1[0][0])
logger.info("Assco Query - "+query1+" :")
logger.info("Assco Query Result - "+str(result1[0][0]))
logger.info("                                                                                                                ")

cursor.execute(query2)
result2 = cursor.fetchall()
print (result2[0][0])
logger.info("Asset Query - "+query2+" :")
logger.info("Asset Query Result - "+str(result2[0][0]))


cursor.close()
connection.close()

logger.info("                                                                                                                ")
logger.info("                                                                                                                ")
logger.info("##################################### Oracle Connection is Closed ##############################################")
logger.info("                                                                                                                ")

me = "Praveen_Kshirsagaray@eogresources.com"
you = "Praveen_Kshirsagaray@eogresources.com"

# Create message
msg = MIMEMultipart('alternative')
msg['Subject'] = """Daily Data Counts Check as on """+dt
msg['From'] = me
msg['To'] = you

# Create the body

text = """Hi Team, 
"""+"""\n"""+"""
This is Daily Data Counts Check report :"""+"""\n"""+"""
 
Assco Count - """+str(result1[0][0])+"""
Assest Cout - """+str(result2[0][0])+"""\n"""+"""

Regards,
ODM support team,"""


html = """\
<html>
  <head></head>
  <body>
    <p>Hi Team,<br>
       <br>
       This is Daily Data Counts Check report :<br>
           Assco  Count - """+str(result1[0][0])+""" <br> 
	   Assest Count - """+str(result2[0][0])+"""\n"""+"""<br>
	   <br>
           <br>
	   Regards,<br>
	   ODM Support team,<br>
    </p>
  </body>
</html>
"""

# Record the MIME types of both parts - text/plain and text/html.
part1 = MIMEText(text, 'plain')
part2 = MIMEText(html, 'html')

# the HTML message, is best and preferred.
msg.attach(part1)
msg.attach(part2)

s = smtplib.SMTP('smtp.eogresources.com')
s.sendmail(me, you, msg.as_string())
s.quit()

logger.info("##################################### Email is trigerd to desination ###########################################")
logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("##################################### DAILY DATA COUNT CHECKS COMPLETED ########################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")
logger.info("                                                                                                                ")
