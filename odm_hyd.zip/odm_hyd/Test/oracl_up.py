#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re

emp_id = sys.argv[1]


dt=arrow.now().format('YYYY-MM-DD')
filename="""/home/odmbatch/odm_hyd/Test/test__"""+dt+""".log"""

my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    #print("file is not present")
    Path(filename).touch()


log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("##################################### ODM COMPLETION DELTA EXTACTION STARTED ###################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")

logger.info("                                                                                                                ")
v_emp_id="""select empno from v_emp where empno ="""+emp_id
logger.info("                                                                                                                ")

v_upd_id="""update v_emp set hiredate=sysdate where empno ="""


print(v_emp_id)
print(v_upd_id)


connection = cx_Oracle.connect('mrte_dba/Test_456@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(v_emp_id)

emp_id_list=[]
emp_id_col_nm =[]

for j in cursor.description:
    emp_id_col_nm.append(j[0])
	
for row_emp_id in cursor.fetchall():
    emp_id_list.append(list(row_emp_id))

print(emp_id_list[0][0])



for i in range(0,len(emp_id_list)):
    v_upd = v_upd_id + str(emp_id_list[0][i])
    cursor.execute(v_upd)
    v_upd=''
    print(v_upd)
      

connection.commit()
connection.close()

