#!/usr/bin/python3
import sys
import os

Name = sys.argv[1]
Grade = sys.argv[2]

gr = int(Grade)

if (gr > 0 and gr < 151):
    print('"'+Name+" grade: "+str(gr)+'"')
else:
    if (gr < 0):
        print("GradeTooLowException")
    else:
        print("GradeTooHighException")

