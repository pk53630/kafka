#!/usr/bin/python3
import sys

#name = sys.argv[1]
#grade = sys.argv[2]
#execute = sys.argv[3]
#signed = sys.argv[4]

low_num = 1
high_num = 150
low = int(low_num)
high = int(high_num)


#[Form name] sign grade: [grade sign], exec grade: [grade exec], is signed: [True or False]
#Awesome Form sign grade: 80, exec grade: 40, is signed: False

# define Python user-defined exceptions
class Error(Exception):
   """Base class for other exceptions"""
   pass
class ValueTooSmallError(Error):
   """Raised when the input value is too small"""
   pass
class ValueTooLargeError(Error):
   """Raised when the input value is too large"""
   pass


class Person:
  def __init__(self, name, grade, execute,signed):
      self.name = name
      self.grade = grade
      self.execute = execute
      self.signed = signed

  def myfunc(self):
    while True:
        try:

            if (int(self.grade) > 0 and int(self.grade) < 151):
                print(self.name+" sign grade: "+str(self.grade)+", exec grade: "+str(self.execute)+", is signed: "+str(+self.signed))
                break
            else:
                if int(self.grade) < low:
                    raise ValueTooSmallError
                    break
                elif int(self.grade) > high:
                    raise ValueTooLargeError
                    break
        except ValueTooSmallError:
            print("GradeTooLowException")
            break
        except ValueTooLargeError:
            print("GradeTooHighException")
            break

			
@Person
def ShrubberyCreationForm("Awesome Form", 145,137,False):
    print("Hello")



p1 = Person("Awesome Form", 145,137,False)	


