#!/usr/bin/python3
import sys

Name = sys.argv[1]
Grade = sys.argv[2]

# define Python user-defined exceptions
class Error(Exception):
   """Base class for other exceptions"""
   pass
class ValueTooSmallError(Error):
   """Raised when the input value is too small"""
   pass
class ValueTooLargeError(Error):
   """Raised when the input value is too large"""
   pass


low_num = 1
high_num = 150
low = int(low_num)
high = int(high_num)


while True:
   try:
       gr = int(Grade)
       if (gr > 0 and gr < 151):
           print('"'+Name+" grade: "+str(gr)+'"')
           break
       else:
           if gr < low:
               raise ValueTooSmallError
           elif gr > high:
               raise ValueTooLargeError
           break
   except ValueTooSmallError:
      print("This value is too small, try again!")
      break
   except ValueTooLargeError:
      print("This value is too large, try again!")
      break
