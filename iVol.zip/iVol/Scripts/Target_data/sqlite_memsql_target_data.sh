#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_1.py 10 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_2.py 10 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_3.py 10 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_4.py 10 </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_1.py 14 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_2.py 14 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_3.py 14 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_4.py 14 </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_1.py 30 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_2.py 30 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_3.py 30 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_4.py 30 </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_1.py 50 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_2.py 50 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_3.py 50 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_4.py 50 </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_1.py 60 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_2.py 60 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_3.py 60 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_4.py 60 </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_1.py 63 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_2.py 63 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_3.py 63 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Target_data/sqlite_memsql_target_data_2017_4.py 63 </dev/null >/dev/null 2>&1 &
