#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re

div_id = sys.argv[1]
#pwd = sys.argv[1]
#sid = sys.argv[1]

dt=arrow.now().format('YYYY-MM-DD')
filename="""/home/odmbatch/odm/logs/get_target_data_"""+dt+""".log"""

my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    #print("file is not present")
    Path(filename).touch()


log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("########################################### NRI DATA EXTACTION STARTED #########################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")


query=""" SELECT  prod.division_id
      ,        prod.completion_id
      ,        prod.prod_dt date_value
      ,        prod.gross_oil_prod target_oil_prod
      ,        prod.gross_gas_prod target_gas_prod
      ,        prod.gross_water_prod target_water_prod
      FROM    odm_dba.odm_comp_target_prod_daily prod
      WHERE    prod.prod_dt BETWEEN to_date('2017-10-01','YYYY-MM-DD') and to_date('2017-12-31','YYYY-MM-DD') and prod.division_id="""+div_id

connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(query)

data_list=[]
column_names =[]

for i in cursor.description:
    column_names.append(i[0])
for row in cursor.fetchall():
    data_list.append(list(row))

cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()

logger.info("                                                                                                                ")
logger.info("                                                                                                                ")
logger.info("###################################### Insert Statement STARTED Execution ######################################")
stmt1 = """INSERT INTO MRTE_DBA.GET_TARGET_DATA
(DIVISION_ID, COMPLETION_ID, DATE_VALUE,TARGET_OIL_PROD,TARGET_GAS_PROD,TARGET_WATER_PROD)
 VALUES
(%s, %s, %s, %s, %s, %s)"""

#cur.executemany(stmt1, data_list)
for k in range(0,len(data_list)):
    #print(len(data_list))
    cur.execute(stmt1,data_list[k])
    #cur.execute(stmt1,data_list[1])



cnx.commit()
#logger.debug("Inserted Well ID are %s",data_list)
logger.info("###################################### Insert Statement COMPLETED Execution ####################################")
logger.info("                                                                                                                ")
cur.close()
cnx.close()

cursor.close()
connection.close()

logger.info("################################################################################################################")
logger.info("##################################### ODM WELL DELTA EXTACTION COMPLETED #######################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")
logger.info("                                                                                                                ")

