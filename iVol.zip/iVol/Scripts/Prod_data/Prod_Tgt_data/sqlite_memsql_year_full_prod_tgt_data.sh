#!/usr/sh

echo `date`

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2005 '10-14' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2005 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2005 '45-50' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2005 '60-63' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2005 '30-93-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2006 '10-14' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2006 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2006 '45-50' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2006 '60-63' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2006 '30-93-95-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2007 '10-14' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2007 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2007 '45-50' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2007 '60-63' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2007 '30-93-95-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2008 '10-14' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2008 '30-95' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2008 '45-50' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2008 '60' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2008 '95' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2008 '60-63-93-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2009 '10-14' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2009 '30-50' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2009 '45-60' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2009 '50' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2009 '95' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2009 '95-63-93-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2010 '10-50' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2010 '14-30' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2010 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2010 '45-60' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2010 '95' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2010 '95-63-93-94-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2011 '10-45' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2011 '14-63' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2011 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2011 '50-60' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2011 '95' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2011 '30-95-94-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2012 '10-45' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2012 '14-63' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2012 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2012 '50-60' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2012 '95' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2012 '30-95-94-144-147-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2013 '10-45' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2013 '14-63' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2013 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2013 '50-60' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2013 '95' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2013 '30-95-144-147-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2014 '10-45' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2014 '14-60' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2014 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2014 '50-63' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2014 '95' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2014 '30-95-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2015 '10-60' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2015 '14-50' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2015 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2015 '45-63' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2015 '30-95-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2016 '60-63' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2016 '14-50' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2016 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2016 '10-45' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2016 '30-95-205-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2017 '10-45' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2017 '14-60' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2017 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2017 '50-63' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2017 '30-95-205-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2018 '10-50' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2018 '14-45' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2018 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2018 '60-63' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2018 '30-95-205-293-301' 'PRD_DATA'

sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2019 '10-60' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2019 '14-45' 'PRD_DATA'
#sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2019 '30' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2019 '50-63' 'PRD_DATA'
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_Tgt_data/sqlite_memsql_full_prod_tgt_data.sh 2019 '30-95-293-301' 'PRD_DATA'

echo `date`
