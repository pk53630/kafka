#!/bin/sh

echo `date`
present_yr=`date +"%Y"`
previou_yr=`expr $present_yr - 1`
v_inc_file_nm='/home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_inc_target_data.sh'
v_pyscript_nm='python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data.py '
v_nullify_war=' </dev/null >/dev/null 2>&1 &'

echo '#!/bin/sh' > $v_inc_file_nm
echo '' >> $v_inc_file_nm
echo 'echo `date`' >> $v_inc_file_nm
echo 'echo "Deleting the records of present year and previous year"' >> $v_inc_file_nm
echo 'python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_inc_target_data_del.py' >> $v_inc_file_nm
echo 'echo `date`' >> $v_inc_file_nm

var=`$ORACLE_HOME/bin/sqlplus -S DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM << EOD
WHENEVER OSERROR EXIT 9;
WHENEVER SQLERROR EXIT 9;
set serveroutput off;
set echo off;
set termout off;
set feedback off;
set heading off;
set trims on;
set trimspool on;
SET WRAP ON;
SET RECSEP OFF;
set lines 32766;
set pages 0;
select distinct division_id from odm_dba.odm_comp_target_prod_daily where to_char(prod_dt,'YYYY') = $present_yr;
exit;
EOD`

echo $var

for i in $var
do
echo $v_pyscript_nm$i" "$present_yr$v_nullify_war >> $v_inc_file_nm
done


echo 'until [ `ps -ef |grep -i "sqlite_memsql_target_data"|wc -l` -eq 1 ]' >> $v_inc_file_nm
echo 'do' >> $v_inc_file_nm
echo ' sleep 5' >> $v_inc_file_nm
echo 'done' >> $v_inc_file_nm
echo 'echo `date`' >> $v_inc_file_nm
echo 'exit 0' >> $v_inc_file_nm
chmod 775 $v_inc_file_nm
sh $v_inc_file_nm
echo `date`
exit 0
