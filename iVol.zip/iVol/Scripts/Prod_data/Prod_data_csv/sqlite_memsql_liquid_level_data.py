#!/usr/local/bin/python3
import sys
import csv
import os
import cx_Oracle
import mysql.connector
import datetime

query="""
SELECT  
      e.division_ID,
      c.completion_id,
      e.DEPTH_TO_LIQ_LEVEL,
      e.TOTAL_GASEOUS_LIQ_COLUMN_HT,
      e.PRODUCING_BHP ,
      e.PUMP_INTAKE_DEPTH,
      e.PUMP_INTAKE_PRESSURE,
      e.EQUIVALENT_GAS_FREE_LIQ_HT,
      e.CASING_PRESSURE,
      e.STATIC_BHP,
      e.PBHP,
      e.FLUID_LEVEL_SURVEY_DATE
      FROM     odm_dba.odm_completion c
      ,        iprod_dba.echometer_fluid_survey e
      WHERE    c.division_id = e.division_id
      AND      c.primo_prprty = e.well_id
"""

#print(query)

connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(query)

filename = "/home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/load_csv_sqlite_memsql_liquid_level_data_.dat"

row = cursor.fetchall()
with open(filename, 'w', newline='\n') as fp:
    a = csv.writer(fp, delimiter='|')
    a.writerows(row)

cursor.close()
connection.close()	


cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()

stmt_del = "DELETE FROM MRTE_DBA.GET_LIQUIDLEVEL_DATA"
cur.execute(stmt_del)
cnx.commit()

stmt = """ 
LOAD DATA LOCAL INFILE  
'"""+filename+"""'
INTO TABLE MRTE_DBA.GET_LIQUIDLEVEL_DATA
FIELDS TERMINATED BY '|' 
(DIVISION_ID, COMPLETION_ID, DEPTH_TO_LIQ_LEVEL, TOTAL_GASEOUS_LIQ_COLUMN_HT, PRODUCING_BHP, PUMP_INTAKE_DEPTH, PUMP_INTAKE_PRESSURE, EQUIVALENT_GAS_FREE_LIQ_HT, CASING_PRESSURE, STATIC_BHP, PBHP, @FLUID_LEVEL_SURVEY_DATE)
SET FLUID_LEVEL_SURVEY_DATE = STR_TO_DATE(@FLUID_LEVEL_SURVEY_DATE, '%Y-%m-%d') """

#print(stmt)
cur.execute(stmt)
cnx.commit()


cur.close()
cnx.close()

os.remove(filename)

