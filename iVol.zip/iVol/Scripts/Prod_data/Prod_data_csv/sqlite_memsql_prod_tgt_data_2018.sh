#!/bin/sh

python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 10 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 14 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 30 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 45 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 50 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 60 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 63 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 95 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 205 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 293 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 301 2018 </dev/null >/dev/null 2>&1 &

