#!/bin/sh
echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2005.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2006.sh
until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
  sleep 5 
done

echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2007.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2008.sh
until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2009.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2010.sh
until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2011.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2012.sh
until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2013.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2014.sh
until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2015.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2016.sh
until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2017.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2018.sh
until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data_2019.sh
until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
  sleep 5
done
echo `date`

until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"| wc -l` -eq 1 ]
do
  sleep 5
done
echo `date`


exit 0

