#!/bin/sh
echo "2015-2016"
echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data_2015.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data_2016.sh
until [ `ps -ef |grep -i "sqlite_memsql_target_data"| wc -l` -eq 1 ]
do
  sleep 5 
done
echo "2017-2018"
echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data_2017.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data_2018.sh
until [ `ps -ef |grep -i "sqlite_memsql_target_data"| wc -l` -eq 1 ]
do
  sleep 5
done
echo "2019-2020"
echo `date`
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data_2019.sh
sh /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data_2020.sh
until [ `ps -ef |grep -i "sqlite_memsql_target_data_"| wc -l` -eq 1 ]
do
  sleep 5
done
echo "Checking any other process are struck"
until [ `ps -ef |grep -i "sqlite_memsql_target_data_"| wc -l` -eq 1 ]
do
  sleep 5
done
echo `date`

exit 0
