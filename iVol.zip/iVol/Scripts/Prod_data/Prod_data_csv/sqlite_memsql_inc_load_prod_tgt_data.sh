#!/bin/sh
echo `date`
echo "Deleting the records of present year and previous year"
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_inc_prod_tgt_data_del.py
echo `date`
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 10 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 14 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 30 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 50 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 60 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 63 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 95 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 293 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 301 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 45 2019 </dev/null >/dev/null 2>&1 &
until [ `ps -ef |grep -i "sqlite_memsql_prod_tgt_data"|wc -l` -eq 1 ]
do
 sleep 5
done
echo `date`
exit 0
