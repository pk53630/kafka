#!/usr/local/bin/python3
import sys
import csv
import os
import cx_Oracle
import mysql.connector
import datetime

div_id = sys.argv[1]
in_year = sys.argv[2]

query="""
SELECT  prod.division_id
      ,        prod.completion_id
      ,        prod.prod_dt date_value
      ,        prod.gross_oil_prod target_oil_prod
      ,        prod.gross_gas_prod target_gas_prod
      ,        prod.gross_water_prod target_water_prod
      FROM    odm_dba.odm_comp_target_prod_daily prod
      WHERE    prod.prod_dt BETWEEN to_date('"""+in_year+"""-01-01','YYYY-MM-DD') and to_date('"""+in_year+"""-12-31','YYYY-MM-DD') and prod.division_id="""+div_id

#print(query)

connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(query)

filename = "/home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/load_csv_sqlite_memsql_tgt_data_"+in_year+"_"+div_id+".dat"

row = cursor.fetchall()
with open(filename, 'w', newline='\n') as fp:
    a = csv.writer(fp, delimiter='|')
    a.writerows(row)

cursor.close()
connection.close()	


cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()


stmt = """ 
LOAD DATA LOCAL INFILE  
'"""+filename+"""'
INTO TABLE MRTE_DBA.GET_TARGET_DATA
FIELDS TERMINATED BY '|' 
(DIVISION_ID, COMPLETION_ID, @DATE_VALUE,TARGET_OIL_PROD,TARGET_GAS_PROD,TARGET_WATER_PROD)
SET DATE_VALUE = STR_TO_DATE(@DATE_VALUE, '%Y-%m-%d') """

#print(stmt)
cur.execute(stmt)
cnx.commit()


cur.close()
cnx.close()


os.remove(filename)
