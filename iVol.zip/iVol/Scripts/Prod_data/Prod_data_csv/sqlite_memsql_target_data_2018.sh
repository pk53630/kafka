#!/bin/sh
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data.py 10 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data.py 14 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data.py 30 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data.py 50 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data.py 60 2018 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_target_data.py 63 2018 </dev/null >/dev/null 2>&1 &
