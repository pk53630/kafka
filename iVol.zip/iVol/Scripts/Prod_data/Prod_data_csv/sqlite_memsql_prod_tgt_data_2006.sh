#!/bin/sh

python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 10 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 14 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 30 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 45 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 50 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 60 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 63 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 93 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 95 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 293 2006 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Prod_data/Prod_data_csv/sqlite_memsql_prod_tgt_data.py 301 2006 </dev/null >/dev/null 2>&1 &

