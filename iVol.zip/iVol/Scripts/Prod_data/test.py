#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re
import threading
from multiprocessing import Process

div_id = sys.argv[1]
p_low = sys.argv[2]
p_high = sys.argv[3]

query="""  select stg.division_id,
stg.completion_id,
stg.date_id,
stg.date_value,
stg.gross_gas_prod,
stg.gross_oil_prod,
stg.water_prod,
stg.gross_gas_sales,
stg.gross_oil_sales,
stg.downtime_hrs,
stg.potential_gas_prod,
stg.potential_oil_prod,
stg.potential_water_prod,
stg.forecast_gas_prod,
stg.forecast_oil_prod,
stg.forecast_water_prod,
stg.tubing_pressure,
stg.casing_pressure1,
stg.casing_pressure2,
stg.choke,
stg.comments,
stg.gas_inj,
stg.line_pressure,
stg.nri_gas,
stg.nri_oil,
stg.perc_comments_fl,
stg.aries_comments_fl,
stg.chlorides,
stg.measured_fluid_level,
stg.shot_fluid_level,
stg.measured_bhp,
stg.gas_lift_vol,
stg.h2s,
stg.water_inj,
stg.surf_casing_press,
stg.strokes,
stg.downtime_reason_key,
stg.gross_oil_beg_inv,
stg.gross_oil_end_inv,
stg.gas_flare,
stg.sc_bhp,
stg.dh_valve,
stg.c5,
stg.oil_gravity,
stg.fresh_water_inj,
stg.salt_water_inj,
stg.WATER_HAULED,
(case when stg.NRI_nri_gas is null then (select nn.nri_gas from odm_dba.odm_comp_nri nn where nn.completion_id=stg.completion_id and nn.division_id="""+str(div_id)+"""
and trunc(nn.date_value) BETWEEN to_date('"""+str(p_low)+"""','YYYY-MM-DD') and to_date('"""+str(p_high)+"""','YYYY-MM-DD')) else stg.NRI_nri_gas end) as nri_nri_gas,
(case when stg.NRI_nri_oil is null then (select nn.nri_oil from odm_dba.odm_comp_nri nn where nn.completion_id=stg.completion_id and nn.division_id="""+str(div_id)+"""
and trunc(nn.date_value) BETWEEN to_date('"""+str(p_low)+"""','YYYY-MM-DD') and to_date('"""+str(p_high)+"""','YYYY-MM-DD')) else stg.NRI_nri_oil end) as nri_nri_oil
from
(     SELECT   prod.division_id
      ,        prod.completion_id
      ,        prod.date_id
      ,        prod.date_value
      ,        prod.gross_gas_prod
      ,        prod.gross_oil_prod
      ,        prod.water_prod
      ,        gross_gas_sales
      ,        gross_oil_sales
      ,        downtime_hrs
      ,        potential_gas_prod
      ,        potential_oil_prod
      ,        potential_water_prod
      ,        forecast_gas_prod
      ,        forecast_oil_prod
      ,        forecast_water_prod
      ,        prod.tubing_pressure
      ,        prod.casing_pressure1
      ,        casing_pressure2
      ,        choke
      ,        comments
      ,        gas_inj
      ,        line_pressure
      ,        0 nri_gas
      ,        0 nri_oil
      ,        0 perc_comments_fl
      ,        0 aries_comments_fl
      ,        chlorides
      ,        measured_fluid_level
      ,        0 shot_fluid_level
      ,        measured_bhp
      ,        gas_lift_vol
      ,        h2s
      ,        water_inj
      ,        surf_casing_press
      ,        strokes
      ,        (SELECT  (INITCAP(REGEXP_REPLACE(SUBSTR(v.ref_value_key, INSTR(v.ref_value_key, '_') + 1, LENGTH(v.ref_value_key)),'_' ,' ')))
               FROM     odm_dba.odm_ref_value v
               ,        odm_dba.odm_ref_value_type vt
               WHERE    vt.ref_value_type_name = 'DOWNTIME_REASON'
               AND      vt.ref_value_type_id = v.ref_value_type_id
               AND      prod.downtime_reason_ref_id = v.ref_value_id
               and      prod.downtime_hrs > 0
               ) downtime_reason_key
      ,        gross_oil_beg_inv   
      ,        gross_oil_end_inv   
      ,        gas_flare
      ,        sc_bhp
      ,        dh_valve
      ,        c5
      ,        ROUND(oil_gravity,5) oil_gravity
      ,        fresh_water_inj
      ,        salt_water_inj
      ,        WATER_HAULED
      ,        nri.nri_gas as NRI_NRI_GAS
      ,        nri.nri_oil as NRI_NRI_OIL
      FROM     odm_dba.odm_comp_production prod
      ,        odm_dba.scada_comp_prod_daily sprod
	  , 		odm_dba.odm_comp_nri nri
      WHERE    prod.division_id = sprod.division_id(+)
      AND      prod.completion_id = sprod.completion_id(+)
      AND      prod.date_id = sprod.prod_date_id(+)
	  AND      prod.division_id = nri.division_id(+)
      AND      prod.completion_id = nri.completion_id(+)
      AND      prod.date_value = nri.date_value(+)) stg
      where    trunc(stg.date_value) BETWEEN to_date('"""+str(p_low)+"""','YYYY-MM-DD') and to_date('"""+str(p_high)+"""','YYYY-MM-DD')
      and stg.division_id ="""+str(div_id)


print(query)
