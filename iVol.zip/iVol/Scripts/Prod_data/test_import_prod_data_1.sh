#!/bin/sh

v_input="'""$1""'"

if [ $1 == 'PRD_DATA' ]
then
 v_script_nm="/home/odmbatch/iVol/Scripts/Prod_data/test_import_inc_prod_data.sh"
elif [ $1 == 'CUMM_DATA' ]
then
 v_script_nm="/home/odmbatch/iVol/Scripts/Prod_data/test_import_inc_cumm_data.sh"
fi


sqlplus -s odm_dba/R1dba_101@r1date.eogresources.com <<EOF
WHENEVER OSERROR EXIT 9;
WHENEVER SQLERROR EXIT 9;
set serveroutput off;
set echo off;
set termout off;
set feedback off;
set heading off;
set trims on;
set trimspool on;
SET WRAP ON;
SET RECSEP OFF;
set lines 32766;
set pages 0;
spool $v_script_nm;

set serveroutput on;
execute odm_dba.IN_INC_YEAR_OUT($v_input);


spool off;
exit;
EOF

chmod 755 $v_script_nm
echo "'""$v_IN_str""'"
