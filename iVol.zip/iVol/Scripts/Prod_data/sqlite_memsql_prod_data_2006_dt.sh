#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-01-01' '2006-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-02-01' '2006-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-03-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-04-01' '2006-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-05-01' '2006-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-06-01' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-07-01' '2006-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-08-01' '2006-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-09-01' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-10-01' '2006-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-11-01' '2006-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2006-12-01' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-01-01' '2006-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-02-01' '2006-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-03-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-04-01' '2006-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-05-01' '2006-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-06-01' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-07-01' '2006-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-08-01' '2006-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-09-01' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-10-01' '2006-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-11-01' '2006-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2006-12-01' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-01-01' '2006-01-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-02-01' '2006-02-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-03-01' '2006-03-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-04-01' '2006-04-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-05-01' '2006-05-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-06-01' '2006-06-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-07-01' '2006-07-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-08-01' '2006-08-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-09-01' '2006-09-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-10-01' '2006-10-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-11-01' '2006-11-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-12-01' '2006-12-15' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-01-16' '2006-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-02-16' '2006-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-03-16' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-04-16' '2006-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-05-16' '2006-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-06-16' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-07-16' '2006-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-08-16' '2006-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-09-16' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-10-16' '2006-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-11-16' '2006-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2006-12-16' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-01-01' '2006-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-02-01' '2006-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-03-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-04-01' '2006-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-05-01' '2006-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-06-01' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-07-01' '2006-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-08-01' '2006-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-09-01' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-10-01' '2006-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-11-01' '2006-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2006-12-01' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-01-01' '2006-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-02-01' '2006-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-03-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-04-01' '2006-04-02' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-04-03' '2006-04-04' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-04-05' '2006-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-05-01' '2006-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-06-01' '2006-06-02' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-06-03' '2006-06-11' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-06-12' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-07-01' '2006-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-08-01' '2006-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-09-01' '2006-09-20' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-09-21' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-10-01' '2006-10-02' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-10-03' '2006-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-11-01' '2006-11-02' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-11-03' '2006-11-17' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-11-18' '2006-11-19' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-11-20' '2006-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-12-01' '2006-12-02' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2006-12-03' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-01-01' '2006-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-02-01' '2006-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-03-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-04-01' '2006-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-05-01' '2006-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-06-01' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-07-01' '2006-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-08-01' '2006-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-09-01' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-10-01' '2006-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-11-01' '2006-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2006-12-01' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2006-01-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2006-04-01' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2006-07-01' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2006-10-01' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 93 '2006-01-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 93 '2006-04-01' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 93 '2006-07-01' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 93 '2006-10-01' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2006-01-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2006-04-01' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2006-07-01' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2006-10-01' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2006-01-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2006-04-01' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2006-07-01' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2006-10-01' '2006-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2006-01-01' '2006-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2006-04-01' '2006-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2006-07-01' '2006-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2006-10-01' '2006-12-31' </dev/null >/dev/null 2>&1 &

