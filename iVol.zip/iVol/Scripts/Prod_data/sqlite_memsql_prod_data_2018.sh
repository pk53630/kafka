#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-01-01' '2018-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-02-01' '2018-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-03-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-04-01' '2018-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-05-01' '2018-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-06-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-07-01' '2018-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-08-01' '2018-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-09-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-10-01' '2018-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-11-01' '2018-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2018-12-01' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-01-01' '2018-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-02-01' '2018-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-03-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-04-01' '2018-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-05-01' '2018-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-06-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-07-01' '2018-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-08-01' '2018-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-09-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-10-01' '2018-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-11-01' '2018-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2018-12-01' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-01-01' '2018-01-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-02-01' '2018-02-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-03-01' '2018-03-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-04-01' '2018-04-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-05-01' '2018-05-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-06-01' '2018-06-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-07-01' '2018-07-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-08-01' '2018-08-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-09-01' '2018-09-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-10-01' '2018-10-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-11-01' '2018-11-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-12-01' '2018-12-15' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-01-16' '2018-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-02-16' '2018-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-03-16' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-04-16' '2018-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-05-16' '2018-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-06-16' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-07-16' '2018-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-08-16' '2018-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-09-16' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-10-16' '2018-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-11-16' '2018-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2018-12-16' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-01-01' '2018-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-02-01' '2018-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-03-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-04-01' '2018-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-05-01' '2018-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-06-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-07-01' '2018-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-08-01' '2018-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-09-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-10-01' '2018-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-11-01' '2018-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2018-12-01' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-01-01' '2018-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-02-01' '2018-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-03-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-04-01' '2018-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-05-01' '2018-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-06-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-07-01' '2018-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-08-01' '2018-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-09-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-10-01' '2018-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-11-01' '2018-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2018-12-01' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-01-01' '2018-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-02-01' '2018-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-03-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-04-01' '2018-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-05-01' '2018-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-06-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-07-01' '2018-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-08-01' '2018-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-09-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-10-01' '2018-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-11-01' '2018-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2018-12-01' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-01-01' '2018-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-02-01' '2018-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-03-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-04-01' '2018-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-05-01' '2018-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-06-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-07-01' '2018-07-10' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-07-11' '2018-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-08-01' '2018-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-09-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-10-01' '2018-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-11-01' '2018-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2018-12-01' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2018-01-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2018-04-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2018-07-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2018-10-01' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 205 '2018-01-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 205 '2018-04-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 205 '2018-07-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 205 '2018-10-01' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2018-01-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2018-04-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2018-07-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2018-10-01' '2018-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2018-01-01' '2018-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2018-04-01' '2018-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2018-07-01' '2018-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2018-10-01' '2018-12-31' </dev/null >/dev/null 2>&1 &
