#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-01-01' '2017-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-02-01' '2017-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-03-01' '2017-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-04-01' '2017-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-05-01' '2017-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-06-01' '2017-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-07-01' '2017-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-08-01' '2017-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-09-01' '2017-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-10-01' '2017-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-11-01' '2017-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2017-12-01' '2017-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-01-01' '2017-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-02-01' '2017-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-03-01' '2017-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-04-01' '2017-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-05-01' '2017-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-06-01' '2017-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-07-01' '2017-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-08-01' '2017-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-09-01' '2017-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-10-01' '2017-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-11-01' '2017-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2017-12-01' '2017-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2017-01-01' '2017-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2017-04-01' '2017-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2017-07-01' '2017-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2017-10-01' '2017-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 205 '2017-01-01' '2017-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 205 '2017-04-01' '2017-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 205 '2017-07-01' '2017-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 205 '2017-10-01' '2017-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2017-01-01' '2017-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2017-04-01' '2017-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2017-07-01' '2017-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2017-10-01' '2017-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2017-01-01' '2017-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2017-04-01' '2017-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2017-07-01' '2017-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2017-10-01' '2017-12-31' </dev/null >/dev/null 2>&1 &

