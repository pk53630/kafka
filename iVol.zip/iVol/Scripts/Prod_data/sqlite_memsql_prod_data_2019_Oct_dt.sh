#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-01-01' '2019-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-02-01' '2019-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-03-01' '2019-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-04-01' '2019-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-05-01' '2019-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-06-01' '2019-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-07-01' '2019-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-08-01' '2019-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-09-01' '2019-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 10 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-01-01' '2019-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-02-01' '2019-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-03-01' '2019-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-04-01' '2019-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-05-01' '2019-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-06-01' '2019-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-07-01' '2019-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-08-01' '2019-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-09-01' '2019-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 14 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-01-01' '2019-01-12' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-02-01' '2019-02-12' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-03-01' '2019-03-12' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-04-01' '2019-04-12' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-05-01' '2019-05-12' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-06-01' '2019-06-12' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-07-01' '2019-07-12' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-08-01' '2019-08-12' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-09-01' '2019-09-12' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 30 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-01-01' '2019-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-02-01' '2019-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-03-01' '2019-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-04-01' '2019-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-05-01' '2019-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-06-01' '2019-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-07-01' '2019-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-08-01' '2019-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-09-01' '2019-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 45 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-02-01' '2019-02-04' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-02-05' '2019-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-03-01' '2019-03-22' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-03-23' '2019-03-27' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-03-28' '2019-03-29' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-03-30' '2019-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-06-01' '2019-06-02' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-06-03' '2019-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-08-01' '2019-08-02' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-08-03' '2019-08-03' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-08-04' '2019-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-01-01' '2019-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-04-01' '2019-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-05-01' '2019-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-07-01' '2019-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-09-01' '2019-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 50 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-01-01' '2019-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-02-01' '2019-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-03-01' '2019-03-10' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-03-11' '2019-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-04-01' '2019-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-05-01' '2019-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-06-01' '2019-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-07-01' '2019-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-08-01' '2019-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-09-01' '2019-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 60 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-01-01' '2019-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-02-01' '2019-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-03-01' '2019-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-04-01' '2019-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-05-01' '2019-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-06-01' '2019-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-07-01' '2019-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-08-01' '2019-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-09-01' '2019-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 63 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2019-01-01' '2019-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2019-04-01' '2019-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2019-07-01' '2019-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 95 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2019-01-01' '2019-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2019-04-01' '2019-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2019-07-01' '2019-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 293 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-01-01' '2019-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-02-01' '2019-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-03-01' '2019-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-04-01' '2019-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-05-01' '2019-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-06-01' '2019-06-05' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-06-06' '2019-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-07-01' '2019-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-08-01' '2019-08-13' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-08-14' '2019-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-09-01' '2019-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2019-10-01' '2019-10-10' </dev/null >/dev/null 2>&1 &
