#!/bin/sh

present_yr=`date +"%Y"`
previou_yr=`expr $present_yr - 1`
v_inc_file_nm='/home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_inc_load_sqlite_memsql_cumm_data.sh'
v_pyscript_nm='python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py '
v_nullify_war=' </dev/null >/dev/null 2>&1 &'

echo '#!/usr/sh' > $v_inc_file_nm
echo 'echo `date`' >> $v_inc_file_nm
echo 'echo "Deleting the records of present year and previous year"' >> $v_inc_file_nm
echo 'python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_cumm_data_del.py' >> $v_inc_file_nm
echo 'echo `date`' >> $v_inc_file_nm

v_present_yr_div_id=`sqlplus -s odm_dba/R1dba_101@r1date.eogresources.com <<EOF
WHENEVER OSERROR EXIT 9;
WHENEVER SQLERROR EXIT 9;
set serveroutput off;
set echo off;
set termout off;
set feedback off;
set heading off;
set trims on;
set trimspool on;
SET WRAP ON;
SET RECSEP OFF;
set lines 32766;
set pages 0;
select distinct division_id from odm_dba.odm_comp_prod_dly_drv where to_char(date_value,'YYYY') = $present_yr;
exit;
EOF`

for i in $v_present_yr_div_id
do
echo $v_pyscript_nm$i" "$present_yr$v_nullify_war >> $v_inc_file_nm
done

v_prev_yr_div_id=`sqlplus -s odm_dba/R1dba_101@r1date.eogresources.com <<EOF
WHENEVER OSERROR EXIT 9;
WHENEVER SQLERROR EXIT 9;
set serveroutput off;
set echo off;
set termout off;
set feedback off;
set heading off;
set trims on;
set trimspool on;
SET WRAP ON;
SET RECSEP OFF;
set lines 32766;
set pages 0;
select distinct division_id from odm_dba.odm_comp_prod_dly_drv where to_char(date_value,'YYYY') = $previou_yr;
exit;
EOF`

for i in $v_prev_yr_div_id
do
echo $v_pyscript_nm$i" "$previou_yr$v_nullify_war >> $v_inc_file_nm
done

echo 'until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"|wc -l` -eq 1 ]' >> $v_inc_file_nm
echo 'do' >> $v_inc_file_nm
echo ' sleep 5' >> $v_inc_file_nm
echo 'done' >> $v_inc_file_nm
echo 'echo `date`' >> $v_inc_file_nm
echo 'exit 0' >> $v_inc_file_nm

exit 0
