#!/usr/bin/python3
import sys
import csv
import os
import cx_Oracle
import mysql.connector
import datetime

div_id = sys.argv[1]
in_year = sys.argv[2]

query="""
SELECT   prod.division_id
      ,        prod.completion_id
      ,        prod.date_id
      ,        prod.date_value
      ,        prod.gross_gas_prod
      ,        prod.gross_oil_prod
      ,        prod.water_prod
      ,        prod.gross_gas_sales
      ,        prod.gross_oil_sales
      ,        prod.downtime_hrs
      ,        prod.potential_gas_prod
      ,        prod.potential_oil_prod
      ,        prod.potential_water_prod
      ,        prod.forecast_gas_prod
      ,        prod.forecast_oil_prod
      ,        prod.forecast_water_prod
      ,        prod.tubing_pressure
      ,        prod.casing_pressure1
      ,        prod.casing_pressure2
      ,        replace(replace(replace(prod.choke,chr(13),' '),chr(10),' '),chr(92),'') as choke
      ,        replace(replace(replace(prod.comments,chr(13),' '),chr(10),' '),chr(92),'') as comments
      ,        prod.gas_inj
      ,        prod.line_pressure
      ,        0 nri_gas
      ,        0 nri_oil
      ,        0 perc_comments_fl
      ,        0 aries_comments_fl
      ,        prod.chlorides
      ,        prod.measured_fluid_level
      ,        0 shot_fluid_level
      ,        prod.measured_bhp
      ,        prod.gas_lift_vol
      ,        prod.h2s
      ,        prod.water_inj
      ,        prod.surf_casing_press
      ,        prod.strokes
      ,        replace(replace(replace((SELECT  (INITCAP(REGEXP_REPLACE(SUBSTR(v.ref_value_key, INSTR(v.ref_value_key, '_') + 1, LENGTH(v.ref_value_key)),'_' ,' ')))
               FROM     odm_dba.odm_ref_value v
               ,        odm_dba.odm_ref_value_type vt
               WHERE    vt.ref_value_type_name = 'DOWNTIME_REASON'
               AND      vt.ref_value_type_id = v.ref_value_type_id
               AND      prod.downtime_reason_ref_id = v.ref_value_id
               and      prod.downtime_hrs > 0
               ),chr(13),' '),chr(10),' '),chr(92),'') as downtime_reason_key
      ,        prod.gross_oil_beg_inv   
      ,        prod.gross_oil_end_inv   
      ,        prod.gas_flare
      ,        sprod.sc_bhp
      ,        sprod.dh_valve
      ,        prod.c5
      ,        ROUND(prod.oil_gravity,5) as oil_gravity
      ,        prod.fresh_water_inj
      ,        prod.salt_water_inj
      ,        prod.WATER_HAULED
      ,   (case when prod.nri_gas is null then (select nn.nri_gas from odm_dba.odm_comp_nri nn where nn.completion_id=prod.completion_id and nn.division_id="""+str(div_id)+""" order by nn.date_value desc fetch first 1 rows only ) else prod.nri_gas end) as nri_nri_gas
      ,   (case when prod.nri_oil is null then (select nn.nri_oil from odm_dba.odm_comp_nri nn where nn.completion_id=prod.completion_id and nn.division_id="""+str(div_id)+""" order by nn.date_value desc fetch first 1 rows only ) else prod.nri_oil end) as nri_nri_oil
      ,        prod1.gross_oil_prod as tgt_gross_oil_prod
      ,        prod1.gross_gas_prod  as tgt_gross_gas_prod
      ,        prod1.gross_water_prod as tgt_gross_water_prod
      FROM     odm_dba.odm_comp_production prod
      ,        odm_dba.scada_comp_prod_daily sprod
      ,        odm_dba.odm_comp_target_prod_daily prod1
      ,        odm_dba.odm_comp_nri nri
      WHERE    prod.division_id = sprod.division_id(+)
      AND      prod.completion_id = sprod.completion_id(+)
      AND      prod.date_id = sprod.prod_date_id(+)
      and      prod.division_id = prod1.division_id(+)
      and      prod.completion_id = prod1.completion_id(+)
      and      prod.date_value = prod1.prod_dt(+)
      AND      prod.division_id = nri.division_id(+)
      AND      prod.completion_id = nri.completion_id(+)
      AND      prod.date_value = nri.date_value(+)
      and prod.date_value BETWEEN to_date('"""+in_year+"""-01-01','YYYY-MM-DD') and to_date('"""+in_year+"""-12-31','YYYY-MM-DD')
      --and prod.completion_id = 120462
      --and prod.date_value = '2014-09-09'
      and prod.division_id="""+div_id


#print(query)

connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(query)

filename = "/home/odmbatch/iVol/Scripts/Prod_data/load_csv_sqlite_memsql_prod_tgt_data_"+in_year+"_"+div_id+".csv"

row = cursor.fetchall()
with open(filename, 'w', newline='\n') as fp:
    a = csv.writer(fp, delimiter='|')
    a.writerows(row)

cursor.close()
connection.close()	


cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()


stmt = """ 
LOAD DATA LOCAL INFILE  
'"""+filename+"""'
INTO TABLE MRTE_DBA.GET_PROD_DATA_TEST_1
FIELDS TERMINATED BY '|' 
(DIVISION_ID,COMPLETION_ID,DATE_ID,@DATE_VALUE,GROSS_GAS_PROD,GROSS_OIL_PROD,WATER_PROD,GROSS_GAS_SALES,GROSS_OIL_SALES,DOWNTIME_HRS,POTENTIAL_GAS_PROD,POTENTIAL_OIL_PROD,POTENTIAL_WATER_PROD,FORECAST_GAS_PROD,FORECAST_OIL_PROD,FORECAST_WATER_PROD,TUBING_PRESSURE,CASING_PRESSURE1,CASING_PRESSURE2,CHOKE,COMMENTS,GAS_INJ,LINE_PRESSURE,NRI_GAS,NRI_OIL,PERC_COMMENTS_FL,ARIES_COMMENTS_FL,CHLORIDES,MEASURED_FLUID_LEVEL,SHOT_FLUID_LEVEL,MEASURED_BHP,GAS_LIFT_VOL,H2S,WATER_INJ,SURF_CASING_PRESS,STROKES,DOWNTIME_REASON_KEY,GROSS_OIL_BEG_INV,GROSS_OIL_END_INV,GAS_FLARE,SC_BHP,DH_VALVE,C5,OIL_GRAVITY,FRESH_WATER_INJ,SALT_WATER_INJ,WATER_HAULED,NRI_NRI_GAS,NRI_NRI_OIL,TARGET_OIL_PROD,TARGET_GAS_PROD,TARGET_WATER_PROD)
SET DATE_VALUE = STR_TO_DATE(@DATE_VALUE, '%Y-%m-%d') """

#print(stmt)
cur.execute(stmt)
cnx.commit()


cur.close()
cnx.close()


