#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re
import threading
from multiprocessing import Process

div_id = sys.argv[1]
p_low = sys.argv[2]
p_high = sys.argv[3]

def get_cumm_date(p_low, p_high):
    query="""  select 
 stg.division_id,
 stg.completion_id,
 stg.date_id,
 stg.date_value,
 stg.gross_gas_prod,
 stg.gross_oil_prod,
 stg.water_prod,
 stg.gross_gas_sales,
 stg.gross_oil_sales,
 stg.downtime_hrs,
 stg.potential_gas_prod,
 stg.potential_oil_prod,
 stg.potential_water_prod,
 stg.forecast_gas_prod,
 stg.forecast_oil_prod,
 stg.forecast_water_prod,
 stg.tubing_pressure,
 stg.casing_pressure1,
 stg.casing_pressure2,
 stg.choke,
 stg.comments,
 stg.gas_inj,
 stg.line_pressure,
 stg.nri_gas,
 stg.nri_oil,
 stg.perc_comments_fl,
 stg.aries_comments_fl,
 stg.chlorides,
 stg.measured_fluid_level,
 stg.shot_fluid_level,
 stg.measured_bhp,
 stg.gas_lift_vol,
 stg.h2s,
 stg.water_inj,
 stg.surf_casing_press,
 stg.strokes,
 stg.downtime_reason_key,
 stg.gross_oil_beg_inv,
 stg.gross_oil_end_inv,
 stg.gas_flare,
 stg.sc_bhp,
 stg.dh_valve,
 stg.c5,
 stg.oil_gravity,
 stg.fresh_water_inj,
 stg.salt_water_inj,
 stg.WATER_HAULED,
 (case when stg.NRI_nri_gas is null then (select nn.nri_gas from odm_dba.odm_comp_nri nn where nn.completion_id=stg.completion_id and nn.division_id="""+str(div_id)+"""
 order by nn.date_value desc fetch first 1 rows only ) else stg.NRI_nri_gas end) as nri_nri_gas,
 (case when stg.NRI_nri_oil is null then (select nn.nri_oil from odm_dba.odm_comp_nri nn where nn.completion_id=stg.completion_id and nn.division_id="""+str(div_id)+"""
 order by nn.date_value desc fetch first 1 rows only ) else stg.NRI_nri_oil end) as nri_nri_oil,
 prod.gross_oil_prod as target_oil_prod,        
 prod.gross_gas_prod as target_gas_prod,
 prod.gross_water_prod as target_water_prod
from
(     SELECT   prod.division_id
      ,        prod.completion_id
      ,        prod.date_id
      ,        prod.date_value
      ,        prod.gross_gas_prod
      ,        prod.gross_oil_prod
      ,        prod.water_prod
      ,        gross_gas_sales
      ,        gross_oil_sales
      ,        downtime_hrs
      ,        potential_gas_prod
      ,        potential_oil_prod
      ,        potential_water_prod
      ,        forecast_gas_prod
      ,        forecast_oil_prod
      ,        forecast_water_prod
      ,        prod.tubing_pressure
      ,        prod.casing_pressure1
      ,        casing_pressure2
      ,        choke
      ,        comments
      ,        gas_inj
      ,        line_pressure
      ,        0 nri_gas
      ,        0 nri_oil
      ,        0 perc_comments_fl
      ,        0 aries_comments_fl
      ,        chlorides
      ,        measured_fluid_level
      ,        0 shot_fluid_level
      ,        measured_bhp
      ,        gas_lift_vol
      ,        h2s
      ,        water_inj
      ,        surf_casing_press
      ,        strokes
      ,        (SELECT  (INITCAP(REGEXP_REPLACE(SUBSTR(v.ref_value_key, INSTR(v.ref_value_key, '_') + 1, LENGTH(v.ref_value_key)),'_' ,' ')))
               FROM     odm_dba.odm_ref_value v
               ,        odm_dba.odm_ref_value_type vt
               WHERE    vt.ref_value_type_name = 'DOWNTIME_REASON'
               AND      vt.ref_value_type_id = v.ref_value_type_id
               AND      prod.downtime_reason_ref_id = v.ref_value_id
               and      prod.downtime_hrs > 0
               ) downtime_reason_key
      ,        gross_oil_beg_inv   
      ,        gross_oil_end_inv   
      ,        gas_flare
      ,        sc_bhp
      ,        dh_valve
      ,        c5
      ,        ROUND(oil_gravity,5) oil_gravity
      ,        fresh_water_inj
      ,        salt_water_inj
      ,        WATER_HAULED
      ,        nri.nri_gas as NRI_NRI_GAS
      ,        nri.nri_oil as NRI_NRI_OIL
      FROM     odm_dba.odm_comp_production prod
      ,        odm_dba.scada_comp_prod_daily sprod
	  , 		odm_dba.odm_comp_nri nri
      WHERE    prod.division_id = sprod.division_id(+)
      AND      prod.completion_id = sprod.completion_id(+)
      AND      prod.date_id = sprod.prod_date_id(+)
	  AND      prod.division_id = nri.division_id(+)
      AND      prod.completion_id = nri.completion_id(+)
      AND      prod.date_value = nri.date_value(+)) stg, odm_dba.odm_comp_target_prod_daily prod
    where stg.division_id = prod.division_id(+)
      and stg.completion_id = prod.completion_id(+)
      and stg.date_value = prod.prod_dt(+)
      and stg.division_id ="""+str(div_id)+"""	  
      and trunc(stg.date_value) BETWEEN to_date('"""+str(p_low)+"""','YYYY-MM-DD') and to_date('"""+str(p_high)+"""','YYYY-MM-DD')"""


    #print(query)

    stmt1 = """INSERT INTO MRTE_DBA.GET_PROD_DATA_TEST
    (DIVISION_ID, COMPLETION_ID, DATE_ID, DATE_VALUE, GROSS_GAS_PROD, GROSS_OIL_PROD, WATER_PROD, GROSS_GAS_SALES, GROSS_OIL_SALES, DOWNTIME_HRS, POTENTIAL_GAS_PROD, POTENTIAL_OIL_PROD, POTENTIAL_WATER_PROD, FORECAST_GAS_PROD, FORECAST_OIL_PROD, FORECAST_WATER_PROD, TUBING_PRESSURE, CASING_PRESSURE1, CASING_PRESSURE2, CHOKE, COMMENTS, GAS_INJ, LINE_PRESSURE, 
    NRI_GAS, NRI_OIL, PERC_COMMENTS_FL, ARIES_COMMENTS_FL, CHLORIDES, MEASURED_FLUID_LEVEL, SHOT_FLUID_LEVEL, MEASURED_BHP, GAS_LIFT_VOL, H2S, WATER_INJ, SURF_CASING_PRESS, STROKES, DOWNTIME_REASON_KEY, GROSS_OIL_BEG_INV, GROSS_OIL_END_INV, GAS_FLARE, SC_BHP, DH_VALVE, C5, OIL_GRAVITY, FRESH_WATER_INJ, SALT_WATER_INJ, WATER_HAULED,NRI_NRI_GAS, NRI_NRI_OIL,TARGET_OIL_PROD,TARGET_GAS_PROD,TARGET_WATER_PROD)
    VALUES
    (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
#    print(stmt1)
    connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
    cursor = cx_Oracle.Cursor(connection)
    cursor.execute(query)

    data_list=[]
    for row in cursor.fetchall():
        data_list.append(list(row))
    #print(data_list)
	
    cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
    cur = cnx.cursor()

    for k in range(0,len(data_list)):
        cur.execute(stmt1,data_list[k])

    cnx.commit()

    cur.close()
    cnx.close()

    cursor.close()
    connection.close()


if __name__=='__main__':
    p1 = Process(target = get_cumm_date(p_low,p_high))
    p1.start()
    # This is where I had to add the join() function.
    p1.join()
