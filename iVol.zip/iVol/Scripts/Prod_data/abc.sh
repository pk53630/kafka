#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-01-01' '2016-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-02-01' '2016-02-29' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-03-01' '2016-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-04-01' '2016-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-05-01' '2016-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-06-01' '2016-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-07-01' '2016-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-08-01' '2016-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-09-01' '2016-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-10-01' '2016-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-11-01' '2016-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Prod_data/sqlite_memsql_prod_data.py 301 '2016-12-01' '2016-12-31' </dev/null >/dev/null 2>&1 &

