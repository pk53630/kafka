#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 10 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 14 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 30 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 45 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 50 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 60 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 63 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 93 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 94 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 95 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 144 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 147 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 205 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 293 </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/sqlite_memsql_attribute_data.py 301 </dev/null >/dev/null 2>&1 &
