#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re
import threading
from multiprocessing import Process

div_id = sys.argv[1]

def get_cumm_date(p_low, p_high):
    query=""" SELECT   
               drv.division_id
      ,        drv.completion_id
      ,        drv.date_id
      ,        drv.date_value
      ,        drv.cum_gross_gas_prod gross_gas_prod
      ,        drv.cum_gross_oil_prod gross_oil_prod
      ,        drv.cum_water_prod water_prod
      ,        drv.cum_gross_gas_sales gross_gas_sales
      ,        drv.cum_gross_oil_sales gross_oil_sales
      ,        drv.cum_downtime_hrs downtime_hrs
      ,        drv.cum_potn_gas_prod potential_gas_prod
      ,        drv.cum_potn_oil_prod potential_oil_prod
      ,        drv.cum_potn_water_prod potential_water_prod
      ,        drv.cum_fcst_gas_prod forecast_gas_prod
      ,        drv.cum_fcst_oil_prod forecast_oil_prod
      ,        drv.cum_fcst_water_prod forecast_water_prod
      ,        drv.cum_missed_gas cum_missed_gas
      ,        drv.cum_missed_oil cum_missed_oil
      ,        drv.cum_missed_water cum_missed_water
      ,        drv.cum_lost_gas cum_lost_gas
      ,        drv.cum_lost_oil cum_lost_oil
      ,        drv.cum_lost_water cum_lost_water
      ,        drv.avg_30d_gross_gas_prod
      ,        drv.avg_30d_gross_gas_sales
      ,        drv.avg_30d_gross_oil_prod
      ,        drv.avg_30d_gross_oil_sales
      ,        drv.avg_30d_water_prod
      ,        drv.avg_30d_water_sales
      ,        drv.avg_60d_gross_gas_prod
      ,        drv.avg_60d_gross_gas_sales
      ,        drv.avg_60d_gross_oil_prod
      ,        drv.avg_60d_gross_oil_sales
      ,        drv.avg_60d_water_prod
      ,        drv.avg_60d_water_sales
      ,        drv.avg_7d_gross_gas_prod
      ,        drv.avg_7d_gross_gas_sales
      ,        drv.avg_7d_gross_oil_prod
      ,        drv.avg_7d_gross_oil_sales
      ,        drv.avg_7d_water_prod
      ,        drv.avg_7d_water_sales
      ,        drv.avg_90d_gross_gas_prod
      ,        drv.avg_90d_gross_gas_sales
      ,        drv.avg_90d_gross_oil_prod
      ,        drv.avg_90d_gross_oil_sales
      ,        drv.avg_90d_water_prod
      ,        drv.avg_90d_water_sales
      ,        drv.cmavg_7d_gross_gas_prod
      ,        drv.cmavg_7d_gross_gas_sales
      ,        drv.cmavg_7d_gross_oil_prod
      ,        drv.cmavg_7d_gross_oil_sales
      ,        drv.cmavg_7d_water_prod
      ,        drv.cmavg_7d_water_sales
      ,        drv.mtd_gross_gas_prod
      ,        drv.mtd_gross_gas_sales
      ,        drv.mtd_gross_oil_prod
      ,        drv.mtd_gross_oil_sales
      ,        drv.mtd_water_prod
      ,        drv.mtd_water_sales
      ,        drv.load_water_rem
      ,        drv.load_water_pct
      FROM     odm_dba.odm_comp_prod_dly_drv drv
      WHERE    trunc(drv.date_value) BETWEEN to_date('"""+str(p_low)+"""','YYYY-MM-DD') and to_date('"""+str(p_high)+"""','YYYY-MM-DD')      
      and drv.division_id ="""+str(div_id)
    print(query)
    stmt1 = """INSERT INTO MRTE_DBA.GET_CUMM_PROD_DATA
    (DIVISION_ID, COMPLETION_ID, DATE_ID, DATE_VALUE, GROSS_GAS_PROD, GROSS_OIL_PROD, WATER_PROD, GROSS_GAS_SALES, GROSS_OIL_SALES, DOWNTIME_HRS, POTENTIAL_GAS_PROD, POTENTIAL_OIL_PROD, POTENTIAL_WATER_PROD, FORECAST_GAS_PROD, FORECAST_OIL_PROD, FORECAST_WATER_PROD, CUM_MISSED_GAS, CUM_MISSED_OIL, CUM_MISSED_WATER, CUM_LOST_GAS, CUM_LOST_OIL, CUM_LOST_WATER, AVG_30D_GROSS_GAS_PROD, AVG_30D_GROSS_GAS_SALES, AVG_30D_GROSS_OIL_PROD, AVG_30D_GROSS_OIL_SALES, AVG_30D_WATER_PROD, AVG_30D_WATER_SALES, AVG_60D_GROSS_GAS_PROD, AVG_60D_GROSS_GAS_SALES, AVG_60D_GROSS_OIL_PROD, AVG_60D_GROSS_OIL_SALES, AVG_60D_WATER_PROD, 
    AVG_60D_WATER_SALES, AVG_7D_GROSS_GAS_PROD, AVG_7D_GROSS_GAS_SALES, AVG_7D_GROSS_OIL_PROD, AVG_7D_GROSS_OIL_SALES, AVG_7D_WATER_PROD, AVG_7D_WATER_SALES, AVG_90D_GROSS_GAS_PROD, AVG_90D_GROSS_GAS_SALES, AVG_90D_GROSS_OIL_PROD, AVG_90D_GROSS_OIL_SALES, AVG_90D_WATER_PROD, AVG_90D_WATER_SALES, CMAVG_7D_GROSS_GAS_PROD, CMAVG_7D_GROSS_GAS_SALES, CMAVG_7D_GROSS_OIL_PROD, CMAVG_7D_GROSS_OIL_SALES, CMAVG_7D_WATER_PROD, CMAVG_7D_WATER_SALES, MTD_GROSS_GAS_PROD, MTD_GROSS_GAS_SALES, MTD_GROSS_OIL_PROD, MTD_GROSS_OIL_SALES, MTD_WATER_PROD, MTD_WATER_SALES, LOAD_WATER_REM, LOAD_WATER_PCT)
    VALUES
    (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
    print(stmt1)
    connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
    cursor = cx_Oracle.Cursor(connection)
    cursor.execute(query)

    data_list=[]
    for row in cursor.fetchall():
        data_list.append(list(row))
    #print(data_list)
	
    cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
    cur = cnx.cursor()

    for k in range(0,len(data_list)):
        cur.execute(stmt1,data_list[k])

    cnx.commit()

    cur.close()
    cnx.close()

    cursor.close()
    connection.close()

if __name__=='__main__':
    p1 = Process(target = get_cumm_date('2015-07-01','2015-09-30'))
    p1.start()
    p2 = Process(target = get_cumm_date('2016-07-01','2016-09-30'))
    p2.start()
    # This is where I had to add the join() function.
    p1.join()
    p2.join()
	
