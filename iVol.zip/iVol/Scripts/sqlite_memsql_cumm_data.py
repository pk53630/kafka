#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re
import threading
from multiprocessing import Process


div_id = sys.argv[1]
#pwd = sys.argv[1]
#sid = sys.argv[1]

dt=arrow.now().format('YYYY-MM-DD')
filename="""/home/odmbatch/odm/logs/get_cumm_data_"""+dt+""".log"""

my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    #print("file is not present")
    Path(filename).touch()


log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("########################################### NRI DATA EXTACTION STARTED #########################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")

low_value=50
high_value=0

# sysdate and sysdate-50        low_value 50 - high_value 1
# sysdate-51 and sysdate-100    low_value 100 - high_value 51
# sysdate-101 and sysdate-150   low_value 150 - high_value 101
# sysdate-151 and sysdate-200   low_value 200 - high_value 151
# sysdate-201 and sysdate-250   low_value 250 - high_value 201
# sysdate-251 and sysdate-300   low_value 300 - high_value 251
# sysdate-301 and sysdate-365   low_value 365 - high_value 301

query=""" SELECT   drv.division_id
      ,        drv.completion_id
      ,        drv.date_id
      ,        drv.date_value
      ,        drv.cum_gross_gas_prod gross_gas_prod
      ,        drv.cum_gross_oil_prod gross_oil_prod
      ,        drv.cum_water_prod water_prod
      ,        drv.cum_gross_gas_sales gross_gas_sales
      ,        drv.cum_gross_oil_sales gross_oil_sales
      ,        drv.cum_downtime_hrs downtime_hrs
      ,        drv.cum_potn_gas_prod potential_gas_prod
      ,        drv.cum_potn_oil_prod potential_oil_prod
      ,        drv.cum_potn_water_prod potential_water_prod
      ,        drv.cum_fcst_gas_prod forecast_gas_prod
      ,        drv.cum_fcst_oil_prod forecast_oil_prod
      ,        drv.cum_fcst_water_prod forecast_water_prod
      ,        drv.cum_missed_gas cum_missed_gas
      ,        drv.cum_missed_oil cum_missed_oil
      ,        drv.cum_missed_water cum_missed_water
      ,        drv.cum_lost_gas cum_lost_gas
      ,        drv.cum_lost_oil cum_lost_oil
      ,        drv.cum_lost_water cum_lost_water
      ,        drv.avg_30d_gross_gas_prod
      ,        drv.avg_30d_gross_gas_sales
      ,        drv.avg_30d_gross_oil_prod
      ,        drv.avg_30d_gross_oil_sales
      ,        drv.avg_30d_water_prod
      ,        drv.avg_30d_water_sales
      ,        drv.avg_60d_gross_gas_prod
      ,        drv.avg_60d_gross_gas_sales
      ,        drv.avg_60d_gross_oil_prod
      ,        drv.avg_60d_gross_oil_sales
      ,        drv.avg_60d_water_prod
      ,        drv.avg_60d_water_sales
      ,        drv.avg_7d_gross_gas_prod
      ,        drv.avg_7d_gross_gas_sales
      ,        drv.avg_7d_gross_oil_prod
      ,        drv.avg_7d_gross_oil_sales
      ,        drv.avg_7d_water_prod
      ,        drv.avg_7d_water_sales
      ,        drv.avg_90d_gross_gas_prod
      ,        drv.avg_90d_gross_gas_sales
      ,        drv.avg_90d_gross_oil_prod
      ,        drv.avg_90d_gross_oil_sales
      ,        drv.avg_90d_water_prod
      ,        drv.avg_90d_water_sales
      ,        drv.cmavg_7d_gross_gas_prod
      ,        drv.cmavg_7d_gross_gas_sales
      ,        drv.cmavg_7d_gross_oil_prod
      ,        drv.cmavg_7d_gross_oil_sales
      ,        drv.cmavg_7d_water_prod
      ,        drv.cmavg_7d_water_sales
      ,        drv.mtd_gross_gas_prod
      ,        drv.mtd_gross_gas_sales
      ,        drv.mtd_gross_oil_prod
      ,        drv.mtd_gross_oil_sales
      ,        drv.mtd_water_prod
      ,        drv.mtd_water_sales
      ,        drv.load_water_rem
      ,        drv.load_water_pct
      FROM     odm_dba.odm_comp_prod_dly_drv drv
      WHERE    drv.date_value BETWEEN trunc(sysdate)-"""+str(low_value)+""" AND trunc(sysdate)-"""+str(high_value)+"""
      and drv.division_id ="""+str(div_id)

connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(query)

data_list=[]
column_names =[]

for i in cursor.description:
    column_names.append(i[0])
for row in cursor.fetchall():
    data_list.append(list(row))

cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()

logger.info("                                                                                                                ")
logger.info("                                                                                                                ")
logger.info("###################################### Insert Statement STARTED Execution ######################################")
stmt1 = """INSERT INTO MRTE_DBA.GET_CUMM_PROD_DATA
(DIVISION_ID, COMPLETION_ID, DATE_ID, DATE_VALUE, GROSS_GAS_PROD, GROSS_OIL_PROD, WATER_PROD, GROSS_GAS_SALES, GROSS_OIL_SALES, DOWNTIME_HRS, POTENTIAL_GAS_PROD, POTENTIAL_OIL_PROD, POTENTIAL_WATER_PROD, FORECAST_GAS_PROD, FORECAST_OIL_PROD, FORECAST_WATER_PROD, CUM_MISSED_GAS, CUM_MISSED_OIL, CUM_MISSED_WATER, CUM_LOST_GAS, CUM_LOST_OIL, CUM_LOST_WATER, AVG_30D_GROSS_GAS_PROD, AVG_30D_GROSS_GAS_SALES, AVG_30D_GROSS_OIL_PROD, AVG_30D_GROSS_OIL_SALES, AVG_30D_WATER_PROD, AVG_30D_WATER_SALES, AVG_60D_GROSS_GAS_PROD, AVG_60D_GROSS_GAS_SALES, AVG_60D_GROSS_OIL_PROD, AVG_60D_GROSS_OIL_SALES, AVG_60D_WATER_PROD, 
AVG_60D_WATER_SALES, AVG_7D_GROSS_GAS_PROD, AVG_7D_GROSS_GAS_SALES, AVG_7D_GROSS_OIL_PROD, AVG_7D_GROSS_OIL_SALES, AVG_7D_WATER_PROD, AVG_7D_WATER_SALES, AVG_90D_GROSS_GAS_PROD, AVG_90D_GROSS_GAS_SALES, AVG_90D_GROSS_OIL_PROD, AVG_90D_GROSS_OIL_SALES, AVG_90D_WATER_PROD, AVG_90D_WATER_SALES, CMAVG_7D_GROSS_GAS_PROD, CMAVG_7D_GROSS_GAS_SALES, CMAVG_7D_GROSS_OIL_PROD, CMAVG_7D_GROSS_OIL_SALES, CMAVG_7D_WATER_PROD, CMAVG_7D_WATER_SALES, MTD_GROSS_GAS_PROD, MTD_GROSS_GAS_SALES, MTD_GROSS_OIL_PROD, MTD_GROSS_OIL_SALES, MTD_WATER_PROD, MTD_WATER_SALES, LOAD_WATER_REM, LOAD_WATER_PCT) 
VALUES
(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""

#cur.executemany(stmt1, data_list)
for k in range(0,len(data_list)):
    #print(len(data_list))
    cur.execute(stmt1,data_list[k])
    #cur.execute(stmt1,data_list[1])



cnx.commit()
#logger.debug("Inserted Well ID are %s",data_list)
logger.info("###################################### Insert Statement COMPLETED Execution ####################################")
logger.info("                                                                                                                ")
cur.close()
cnx.close()

cursor.close()
connection.close()

logger.info("################################################################################################################")
logger.info("##################################### ODM WELL DELTA EXTACTION COMPLETED #######################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")
logger.info("                                                                                                                ")

