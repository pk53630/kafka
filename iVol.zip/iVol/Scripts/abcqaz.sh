#!/usr/sh

min_yr=2005
present_yr=`date +"%Y"`

num_yr=`expr $present_yr - $min_yr`

echo '#!/usr/sh' > /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
echo 'echo "Delete GET_NON_PREV_CUMM_DATA table"' >> /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
echo 'echo `date`' >> /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
echo 'python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA_del.py' >> /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh

while [[ $min_yr -le $present_yr ]]
do
 echo 'echo "'"$min_yr"'"' >>/home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
 echo 'echo `date`' >>/home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
 echo "python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py "$min_yr >> /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
 echo 'until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]' >>/home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
 echo 'do' >>/home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
 echo '  sleep 5' >>/home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
 echo 'done' >>/home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
 echo '' >> /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
 min_yr=`expr $min_yr + 1`
done
echo 'exit 0' >> /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh
chmod 755 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_inc_load_GET_NON_PREV_CUMM_DATA.sh

