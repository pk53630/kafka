#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-01-01' '2013-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-02-01' '2013-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-03-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-04-01' '2013-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-05-01' '2013-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-06-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-07-01' '2013-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-08-01' '2013-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-09-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-10-01' '2013-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-11-01' '2013-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2013-12-01' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-01-01' '2013-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-02-01' '2013-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-03-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-04-01' '2013-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-05-01' '2013-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-06-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-07-01' '2013-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-08-01' '2013-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-09-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-10-01' '2013-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-11-01' '2013-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2013-12-01' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-01-01' '2013-01-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-02-01' '2013-02-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-03-01' '2013-03-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-04-01' '2013-04-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-05-01' '2013-05-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-06-01' '2013-06-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-07-01' '2013-07-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-08-01' '2013-08-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-09-01' '2013-09-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-10-01' '2013-10-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-11-01' '2013-11-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-12-01' '2013-12-15' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-01-16' '2013-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-02-16' '2013-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-03-16' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-04-16' '2013-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-05-16' '2013-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-06-16' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-07-16' '2013-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-08-16' '2013-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-09-16' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-10-16' '2013-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-11-16' '2013-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2013-12-16' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-01-01' '2013-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-02-01' '2013-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-03-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-04-01' '2013-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-05-01' '2013-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-06-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-07-01' '2013-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-08-01' '2013-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-09-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-10-01' '2013-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-11-01' '2013-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2013-12-01' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-01-01' '2013-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-02-01' '2013-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-03-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-04-01' '2013-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-05-01' '2013-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-06-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-07-01' '2013-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-08-01' '2013-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-09-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-10-01' '2013-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-11-01' '2013-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2013-12-01' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-01-01' '2013-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-02-01' '2013-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-03-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-04-01' '2013-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-05-01' '2013-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-06-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-07-01' '2013-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-08-01' '2013-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-09-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-10-01' '2013-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-11-01' '2013-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2013-12-01' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-01-01' '2013-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-02-01' '2013-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-03-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-04-01' '2013-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-05-01' '2013-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-06-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-07-01' '2013-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-08-01' '2013-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-09-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-10-01' '2013-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-11-01' '2013-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2013-12-01' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-01-01' '2013-01-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-02-01' '2013-02-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-03-01' '2013-03-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-04-01' '2013-04-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-05-01' '2013-05-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-06-01' '2013-06-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-07-01' '2013-07-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-08-01' '2013-08-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-09-01' '2013-09-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-10-01' '2013-10-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-11-01' '2013-11-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-12-01' '2013-12-15' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-01-16' '2013-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-02-16' '2013-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-03-16' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-04-16' '2013-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-05-16' '2013-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-06-16' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-07-16' '2013-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-08-16' '2013-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-09-16' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-10-16' '2013-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-11-16' '2013-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2013-12-16' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 144 '2013-01-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 144 '2013-04-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 144 '2013-07-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 144 '2013-10-01' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 147 '2013-01-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 147 '2013-04-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 147 '2013-07-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 147 '2013-10-01' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2013-01-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2013-04-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2013-07-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2013-10-01' '2013-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2013-01-01' '2013-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2013-04-01' '2013-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2013-07-01' '2013-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2013-10-01' '2013-12-31' </dev/null >/dev/null 2>&1 &


