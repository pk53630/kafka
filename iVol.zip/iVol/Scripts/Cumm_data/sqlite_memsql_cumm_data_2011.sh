#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-01-01' '2011-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-02-01' '2011-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-03-01' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-04-01' '2011-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-05-01' '2011-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-06-01' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-07-01' '2011-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-08-01' '2011-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-09-01' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-10-01' '2011-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-11-01' '2011-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2011-12-01' '2011-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-01-01' '2011-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-02-01' '2011-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-03-01' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-04-01' '2011-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-05-01' '2011-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-06-01' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-07-01' '2011-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-08-01' '2011-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-09-01' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-10-01' '2011-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-11-01' '2011-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2011-12-01' '2011-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-01-01' '2011-01-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-02-01' '2011-02-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-03-01' '2011-03-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-04-01' '2011-04-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-05-01' '2011-05-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-06-01' '2011-06-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-07-01' '2011-07-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-08-01' '2011-08-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-09-01' '2011-09-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-10-01' '2011-10-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-11-01' '2011-11-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-12-01' '2011-12-15' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-01-16' '2011-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-02-16' '2011-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-03-16' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-04-16' '2011-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-05-16' '2011-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-06-16' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-07-16' '2011-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-08-16' '2011-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-09-16' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-10-16' '2011-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-11-16' '2011-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2011-12-16' '2011-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-01-01' '2011-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-02-01' '2011-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-03-01' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-04-01' '2011-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-05-01' '2011-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-06-01' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-07-01' '2011-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-08-01' '2011-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-09-01' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-10-01' '2011-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-11-01' '2011-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2011-12-01' '2011-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-01-01' '2011-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-02-01' '2011-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-03-01' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-04-01' '2011-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-05-01' '2011-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-06-01' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-07-01' '2011-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-08-01' '2011-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-09-01' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-10-01' '2011-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-11-01' '2011-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2011-12-01' '2011-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-01-01' '2011-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-02-01' '2011-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-03-01' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-04-01' '2011-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-05-01' '2011-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-06-01' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-07-01' '2011-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-08-01' '2011-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-09-01' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-10-01' '2011-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-11-01' '2011-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2011-12-01' '2011-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2011-01-01' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2011-04-01' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2011-07-01' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2011-10-01' '2011-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-01-01' '2011-01-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-02-01' '2011-02-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-03-01' '2011-03-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-04-01' '2011-04-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-05-01' '2011-05-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-06-01' '2011-06-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-07-01' '2011-07-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-08-01' '2011-08-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-09-01' '2011-09-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-10-01' '2011-10-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-11-01' '2011-11-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-12-01' '2011-12-15' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-01-16' '2011-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-02-16' '2011-02-28' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-03-16' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-04-16' '2011-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-05-16' '2011-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-06-16' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-07-16' '2011-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-08-16' '2011-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-09-16' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-10-16' '2011-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-11-16' '2011-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2011-12-16' '2011-12-31' </dev/null >/dev/null 2>&1 &


nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2011-01-01' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2011-04-01' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2011-07-01' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2011-10-01' '2011-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2011-01-01' '2011-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2011-04-01' '2011-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2011-07-01' '2011-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2011-10-01' '2011-12-31' </dev/null >/dev/null 2>&1 &


