#!/usr/bin/sh

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-01-01' '2008-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-02-01' '2008-02-29' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-03-01' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-04-01' '2008-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-05-01' '2008-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-06-01' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-07-01' '2008-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-08-01' '2008-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-09-01' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-10-01' '2008-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-11-01' '2008-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 10 '2008-12-01' '2008-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-01-01' '2008-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-02-01' '2008-02-29' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-03-01' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-04-01' '2008-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-05-01' '2008-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-06-01' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-07-01' '2008-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-08-01' '2008-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-09-01' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-10-01' '2008-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-11-01' '2008-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 14 '2008-12-01' '2008-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-01-01' '2008-01-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-02-01' '2008-02-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-03-01' '2008-03-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-04-01' '2008-04-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-05-01' '2008-05-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-06-01' '2008-06-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-07-01' '2008-07-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-08-01' '2008-08-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-09-01' '2008-09-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-10-01' '2008-10-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-11-01' '2008-11-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-12-01' '2008-12-15' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-01-16' '2008-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-02-16' '2008-02-29' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-03-16' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-04-16' '2008-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-05-16' '2008-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-06-16' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-07-16' '2008-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-08-16' '2008-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-09-16' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-10-16' '2008-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-11-16' '2008-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 30 '2008-12-16' '2008-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-01-01' '2008-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-02-01' '2008-02-29' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-03-01' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-04-01' '2008-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-05-01' '2008-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-06-01' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-07-01' '2008-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-08-01' '2008-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-09-01' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-10-01' '2008-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-11-01' '2008-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 45 '2008-12-01' '2008-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-01-01' '2008-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-02-01' '2008-02-29' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-03-01' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-04-01' '2008-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-05-01' '2008-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-06-01' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-07-01' '2008-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-08-01' '2008-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-09-01' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-10-01' '2008-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-11-01' '2008-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 50 '2008-12-01' '2008-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-01-01' '2008-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-02-01' '2008-02-29' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-03-01' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-04-01' '2008-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-05-01' '2008-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-06-01' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-07-01' '2008-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-08-01' '2008-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-09-01' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-10-01' '2008-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-11-01' '2008-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 60 '2008-12-01' '2008-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2008-01-01' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2008-04-01' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2008-07-01' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 63 '2008-10-01' '2008-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-01-01' '2008-01-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-02-01' '2008-02-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-03-01' '2008-03-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-04-01' '2008-04-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-05-01' '2008-05-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-06-01' '2008-06-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-07-01' '2008-07-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-08-01' '2008-08-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-09-01' '2008-09-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-10-01' '2008-10-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-11-01' '2008-11-15' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-12-01' '2008-12-15' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-01-16' '2008-01-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-02-16' '2008-02-29' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-03-16' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-04-16' '2008-04-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-05-16' '2008-05-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-06-16' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-07-16' '2008-07-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-08-16' '2008-08-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-09-16' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-10-16' '2008-10-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-11-16' '2008-11-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 95 '2008-12-16' '2008-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2008-01-01' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2008-04-01' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2008-07-01' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 293 '2008-10-01' '2008-12-31' </dev/null >/dev/null 2>&1 &

nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2008-01-01' '2008-03-31' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2008-04-01' '2008-06-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2008-07-01' '2008-09-30' </dev/null >/dev/null 2>&1 &
nohup python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_cumm_data.py 301 '2008-10-01' '2008-12-31' </dev/null >/dev/null 2>&1 &
