#!/bin/sh

python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA_del.py

python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2005
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2006
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2007
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2008
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2009
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2010
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2011
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2012
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2013
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2014
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2015
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2016
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2017
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2018
python3 /home/odmbatch/iVol/Scripts/Cumm_data/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2019

