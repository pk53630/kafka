#!/usr/bin/python3
import sys
import os
import mysql.connector
import datetime

in_year = sys.argv[1]
query="""
select stg.division_id, stg.date_value, 
sum(stg.GROSS_GAS_PROD) as GROSS_GAS_PROD, 
sum(stg.GROSS_OIL_PROD) as GROSS_OIL_PROD,
sum(stg.WATER_PROD) as WATER_PROD,
sum(stg.GROSS_GAS_SALES) as GROSS_GAS_SALES,
sum(stg.GROSS_OIL_SALES) as GROSS_OIL_SALES,
sum(stg.DOWNTIME_HRS) as DOWNTIME_HRS,
sum(stg.POTENTIAL_GAS_PROD) as POTENTIAL_GAS_PROD,
sum(stg.POTENTIAL_OIL_PROD) as POTENTIAL_OIL_PROD,
sum(stg.POTENTIAL_WATER_PROD) as POTENTIAL_WATER_PROD,
sum(stg.FORECAST_GAS_PROD) as FORECAST_GAS_PROD,
sum(stg.FORECAST_OIL_PROD) as FORECAST_OIL_PROD,
sum(stg.FORECAST_WATER_PROD) as FORECAST_WATER_PROD
 from
(select 
division_id, date_value, 
GROSS_GAS_PROD, lag(GROSS_GAS_PROD,1) OVER (ORDER BY date_value) AS prev_GROSS_GAS_PROD,
GROSS_OIL_PROD, lag(GROSS_OIL_PROD,1) OVER (ORDER BY date_value) AS prev_GROSS_OIL_PROD,
WATER_PROD, lag(WATER_PROD,1) OVER (ORDER BY date_value) AS prev_WATER_PROD,
GROSS_GAS_SALES, lag(GROSS_GAS_SALES,1) OVER (ORDER BY date_value) AS prev_GROSS_GAS_SALES,
GROSS_OIL_SALES, lag(GROSS_OIL_SALES,1) OVER (ORDER BY date_value) AS prev_GROSS_OIL_SALES,
DOWNTIME_HRS, lag(DOWNTIME_HRS,1) OVER (ORDER BY date_value) AS prev_DOWNTIME_HRS,
POTENTIAL_GAS_PROD, lag(POTENTIAL_GAS_PROD,1) OVER (ORDER BY date_value) AS prev_POTENTIAL_GAS_PROD,
POTENTIAL_OIL_PROD, lag(POTENTIAL_OIL_PROD,1) OVER (ORDER BY date_value) AS prev_POTENTIAL_OIL_PROD,
POTENTIAL_WATER_PROD, lag(POTENTIAL_WATER_PROD,1) OVER (ORDER BY date_value) AS prev_POTENTIAL_WATER_PROD,
FORECAST_GAS_PROD, lag(FORECAST_GAS_PROD,1) OVER (ORDER BY date_value) AS prev_FORECAST_GAS_PROD,
FORECAST_OIL_PROD, lag(FORECAST_OIL_PROD,1) OVER (ORDER BY date_value) AS prev_FORECAST_OIL_PROD,
FORECAST_WATER_PROD, lag(FORECAST_WATER_PROD,1) OVER (ORDER BY date_value) AS prev_FORECAST_WATER_PROD
 from MRTE_DBA.GET_CUMM_PROD_DATA
 where to_char(date_value,'YYYY') in ("""+in_year+""")
) stg
 where if(stg.GROSS_GAS_PROD is null,0,stg.GROSS_GAS_PROD) <> if(stg.prev_GROSS_GAS_PROD is null,0,stg.prev_GROSS_GAS_PROD)
   group by stg.division_id, stg.date_value
  order by 1,2 asc """


#print(query)


cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()

cur.execute(query)

data_list=[]
for row in cur.fetchall():
    data_list.append(list(row))

#print(len(data_list))


stmt1 = """INSERT INTO MRTE_DBA.GET_NON_PREV_CUMM_DATA
(DIVISION_ID,DATE_VALUE,GROSS_GAS_PROD,GROSS_OIL_PROD,WATER_PROD,GROSS_GAS_SALES,GROSS_OIL_SALES,DOWNTIME_HRS,POTENTIAL_GAS_PROD,POTENTIAL_OIL_PROD,POTENTIAL_WATER_PROD,FORECAST_GAS_PROD,FORECAST_OIL_PROD,FORECAST_WATER_PROD)
 VALUES
(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
"""

for k in range(0,len(data_list)):
    #print(len(data_list))
    cur.execute(stmt1,data_list[k])

cnx.commit()
cur.close()
cnx.close()


