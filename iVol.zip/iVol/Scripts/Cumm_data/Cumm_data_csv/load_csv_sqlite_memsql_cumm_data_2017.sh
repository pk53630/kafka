#!/bin/sh

python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 10 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 14 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 30 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 45 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 50 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 60 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 63 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 95 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 205 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 293 2017 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 301 2017 </dev/null >/dev/null 2>&1 &

