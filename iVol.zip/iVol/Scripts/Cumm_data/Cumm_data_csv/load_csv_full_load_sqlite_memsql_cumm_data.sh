#!/bin/sh

echo "2005-2006"
echo `date`
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2005.sh
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2006.sh
until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"| wc -l` -eq 1 ]
do
  sleep 5 
done

echo "2007-2008"
echo `date`
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2007.sh
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2008.sh
until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2009-2010"
echo `date`
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2009.sh
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2010.sh
until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2011-2012"
echo `date`
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2011.sh
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2012.sh
until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2013-2014"
echo `date`
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2013.sh
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2014.sh
until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2015-2016"
echo `date`
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2015.sh
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2016.sh
until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2017-2018"
echo `date`
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2017.sh
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2018.sh
until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2019"
echo `date`
sh /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_2019.sh
until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"| wc -l` -eq 1 ]
do
  sleep 5
done
echo `date`

until [ `ps -ef |grep -i "load_csv_sqlite_memsql_cumm_data"| wc -l` -eq 1 ]
do
  sleep 5
done
echo `date`

exit 0
