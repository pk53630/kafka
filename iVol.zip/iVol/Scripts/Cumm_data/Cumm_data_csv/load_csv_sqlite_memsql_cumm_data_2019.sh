#!/bin/sh

python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 10 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 14 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 30 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 45 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 50 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 60 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 63 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 95 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 205 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 293 2019 </dev/null >/dev/null 2>&1 &
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data.py 301 2019 </dev/null >/dev/null 2>&1 &

