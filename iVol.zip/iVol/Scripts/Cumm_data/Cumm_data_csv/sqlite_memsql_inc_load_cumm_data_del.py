#!/usr/local/bin/python3
import sys
import os
import mysql.connector
import datetime
from datetime import date

#prev_yr = (date.today().year - 1)
prev_yr = (date.today().year)
present_yr = (date.today().year)

cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()

stmt = "DELETE FROM MRTE_DBA.GET_CUMM_PROD_DATA where to_char(date_value,'YYYY') in ("+str(prev_yr)+","+str(present_yr)+")" 
#print(stmt)
cur.execute(stmt)
cnx.commit()

cur.close()
cnx.close()

