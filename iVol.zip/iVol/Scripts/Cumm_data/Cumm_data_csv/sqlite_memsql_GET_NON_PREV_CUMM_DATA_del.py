#!/usr/local/bin/python3
import sys
import os
import mysql.connector
import datetime

cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()

stmt = "DELETE FROM MRTE_DBA.GET_NON_PREV_CUMM_DATA" 
cur.execute(stmt)
cnx.commit()

cur.close()
cnx.close()


