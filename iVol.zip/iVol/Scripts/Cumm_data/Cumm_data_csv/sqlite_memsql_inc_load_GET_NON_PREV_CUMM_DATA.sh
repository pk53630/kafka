#!/bin/sh
echo "Delete GET_NON_PREV_CUMM_DATA table"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA_del.py
echo "2005"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2005
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2006"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2006
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2007"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2007
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2008"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2008
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2009"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2009
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2010"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2010
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2011"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2011
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2012"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2012
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2013"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2013
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2014"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2014
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2015"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2015
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2016"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2016
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2017"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2017
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2018"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2018
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

echo "2019"
echo `date`
python3 /home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/sqlite_memsql_GET_NON_PREV_CUMM_DATA.py 2019
until [ `ps -ef |grep -i "sqlite_memsql_GET_NON_PREV_CUMM_DATA"| wc -l` -eq 1 ]
do
  sleep 5
done

