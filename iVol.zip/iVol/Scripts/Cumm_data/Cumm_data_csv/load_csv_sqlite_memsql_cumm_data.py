#!/usr/local/bin/python3
import sys
import csv
import os
import cx_Oracle
import mysql.connector
import datetime
import arrow

div_id = sys.argv[1]
in_year = sys.argv[2]

now = arrow.now()
nxt_dt=now.shift(days=1).date()
yr=arrow.now().format('YYYY')

if(yr == in_year):
    v_low_dt=yr+"-01-01"
    v_high_dt=nxt_dt
else:
    v_low_dt=in_year+"-01-01"
    v_high_dt=in_year+"-12-31"



query="""
SELECT   
               drv.division_id
      ,        drv.completion_id
      ,        drv.date_id
      ,        drv.date_value
      ,        drv.cum_gross_gas_prod gross_gas_prod
      ,        drv.cum_gross_oil_prod gross_oil_prod
      ,        drv.cum_water_prod water_prod
      ,        drv.cum_gross_gas_sales gross_gas_sales
      ,        drv.cum_gross_oil_sales gross_oil_sales
      ,        drv.cum_downtime_hrs downtime_hrs
      ,        drv.cum_potn_gas_prod potential_gas_prod
      ,        drv.cum_potn_oil_prod potential_oil_prod
      ,        drv.cum_potn_water_prod potential_water_prod
      ,        drv.cum_fcst_gas_prod forecast_gas_prod
      ,        drv.cum_fcst_oil_prod forecast_oil_prod
      ,        drv.cum_fcst_water_prod forecast_water_prod
      ,        drv.cum_missed_gas cum_missed_gas
      ,        drv.cum_missed_oil cum_missed_oil
      ,        drv.cum_missed_water cum_missed_water
      ,        drv.cum_lost_gas cum_lost_gas
      ,        drv.cum_lost_oil cum_lost_oil
      ,        drv.cum_lost_water cum_lost_water
      ,        drv.avg_30d_gross_gas_prod
      ,        drv.avg_30d_gross_gas_sales
      ,        drv.avg_30d_gross_oil_prod
      ,        drv.avg_30d_gross_oil_sales
      ,        drv.avg_30d_water_prod
      ,        drv.avg_30d_water_sales
      ,        drv.avg_60d_gross_gas_prod
      ,        drv.avg_60d_gross_gas_sales
      ,        drv.avg_60d_gross_oil_prod
      ,        drv.avg_60d_gross_oil_sales
      ,        drv.avg_60d_water_prod
      ,        drv.avg_60d_water_sales
      ,        drv.avg_7d_gross_gas_prod
      ,        drv.avg_7d_gross_gas_sales
      ,        drv.avg_7d_gross_oil_prod
      ,        drv.avg_7d_gross_oil_sales
      ,        drv.avg_7d_water_prod
      ,        drv.avg_7d_water_sales
      ,        drv.avg_90d_gross_gas_prod
      ,        drv.avg_90d_gross_gas_sales
      ,        drv.avg_90d_gross_oil_prod
      ,        drv.avg_90d_gross_oil_sales
      ,        drv.avg_90d_water_prod
      ,        drv.avg_90d_water_sales
      ,        drv.cmavg_7d_gross_gas_prod
      ,        drv.cmavg_7d_gross_gas_sales
      ,        drv.cmavg_7d_gross_oil_prod
      ,        drv.cmavg_7d_gross_oil_sales
      ,        drv.cmavg_7d_water_prod
      ,        drv.cmavg_7d_water_sales
      ,        drv.mtd_gross_gas_prod
      ,        drv.mtd_gross_gas_sales
      ,        drv.mtd_gross_oil_prod
      ,        drv.mtd_gross_oil_sales
      ,        drv.mtd_water_prod
      ,        drv.mtd_water_sales
      ,        drv.load_water_rem
      ,        drv.load_water_pct
      FROM     odm_dba.odm_comp_prod_dly_drv drv
      WHERE    trunc(drv.date_value) BETWEEN to_date('"""+str(v_low_dt)+"""','YYYY-MM-DD') and to_date('"""+str(v_high_dt)+"""','YYYY-MM-DD')
      and      drv.division_id ="""+str(div_id)

#print(query)

connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(query)

filename = "/home/odmbatch/iVol/Scripts/Cumm_data/Cumm_data_csv/load_csv_sqlite_memsql_cumm_data_"+str(in_year)+"_"+str(div_id)+".dat"

row = cursor.fetchall()
with open(filename, 'w', newline='\n') as fp:
    a = csv.writer(fp, delimiter='|')
    a.writerows(row)

cursor.close()
connection.close()	


cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()


stmt = """ 
LOAD DATA LOCAL INFILE  
'"""+filename+"""'
INTO TABLE MRTE_DBA.GET_CUMM_PROD_DATA
FIELDS TERMINATED BY '|' 
(DIVISION_ID, COMPLETION_ID, DATE_ID, @DATE_VALUE, GROSS_GAS_PROD, GROSS_OIL_PROD, WATER_PROD, GROSS_GAS_SALES, GROSS_OIL_SALES, DOWNTIME_HRS, POTENTIAL_GAS_PROD, POTENTIAL_OIL_PROD, POTENTIAL_WATER_PROD, FORECAST_GAS_PROD, FORECAST_OIL_PROD, FORECAST_WATER_PROD, CUM_MISSED_GAS, CUM_MISSED_OIL, CUM_MISSED_WATER, CUM_LOST_GAS, CUM_LOST_OIL, CUM_LOST_WATER, AVG_30D_GROSS_GAS_PROD, AVG_30D_GROSS_GAS_SALES, AVG_30D_GROSS_OIL_PROD, AVG_30D_GROSS_OIL_SALES, AVG_30D_WATER_PROD, AVG_30D_WATER_SALES, AVG_60D_GROSS_GAS_PROD, AVG_60D_GROSS_GAS_SALES, AVG_60D_GROSS_OIL_PROD, AVG_60D_GROSS_OIL_SALES, AVG_60D_WATER_PROD, 
 AVG_60D_WATER_SALES, AVG_7D_GROSS_GAS_PROD, AVG_7D_GROSS_GAS_SALES, AVG_7D_GROSS_OIL_PROD, AVG_7D_GROSS_OIL_SALES, AVG_7D_WATER_PROD, AVG_7D_WATER_SALES, AVG_90D_GROSS_GAS_PROD, AVG_90D_GROSS_GAS_SALES, AVG_90D_GROSS_OIL_PROD, AVG_90D_GROSS_OIL_SALES, AVG_90D_WATER_PROD, AVG_90D_WATER_SALES, CMAVG_7D_GROSS_GAS_PROD, CMAVG_7D_GROSS_GAS_SALES, CMAVG_7D_GROSS_OIL_PROD, CMAVG_7D_GROSS_OIL_SALES, CMAVG_7D_WATER_PROD, CMAVG_7D_WATER_SALES, MTD_GROSS_GAS_PROD, MTD_GROSS_GAS_SALES, MTD_GROSS_OIL_PROD, MTD_GROSS_OIL_SALES, MTD_WATER_PROD, MTD_WATER_SALES, LOAD_WATER_REM, LOAD_WATER_PCT)
SET DATE_VALUE = STR_TO_DATE(@DATE_VALUE, '%Y-%m-%d') """

#print(stmt)
cur.execute(stmt)
cnx.commit()


cur.close()
cnx.close()

os.remove(filename)

