#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re
import threading
from multiprocessing import Process

div_id = sys.argv[1]

def get_cumm_date(p_low, p_high):
    query=""" SELECT   prod.division_id
      ,        prod.completion_id
      ,        date_id
      ,        date_value
      ,        prod.gross_gas_prod
      ,        prod.gross_oil_prod
      ,        prod.water_prod
      ,        gross_gas_sales
      ,        gross_oil_sales
      ,        downtime_hrs
      ,        potential_gas_prod
      ,        potential_oil_prod
      ,        potential_water_prod
      ,        forecast_gas_prod
      ,        forecast_oil_prod
      ,        forecast_water_prod
      ,        prod.tubing_pressure
      ,        prod.casing_pressure1
      ,        casing_pressure2
      ,        choke
      ,        comments
      ,        gas_inj
      ,        line_pressure
      ,        0 nri_gas
      ,        0 nri_oil
      ,        0 perc_comments_fl
      ,        0 aries_comments_fl
      ,        chlorides
      ,        measured_fluid_level
      ,        0 shot_fluid_level
      ,        measured_bhp
      ,        gas_lift_vol
      ,        h2s
      ,        water_inj
      ,        surf_casing_press
      ,        strokes
      ,        (SELECT  (INITCAP(REGEXP_REPLACE(SUBSTR(v.ref_value_key, INSTR(v.ref_value_key, '_') + 1, LENGTH(v.ref_value_key)),'_' ,' ')))
               FROM     odm_dba.odm_ref_value v
               ,        odm_dba.odm_ref_value_type vt
               WHERE    vt.ref_value_type_name = 'DOWNTIME_REASON'
               AND      vt.ref_value_type_id = v.ref_value_type_id
               AND      prod.downtime_reason_ref_id = v.ref_value_id
               and      prod.downtime_hrs > 0
               ) downtime_reason_key
      ,        gross_oil_beg_inv   
      ,        gross_oil_end_inv   
      ,        gas_flare
      ,        sc_bhp
      ,        dh_valve
      ,        c5
      ,        ROUND(oil_gravity,5) oil_gravity
      ,        fresh_water_inj
      ,        salt_water_inj
      ,        WATER_HAULED
      FROM     odm_dba.odm_comp_production prod
      ,        odm_dba.scada_comp_prod_daily sprod
      WHERE    prod.division_id = sprod.division_id(+)
      AND      prod.completion_id = sprod.completion_id(+)
      AND      prod.date_id = sprod.prod_date_id(+)
      AND    prod.date_value BETWEEN trunc(sysdate)-"""+str(p_low)+""" AND trunc(sysdate)-"""+str(p_high)+"""
      and prod.division_id ="""+str(div_id)
    print(query)
    stmt1 = """INSERT INTO MRTE_DBA.GET_PROD_DATA
    (DIVISION_ID, COMPLETION_ID, DATE_ID, DATE_VALUE, GROSS_GAS_PROD, GROSS_OIL_PROD, WATER_PROD, GROSS_GAS_SALES, GROSS_OIL_SALES, DOWNTIME_HRS, POTENTIAL_GAS_PROD, POTENTIAL_OIL_PROD, POTENTIAL_WATER_PROD, FORECAST_GAS_PROD, FORECAST_OIL_PROD, FORECAST_WATER_PROD, TUBING_PRESSURE, CASING_PRESSURE1, CASING_PRESSURE2, CHOKE, COMMENTS, GAS_INJ, LINE_PRESSURE, 
    NRI_GAS, NRI_OIL, PERC_COMMENTS_FL, ARIES_COMMENTS_FL, CHLORIDES, MEASURED_FLUID_LEVEL, SHOT_FLUID_LEVEL, MEASURED_BHP, GAS_LIFT_VOL, H2S, WATER_INJ, SURF_CASING_PRESS, STROKES, DOWNTIME_REASON_KEY, GROSS_OIL_BEG_INV, GROSS_OIL_END_INV, GAS_FLARE, SC_BHP, DH_VALVE, C5, OIL_GRAVITY, FRESH_WATER_INJ, SALT_WATER_INJ, WATER_HAULED)
    VALUES
    (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
    print(stmt1)
    connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
    cursor = cx_Oracle.Cursor(connection)
    cursor.execute(query)

    data_list=[]
    for row in cursor.fetchall():
        data_list.append(list(row))
    #print(data_list)
	
    cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
    cur = cnx.cursor()

    for k in range(0,len(data_list)):
        cur.execute(stmt1,data_list[k])

    cnx.commit()

    cur.close()
    cnx.close()

    cursor.close()
    connection.close()

if __name__=='__main__':
    p1 = Process(target = get_cumm_date(50,0))
    p1.start()
    p2 = Process(target = get_cumm_date(100,51))
    p2.start()
    # This is where I had to add the join() function.
    p1.join()
    p2.join()
	

