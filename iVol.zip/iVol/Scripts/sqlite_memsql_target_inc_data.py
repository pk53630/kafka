#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re

#div_id = sys.argv[1]
#pwd = sys.argv[1]
#sid = sys.argv[1]

dt=arrow.now().format('YYYY-MM-DD')
filename="""/home/odmbatch/odm/logs/get_target_inc_data_"""+dt+""".log"""

my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    #print("file is not present")
    Path(filename).touch()


log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("########################################### NRI DATA EXTACTION STARTED #########################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")


del_query="""select DIVISION_ID, COMPLETION_ID, DATE_VALUE from MRTE_DBA.GET_TARGET_DATA where DATE_VALUE between (select min(DATE_VALUE) from MRTE_DBA.GET_TARGET_DATA) and DATE_SUB(current_date(), INTERVAL 366 DAY) order by DATE_VALUE desc"""

cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()

cur.execute(del_query)

del_data_list=[]

for row in cur.fetchall():
    del_data_list.append(list(row))
	
print(del_data_list[1])
print('Total Row(s):', cur.rowcount)

stmt = "DELETE FROM MRTE_DBA.GET_TARGET_DATA WHERE DIVISION_ID = (%s) and COMPLETION_ID = (%s) and DATE_VALUE = (%s)" 
cur.executemany(stmt,del_data_list)


#rows = cur.fetchall()
#print('Total Row(s):', cur.rowcount)
#for row in rows:
#    print(row)

max_dt_lst=[]
max_dt = "select to_char(adddate(max(DATE_VALUE),INTERVAL 1 DAY),'YYYY-MM-DD') from MRTE_DBA.GET_TARGET_DATA"
cur.execute(max_dt)
for row in cur.fetchall():
    max_dt_lst.append(list(row))

print(", ".join(max_dt_lst[0]))

inc_query = """
SELECT  prod.division_id
,        prod.completion_id
,        prod.prod_dt date_value
,        prod.gross_oil_prod target_oil_prod
,        prod.gross_gas_prod target_gas_prod
,        prod.gross_water_prod target_water_prod
FROM    odm_dba.odm_comp_target_prod_daily prod
WHERE    prod.prod_dt BETWEEN to_date('"""+", ".join(max_dt_lst[0])+"""','YYYY-MM-DD') AND trunc(sysdate)+1
"""

print(inc_query)

connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(inc_query)

data_list=[]
column_names =[]

for i in cursor.description:
    column_names.append(i[0])
for row in cursor.fetchall():
    data_list.append(list(row))

print(data_list[1])	
print("Number of items in list: ",len(data_list))


stmt1 = """INSERT INTO MRTE_DBA.GET_TARGET_DATA
(DIVISION_ID, COMPLETION_ID, DATE_VALUE,TARGET_OIL_PROD,TARGET_GAS_PROD,TARGET_WATER_PROD)
 VALUES
(%s, %s, %s, %s, %s, %s)"""


for k in range(0,len(data_list)):
    cur.execute(stmt1,data_list[k])


cnx.commit()







cursor.close()
connection.close()	


cur.close()
cnx.close()

