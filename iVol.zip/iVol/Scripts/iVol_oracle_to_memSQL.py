#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import pandas as pd
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re
import smtplib

src_owner_nm = sys.argv[1]
src_table_nm = sys.argv[2]
tgt_owner_nm = sys.argv[3]
tgt_table_nm = sys.argv[4]

dt=arrow.now().format('YYYYMMDD')
dtMS=arrow.now().format('HHMS')

filename="""/home/odmbatch/iVol/logs/iVol_"""+src_table_nm+dt+""".log"""
#archive_file= """/home/odmbatch/iVol/archive/"""+dtMS+"""_iVol_"""+src_table_nm+"""_"""+dt+""".csv"""

#validation_file="""/home/odmbatch/iVol/data/"""+dtMS+"""_iVol_"""+src_table_nm+"""_"""+dt+""".csv"""
#Path(validation_file).touch()


my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    #print("file is not present")
    Path(filename).touch()


log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("################################################################################################################")
logger.info("############################################ iVolume EXTACTION STARTED ################################################")
logger.info("################################################################################################################")

def purge_full_tbl():
    purge_tgt_full = "DELETE FROM "+tgt_owner_nm+"."+tgt_table_nm
    cur.execute(purge_tgt_full)
    cnx.commit()


def diff_df(df1, df2, how="left"):
    """
      Find Difference of rows for given two dataframes
      this function is not symmetric, means
            diff(x, y) != diff(y, x)
      however
            diff(x, y, how='left') == diff(y, x, how='right')
    """
    #print(df1.columns.str.lower())
    #print(df2.columns.str.lower())

    if df1.equals(df2):
        return None
    elif how == 'right':
        return pd.concat([df2, df1, df1]).drop_duplicates(keep=False)
    elif how == 'left':
        return pd.concat([df1, df2, df2]).drop_duplicates(keep=False)
    else:
        raise ValueError('how parameter supports only "left" or "right keywords"')



def extract_full_load():
    print("Full Extraction Load")
    cursor.execute(src_col_query)
    src_column_names =[]

    for row in cursor.fetchall():
         src_column_names.append(list(row))

    x=""
    for i in range(0,len(src_column_names)):
         x=x+","+(''.join(src_column_names[i]))

    b=len(x)
    all_col=x[1:b]
    #print(x[1:b])
    src_query_in="select "+all_col+" from "+src_owner_nm+"."+src_table_nm
    print(src_query_in)
    logger.info("                                                                                                                ")
    logger.info("############################# Source Query wilth Dynamic SELECT Statement Execution ############################")

    cursor.execute(src_query_in)

    data_list = []

    for row1 in cursor.fetchall():
         data_list.append(list(row1))

    print(len(data_list))

    cursor.execute(src_cnt)
    res = cursor.fetchall()
    #print (res[0][0])

    x1=""
    for k in range(0,res[0][0]):
         x1=x1+","+(''.join('%s'))

    b1=len(x1)
    all_col_value=x1[1:b1]
    #print(x1[1:b1])

    stmt1 = """INSERT INTO """+tgt_owner_nm+"""."""+tgt_table_nm+"""("""+all_col+""")"""+""" VALUES ("""+all_col_value+""")"""

    print(stmt1)

    for k in range(0,len(data_list)):
         cur.execute(stmt1,data_list[k])

    cnx.commit()
    logger.info("###################################### Insert Statement COMPLETED Execution ####################################")



def extract_inc_load(v_max_dt):
    print("Incremental Extraction Load")
    cursor.execute(src_col_query)

    v_order_by=""
    for p in range(1,src_pk_col_res[0][0]+1):
        v_order_by=v_order_by+","+str(p)

    #print(v_order_by[1:len(v_order_by)])

    src_column_names =[]

    for row in cursor.fetchall():
        src_column_names.append(list(row))

    x1=""
    x11=""
    for j in range(0,len(src_column_names)):
        x1=x1+","+(''.join(src_column_names[j]))
        x11=x11+","+(''.join('%s'))

    a1=len(x1)
    v_all_col=x1[1:a1]
    v_all_val=x11[1:a1]
    #print(x1[1:a1])

    cursor.execute(src_con_query)
    pk_col_list = []

    for row1 in cursor.fetchall():
        pk_col_list.append(list(row1))

    #print(pk_col_list)

    x2=""
    x3=""
    x4=""
    x5=""
    x6=""
    for k in range(0,len(pk_col_list)):
        x5=x5+"to_char("+(''.join(pk_col_list[k]))+") as DF_"+str(k)+","
        x6=x6+"convert("+(''.join(pk_col_list[k]))+",CHAR) as DF_"+str(k)+","
        x2=x2+","+(''.join(pk_col_list[k]))
        x3=x3+(''.join(pk_col_list[k]))+" = (%s) and "
        x4=x4+(''.join(pk_col_list[k]))+" = (:s) and "
    
    a2=len(x2)
    v_pk_col=x2[1:a2]
    #print(x2[1:a2])

    a3=len(x3)-4
    v_memSQL_where=x3[0:a3]
    #print(x3[0:a3])
    a4=len(x4)-4
    v_orcSQL_where=x4[0:a4]
    if(v_order_by == ""):
        v_order_by="1"
        print(v_order_by)

    print(x5[0:len(x5)-1]) 
    #print(v_order_by) 
    src_pk_id="select "+v_pk_col+" from "+src_owner_nm+"."+src_table_nm+" where (update_ts > to_date('"+v_tgt_max_dt[0][0]+"','YYYY-MM-DD HH24:MI:SS') OR create_ts > to_date('"+v_tgt_max_dt[0][0]+"','YYYY-MM-DD HH24:MI:SS'))"
    print(src_pk_id)

    cursor.execute(src_pk_id)
    pk_data_tuple=[]
    pk_data_list = []

    for row2 in cursor.fetchall():
        pk_data_list.append(list(row2))

	
    print(len(pk_data_list))
    chk_rec_tgt="select "+v_pk_col+" from "+tgt_owner_nm+"."+tgt_table_nm+" where "+v_memSQL_where
    print(chk_rec_tgt)

    for m in range(0,len(pk_data_list)):
        cur.execute(chk_rec_tgt,pk_data_list[m])
        tgt_rec=cur.fetchall()
        #print(pk_data_list[m])
        if(len(tgt_rec) > 0):
            stmt = "DELETE FROM "+tgt_owner_nm+"."+tgt_table_nm+" where "+v_memSQL_where
            #print(tgt_rec[0])
            cur.execute(stmt,tgt_rec[0])
            cnx.commit()
        src_sel_query="select "+v_all_col+" from "+src_owner_nm+"."+src_table_nm+" where "+v_orcSQL_where
        #print(src_sel_query)
        cursor.execute(src_sel_query,pk_data_list[m])
        src_sel_query_res=cursor.fetchall()
        #print(src_sel_query_res)
        stmt1 = """INSERT INTO """+tgt_owner_nm+"""."""+tgt_table_nm+"""("""+v_all_col+""")"""+""" VALUES ("""+v_all_val+""")"""
        #print(src_sel_query_res[0])
        cur.execute(stmt1,src_sel_query_res[0])
        cnx.commit()

    #print(len(tgt_rec))
    # print(len(src_sel_query_res))
    src_query_in="select "+x5[0:len(x5)-1]+" from "+src_owner_nm+"."+src_table_nm+" order by "+v_order_by[1:len(v_order_by)]+" asc"
    tgt_query_in="select "+x6[0:len(x6)-1]+" from "+tgt_owner_nm+"."+tgt_table_nm+" order by "+v_order_by[1:len(v_order_by)]+" asc"
    print(src_query_in)
    print(tgt_query_in)
    df1 = pd.read_sql(tgt_query_in,cnx)
    df2 = pd.read_sql(src_query_in,connection)
    # find elements in df1 that are not in df2
    df3=pd.DataFrame(df1[:])
    df4=pd.DataFrame(df2)
    print(len(df4))
    print(len(df3))
    df5=pd.concat([df3, df4, df4]).drop_duplicates(keep=False)
    print(len(df5))
    #df4=df3[['df_0','df_1','df_2']]
    #print(df3[['DF_0','DF_1']])
    v_del_lst=[]
    v_del_lst=df5.values.tolist()
    print(len(v_del_lst))
    if (len(v_del_lst ) > 0 ):
        for p in range(0,len(v_del_lst)):
            stmt2 = "DELETE FROM "+tgt_owner_nm+"."+tgt_table_nm+" where "+v_memSQL_where
            print(stmt2)
            print(v_del_lst[p])
            cur.execute(stmt2,v_del_lst[p])
            cnx.commit()


    df6=pd.read_sql(tgt_query_in,cnx)
    df7=pd.read_sql(src_query_in,connection)
    df8=pd.concat([df6, df7, df7]).drop_duplicates(keep=False)
    print(len(df8))
    df9=pd.concat([df7, df6, df6]).drop_duplicates(keep=False)
    print(len(df9))






src_updt_col_chk="""select count(*) from all_col_comments where column_name ='UPDATE_TS' and table_name='"""+src_table_nm+"""' and owner='"""+src_owner_nm+"""'"""
src_pk_col_chk="""select count(*) from all_cons_columns a, all_constraints b where a.constraint_name = b.constraint_name  and b.constraint_type='P' and a.table_name='"""+src_table_nm+"""' and a.owner='"""+src_owner_nm+"""'"""

tgt_max_dt="""select nvl(max(update_ts),'1111-01-01 00:00:00') as max_dt from """+tgt_owner_nm+"""."""+tgt_table_nm
src_col_query="""select column_name from all_col_comments where table_name='"""+src_table_nm+"""' and owner='"""+src_owner_nm+"""'"""
#src_query="""select column_name from all_col_comments where table_name='"""+src_table_nm+"""' and owner='"""+src_owner_nm+"""'"""
src_cnt="""select count(column_name) from all_col_comments where table_name='"""+src_table_nm+"""' and owner='"""+src_owner_nm+"""'"""
src_con_query="""select distinct a.column_name from all_cons_columns a, all_constraints b where a.constraint_name = b.constraint_name  and b.constraint_type='P' and a.table_name='"""+src_table_nm+"""' and a.owner='"""+src_owner_nm+"""'"""


connection = cx_Oracle.connect('mrte_dba/Test_456@r1date.eogresources.com')
cursor = cx_Oracle.Cursor(connection)

cursor.execute(src_updt_col_chk)
src_updt_col_res = cursor.fetchall()
print(src_updt_col_res[0][0])

cursor.execute(src_pk_col_chk)
src_pk_col_res = cursor.fetchall()
print(src_pk_col_res[0][0])


cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()


if (src_updt_col_res[0][0] > 0 and src_pk_col_res[0][0] > 0):
    cur.execute(tgt_max_dt)
    v_tgt_max_dt=cur.fetchall()
    v_max_dt=v_tgt_max_dt[0][0]
    print(v_tgt_max_dt[0][0])
    if(v_max_dt == '1111-01-01 00:00:00'):
        extract_full_load()
    else:
        extract_inc_load(v_max_dt)
else:
    print("No Update timestamp and primary keys are present not possible to delta loads")
    purge_full_tbl()
    extract_full_load()


cur.close()
cnx.close()

cursor.close()
connection.close()
