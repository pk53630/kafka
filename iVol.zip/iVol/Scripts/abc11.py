#!/usr/bin/python3

lst=[10 ,14 ,30 ,45 ,50 ,60 ,63 ,93 ,94 ,95 ,144,147,205,293,301]


for i in lst:
    print(i)




