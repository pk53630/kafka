#!/usr/bin/python3
import sys
import os
import cx_Oracle
import mysql.connector
import datetime
import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
import arrow
import re

#div_id = sys.argv[1]
#pwd = sys.argv[1]
#sid = sys.argv[1]

dt=arrow.now().format('YYYY-MM-DD')
filename="""/home/odmbatch/odm/logs/get_liquid_level_data_"""+dt+""".log"""

my_file = Path(filename)
if (not my_file.is_file()):
    # file not exists
    #print("file is not present")
    Path(filename).touch()


log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = 10
handler = TimedRotatingFileHandler(filename, when="midnight", interval=1)
handler.setLevel(log_level)
formatter = logging.Formatter(log_format)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# add a suffix which you want
handler.suffix = "%Y-%m-%d %HH:%M:%S"

#need to change the extMatch variable to match the suffix for it
handler.extMatch = re.compile(r"^\d{8}$")

# finally add handler to logger
logger.addHandler(handler)

logger.info("                                                                                                                ")
logger.info("################################################################################################################")
logger.info("########################################### NRI DATA EXTACTION STARTED #########################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")


query=""" SELECT  
      e.division_ID,
      c.completion_id,
      e.DEPTH_TO_LIQ_LEVEL,
      e.TOTAL_GASEOUS_LIQ_COLUMN_HT,
      e.PRODUCING_BHP ,
      e.PUMP_INTAKE_DEPTH,
      e.PUMP_INTAKE_PRESSURE,
      e.EQUIVALENT_GAS_FREE_LIQ_HT,
      e.CASING_PRESSURE,
      e.STATIC_BHP,
      e.PBHP,
      e.FLUID_LEVEL_SURVEY_DATE
      FROM     odm_dba.odm_completion c
      ,        iprod_dba.echometer_fluid_survey e
      WHERE    c.division_id = e.division_id
      AND      c.primo_prprty = e.well_id """

connection = cx_Oracle.connect('DATAMART_READ_ONLY/Welcome_1@P1DATE.EOGRESOURCES.COM')
cursor = cx_Oracle.Cursor(connection)
cursor.execute(query)

data_list=[]
column_names =[]

for i in cursor.description:
    column_names.append(i[0])
for row in cursor.fetchall():
    data_list.append(list(row))

cnx = mysql.connector.connect(user='MRTE_DBA', password='testpass123', host='OPSMSQLDEV01')
cur = cnx.cursor()

logger.info("                                                                                                                ")
logger.info("                                                                                                                ")
logger.info("###################################### Insert Statement STARTED Execution ######################################")
stmt1 = """INSERT INTO MRTE_DBA.GET_LIQUIDLEVEL_DATA
(DIVISION_ID, COMPLETION_ID, DEPTH_TO_LIQ_LEVEL, TOTAL_GASEOUS_LIQ_COLUMN_HT, PRODUCING_BHP, PUMP_INTAKE_DEPTH, PUMP_INTAKE_PRESSURE, EQUIVALENT_GAS_FREE_LIQ_HT, CASING_PRESSURE, STATIC_BHP, PBHP, FLUID_LEVEL_SURVEY_DATE)
 VALUES
(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""

#cur.executemany(stmt1, data_list)
for k in range(0,len(data_list)):
    cur.execute(stmt1,data_list[k])



cnx.commit()

logger.info("###################################### Insert Statement COMPLETED Execution ####################################")
logger.info("                                                                                                                ")
cur.close()
cnx.close()

cursor.close()
connection.close()

logger.info("################################################################################################################")
logger.info("##################################### ODM WELL DELTA EXTACTION COMPLETED #######################################")
logger.info("################################################################################################################")
logger.info("                                                                                                                ")
logger.info("                                                                                                                ")


